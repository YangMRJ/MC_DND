package com.example.dnd.client;

import com.example.dnd.block.BoardBlockEntity;
import com.example.dnd.block.BoardBlockEntity.Token;
import com.example.dnd.block.MiniData;
import com.example.dnd.client.render.BoardRenderer;
import com.example.dnd.client.render.TerrainMesher;
import com.example.dnd.network.BoardActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.phys.Vec3;

/**
 * Orbiting 3D view of a board. The world keeps rendering behind the screen; we move the camera
 * around the board center with a client-only camera entity and do our own ray picking.
 *
 * Tab "Minis": left click places / drags a miniature, R rotates the one under the mouse, right click removes it.
 * Tab "Mapa": left click / drag paints with the selected tool (terrain, height, props).
 * Right drag: orbit. Wheel: zoom.
 */
public class BoardScreen extends Screen {
	private static final double CELL = BoardRenderer.CELL;
	private static final double TOP = BoardRenderer.TOP;
	private static final double ORIGIN = BoardRenderer.ORIGIN;
	private static final int PANEL_W = 130, ROW = 20, BROW = 17, COL_W = 64;

	private enum Mode { MINIS, BUILD }

	private enum Kind { TILE, RAISE, LOWER, PROP }

	private final BlockPos pos;
	private Entity cameraEntity;

	// orbit state
	private double azim = 0.0;
	private double elev = 0.95;
	private double dist = 2.4;

	private Mode mode = Mode.MINIS;
	private int slot = 0;
	private Kind tool = Kind.TILE;
	private int toolValue = 0;
	private int dragId = -1;
	private int lastPaintX = -1, lastPaintZ = -1;
	private boolean painting;
	private boolean rightDown, rightMoved;
	private double rightX, rightY;
	private int panelX;

	// camera basis, refreshed every frame
	private Vec3 camPos = Vec3.ZERO, fwd = Vec3.ZERO, right = Vec3.ZERO, up = Vec3.ZERO;

	public BoardScreen(BlockPos pos) {
		super(Component.literal("Tabuleiro"));
		this.pos = pos;
	}

	// ---------------------------------------------------------------- setup

	@Override
	protected void init() {
		panelX = this.width - PANEL_W - 8;

		Minecraft mc = Minecraft.getInstance();
		if (cameraEntity == null && mc.level != null) {
			cameraEntity = EntityTypes.MARKER.create(mc.level, EntitySpawnReason.TRIGGERED);
		}
		if (cameraEntity != null) {
			// Note: set the camera entity FIRST, then position it. Setting it after positioning
			// can make the vanilla camera system reset our transform on the next frame.
			mc.setCameraEntity(cameraEntity);
			updateCamera();
		}
	}

	@Override
	public void removed() {
		Minecraft mc = Minecraft.getInstance();
		mc.setCameraEntity(mc.player);
		super.removed();
	}

	private BoardBlockEntity board() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level != null && mc.level.getBlockEntity(pos) instanceof BoardBlockEntity be) return be;
		return null;
	}

	private void send(BoardActionPayload payload) {
		ClientPlayNetworking.send(payload);
	}

	// ---------------------------------------------------------------- camera math

	private Vec3 center() {
		return new Vec3(pos.getX() + 0.5, pos.getY() + TOP + 0.08, pos.getZ() + 0.5);
	}

	private void updateCamera() {
		Vec3 c = center();
		double ce = Math.cos(elev), se = Math.sin(elev);
		camPos = new Vec3(c.x + dist * ce * Math.sin(azim), c.y + dist * se, c.z - dist * ce * Math.cos(azim));
		fwd = c.subtract(camPos).normalize();
		right = fwd.cross(new Vec3(0, 1, 0)).normalize();
		up = right.cross(fwd);

		if (cameraEntity != null) {
			float yaw = (float) Math.toDegrees(Math.atan2(-fwd.x, fwd.z));
			float pitch = (float) Math.toDegrees(Math.asin(-fwd.y));
			// The camera sits at the entity's eye; compensate so the eye ends up exactly at camPos.
			double eyeOffset = cameraEntity.getEyeY() - cameraEntity.getY();
			cameraEntity.setPos(camPos.x, camPos.y - eyeOffset, camPos.z);
			cameraEntity.setYRot(yaw);
			cameraEntity.setXRot(Mth.clamp(pitch, -90f, 90f));
			cameraEntity.setOldPosAndRot();
		}
	}

	private double tanHalfFov() {
		double fov = Minecraft.getInstance().options.fov().get();
		return Math.tan(Math.toRadians(fov) / 2.0);
	}

	/** World point -> GUI coordinates, or null when behind the camera. */
	private double[] project(Vec3 p) {
		Vec3 v = p.subtract(camPos);
		double z = v.dot(fwd);
		if (z < 0.05) return null;
		double th = tanHalfFov();
		double aspect = (double) this.width / this.height;
		double sx = (v.dot(right) / (z * th * aspect) * 0.5 + 0.5) * this.width;
		double sy = (0.5 - v.dot(up) / (z * th) * 0.5) * this.height;
		return new double[]{sx, sy};
	}

	private Vec3 rayDir(double mx, double my) {
		double th = tanHalfFov();
		double aspect = (double) this.width / this.height;
		double nx = (mx / this.width) * 2 - 1;
		double ny = 1 - (my / this.height) * 2;
		return fwd.add(right.scale(nx * th * aspect)).add(up.scale(ny * th)).normalize();
	}

	private double cellX0(int x) {
		return pos.getX() + ORIGIN + x * CELL;
	}

	private double cellZ0(int z) {
		return pos.getZ() + ORIGIN + z * CELL;
	}

	private double surfaceY(BoardBlockEntity be, int x, int z) {
		return pos.getY() + TerrainMesher.surface(be.tileAt(x, z), be.heightAt(x, z));
	}

	/** Cell under the mouse as {x, z}: the nearest terrain column hit by the mouse ray, or null. */
	private int[] pickCell(BoardBlockEntity be, double mx, double my) {
		Vec3 d = rayDir(mx, my);
		int[] best = null;
		double bestT = Double.MAX_VALUE;
		double baseY = pos.getY() + BoardRenderer.BASE;
		for (int z = 0; z < BoardBlockEntity.SIZE; z++) {
			for (int x = 0; x < BoardBlockEntity.SIZE; x++) {
				double x0 = cellX0(x), z0 = cellZ0(z);
				double t = rayBox(camPos, d, x0, baseY, z0, x0 + CELL, surfaceY(be, x, z), z0 + CELL);
				if (t >= 0 && t < bestT) {
					bestT = t;
					best = new int[]{x, z};
				}
			}
		}
		return best;
	}

	/** Nearest miniature whose box is hit by the mouse ray (so clicking a head works). */
	private Token pickToken(BoardBlockEntity be, double mx, double my) {
		Vec3 d = rayDir(mx, my);
		Token best = null;
		double bestT = Double.MAX_VALUE;
		for (Token t : be.getTokens()) {
			double x0 = cellX0(t.x()), z0 = cellZ0(t.z()), y0 = surfaceY(be, t.x(), t.z());
			double m = CELL * 0.1;
			double tt = rayBox(camPos, d, x0 + m, y0, z0 + m, x0 + CELL - m, y0 + BoardRenderer.MINI_H, z0 + CELL - m);
			if (tt >= 0 && tt < bestT) {
				bestT = tt;
				best = t;
			}
		}
		return best;
	}

	private static double rayBox(Vec3 o, Vec3 d, double x0, double y0, double z0, double x1, double y1, double z1) {
		double tmin = 0, tmax = Double.MAX_VALUE;
		double[] oo = {o.x, o.y, o.z}, dd = {d.x, d.y, d.z}, lo = {x0, y0, z0}, hi = {x1, y1, z1};
		for (int i = 0; i < 3; i++) {
			if (Math.abs(dd[i]) < 1e-9) {
				if (oo[i] < lo[i] || oo[i] > hi[i]) return -1;
			} else {
				double t1 = (lo[i] - oo[i]) / dd[i], t2 = (hi[i] - oo[i]) / dd[i];
				if (t1 > t2) {
					double s = t1;
					t1 = t2;
					t2 = s;
				}
				tmin = Math.max(tmin, t1);
				tmax = Math.min(tmax, t2);
				if (tmin > tmax) return -1;
			}
		}
		return tmin;
	}

	private boolean overPanel(double mx) {
		return mx >= panelX - 6;
	}

	// ---------------------------------------------------------------- panel layout

	private static final class Entry {
		final String label;
		final Kind kind;
		final int value;
		final int swatch;

		Entry(String label, Kind kind, int value, int swatch) {
			this.label = label;
			this.kind = kind;
			this.value = value;
			this.swatch = swatch;
		}
	}

	private List<Entry> buildEntries() {
		List<Entry> l = new java.util.ArrayList<>();
		for (int i = 0; i < BoardBlockEntity.TILES; i++) {
			l.add(new Entry(TerrainMesher.TILE_NAMES[i], Kind.TILE, i, 0xFF000000 | TerrainMesher.TILE_RGB[i]));
		}
		l.add(new Entry("Subir", Kind.RAISE, 0, 0));
		l.add(new Entry("Baixar", Kind.LOWER, 0, 0));
		for (int i = 0; i < BoardBlockEntity.PROPS; i++) {
			l.add(new Entry(TerrainMesher.PROP_NAMES[i], Kind.PROP, i, 0));
		}
		return l;
	}

	private static final int TAB_Y = 8, LIST_Y = 36;

	private boolean inRow(double mx, double my, int i, int y0) {
		int y = y0 + i * ROW;
		return mx >= panelX && mx < panelX + PANEL_W && my >= y && my < y + ROW - 2;
	}

	/** Build-tab entries are laid out in two columns. */
	private boolean inBuildCell(double mx, double my, int i) {
		int x = panelX + (i % 2) * (COL_W + 2), y = LIST_Y + (i / 2) * BROW;
		return mx >= x && mx < x + COL_W && my >= y && my < y + BROW - 2;
	}

	private int buttonsY() {
		return this.height - 3 * ROW - 6;
	}

	private boolean handlePanelClick(double mx, double my, BoardBlockEntity be) {
		// tabs
		int tw = (PANEL_W - 4) / 2;
		if (my >= TAB_Y && my < TAB_Y + 18) {
			if (mx >= panelX && mx < panelX + tw) {
				mode = Mode.MINIS;
				UiKit.click();
			} else if (mx >= panelX + tw + 4 && mx < panelX + PANEL_W) {
				mode = Mode.BUILD;
				UiKit.click();
			}
			return true;
		}
		// list
		if (mode == Mode.MINIS) {
			List<MiniData> roster = be.getRoster();
			for (int i = 0; i < roster.size(); i++) {
				if (inRow(mx, my, i, LIST_Y)) {
					slot = i;
					UiKit.click();
					return true;
				}
			}
		} else {
			List<Entry> entries = buildEntries();
			for (int i = 0; i < entries.size(); i++) {
				if (inBuildCell(mx, my, i)) {
					tool = entries.get(i).kind;
					toolValue = entries.get(i).value;
					UiKit.click();
					return true;
				}
			}
		}
		// bottom buttons
		int by = buttonsY();
		if (inRow(mx, my, 0, by)) {
			UiKit.click();
			if (mode == Mode.MINIS) {
				send(BoardActionPayload.of(pos, BoardActionPayload.CLEAR, 0, 0, 0));
			} else {
				send(BoardActionPayload.of(pos, BoardActionPayload.RESET_MAP, 0, 0, 0));
			}
			return true;
		}
		if (mode == Mode.BUILD && inRow(mx, my, 1, by)) {
			UiKit.click();
			int fillTile = tool == Kind.TILE ? toolValue : 0;
			send(BoardActionPayload.of(pos, BoardActionPayload.FILL, 0, 0, fillTile));
			return true;
		}
		if (inRow(mx, my, 2, by)) {
			UiKit.click();
			this.onClose();
			return true;
		}
		return true;
	}

	// ---------------------------------------------------------------- map painting

	private void paintAt(BoardBlockEntity be, double mx, double my) {
		int[] cell = pickCell(be, mx, my);
		if (cell == null) return;
		if (cell[0] == lastPaintX && cell[1] == lastPaintZ) return;
		lastPaintX = cell[0];
		lastPaintZ = cell[1];
		applyTool(be, cell[0], cell[1]);
	}

	private void applyTool(BoardBlockEntity be, int x, int z) {
		int t = be.tileAt(x, z), h = be.heightAt(x, z), p = be.propAt(x, z);
		switch (tool) {
			case TILE -> t = toolValue;
			case RAISE -> h = Math.min(BoardBlockEntity.MAX_HEIGHT, h + 1);
			case LOWER -> h = Math.max(0, h - 1);
			case PROP -> p = toolValue;
		}
		send(BoardActionPayload.of(pos, BoardActionPayload.SET_CELL, x, z, BoardBlockEntity.pack(t, h, p)));
	}

	// ---------------------------------------------------------------- input

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		BoardBlockEntity be = board();
		if (be == null) return false;
		double mx = event.x(), my = event.y();
		int button = event.button();

		if (overPanel(mx)) {
			return button == 0 && handlePanelClick(mx, my, be);
		}

		if (button == 0) {
			if (mode == Mode.MINIS) {
				Token t = pickToken(be, mx, my);
				if (t != null) {
					dragId = t.id();
				} else if (slot < be.getRoster().size()) {
					int[] cell = pickCell(be, mx, my);
					if (cell != null) send(BoardActionPayload.of(pos, BoardActionPayload.ADD, cell[0], cell[1], slot));
				}
			} else {
				painting = true;
				lastPaintX = lastPaintZ = -1;
				paintAt(be, mx, my);
			}
			return true;
		}
		if (button == 1) {
			rightDown = true;
			rightMoved = false;
			rightX = mx;
			rightY = my;
			return true;
		}
		return false;
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		if (event.button() == 1 && rightDown) {
			azim += dx * 0.01;
			elev = Mth.clamp(elev + dy * 0.01, 0.15, 1.5);
			if (Math.abs(event.x() - rightX) + Math.abs(event.y() - rightY) > 4) rightMoved = true;
			updateCamera();
			return true;
		}
		if (event.button() == 0 && painting && mode == Mode.BUILD) {
			BoardBlockEntity be = board();
			if (be != null && !overPanel(event.x())) paintAt(be, event.x(), event.y());
			return true;
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		double mx = event.x(), my = event.y();
		if (event.button() == 1 && rightDown) {
			rightDown = false;
			BoardBlockEntity be = board();
			if (!rightMoved && be != null) {
				if (mode == Mode.MINIS) {
					Token t = pickToken(be, mx, my);
					if (t != null) send(BoardActionPayload.of(pos, BoardActionPayload.REMOVE, 0, 0, t.id()));
				} else {
					// right click in the map tab clears the prop on that cell
					int[] cell = pickCell(be, mx, my);
					if (cell != null && be.propAt(cell[0], cell[1]) != 0) {
						int x = cell[0], z = cell[1];
						send(BoardActionPayload.of(pos, BoardActionPayload.SET_CELL, x, z,
								BoardBlockEntity.pack(be.tileAt(x, z), be.heightAt(x, z), 0)));
					}
				}
			}
			return true;
		}
		if (event.button() == 0 && painting) {
			painting = false;
			lastPaintX = lastPaintZ = -1;
			return true;
		}
		if (event.button() == 0 && dragId >= 0) {
			BoardBlockEntity be = board();
			Token t = be == null ? null : be.tokenById(dragId);
			int[] cell = be == null ? null : pickCell(be, mx, my);
			if (t != null && cell != null && (cell[0] != t.x() || cell[1] != t.z())) {
				send(BoardActionPayload.of(pos, BoardActionPayload.MOVE, cell[0], cell[1], dragId));
			}
			dragId = -1;
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		dist = Mth.clamp(dist - scrollY * 0.15, 0.8, 5.0);
		updateCamera();
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		if (event.key() == InputConstants.KEY_R && mode == Mode.MINIS) {
			BoardBlockEntity be = board();
			Minecraft mc = Minecraft.getInstance();
			if (be != null) {
				int id = dragId;
				if (id < 0) {
					Token t = pickToken(be, mc.mouseHandler.getScaledXPos(mc.getWindow()),
							mc.mouseHandler.getScaledYPos(mc.getWindow()));
					if (t != null) id = t.id();
				}
				if (id >= 0) send(BoardActionPayload.of(pos, BoardActionPayload.ROTATE, 0, 0, id));
			}
			return true;
		}
		return super.keyPressed(event);
	}

	// ---------------------------------------------------------------- render

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		// no blur / dimming: we want to see the world (and the board) clearly
	}

	@Override
	public void tick() {
		updateCamera();
	}

	private void outlineCell(GuiGraphicsExtractor g, BoardBlockEntity be, int cx, int cz, int color) {
		double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
		double y = surfaceY(be, cx, cz);
		for (int i = 0; i < 4; i++) {
			double[] s = project(new Vec3(cellX0(cx) + (i & 1) * CELL, y, cellZ0(cz) + (i >> 1) * CELL));
			if (s == null) return;
			minX = Math.min(minX, s[0]);
			maxX = Math.max(maxX, s[0]);
			minY = Math.min(minY, s[1]);
			maxY = Math.max(maxY, s[1]);
		}
		g.outline((int) minX, (int) minY, Math.max(2, (int) (maxX - minX)), Math.max(2, (int) (maxY - minY)), color);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		BoardBlockEntity be = board();
		if (be == null) {
			this.onClose();
			return;
		}
		updateCamera();
		super.extractRenderState(g, mouseX, mouseY, delta);

		// hover / drag target highlight
		if (!overPanel(mouseX) && !rightDown) {
			int[] cell = pickCell(be, mouseX, mouseY);
			if (mode == Mode.MINIS && dragId >= 0) {
				if (cell != null) outlineCell(g, be, cell[0], cell[1], 0xFF55FF55);
			} else if (mode == Mode.MINIS) {
				Token t = pickToken(be, mouseX, mouseY);
				if (t != null) outlineCell(g, be, t.x(), t.z(), 0xFFFFFF55);
				else if (cell != null) outlineCell(g, be, cell[0], cell[1], 0xFFFFFFFF);
			} else if (cell != null) {
				outlineCell(g, be, cell[0], cell[1], 0xFFFFD98A);
			}
		}

		drawPanel(g, be, mouseX, mouseY);
		drawHelp(g);
	}

	private void drawPanel(GuiGraphicsExtractor g, BoardBlockEntity be, int mx, int my) {
		g.fill(panelX - 8, 0, this.width, this.height, 0xCC120A04);
		g.fill(panelX - 8, 0, panelX - 7, this.height, 0xFF5C3C20);

		int tw = (PANEL_W - 4) / 2;
		UiKit.button(g, this.font, panelX, TAB_Y, tw, 18, "Minis",
				UiKit.in(mx, my, panelX, TAB_Y, tw, 18), mode == Mode.MINIS, true);
		UiKit.button(g, this.font, panelX + tw + 4, TAB_Y, tw, 18, "Mapa",
				UiKit.in(mx, my, panelX + tw + 4, TAB_Y, tw, 18), mode == Mode.BUILD, true);

		if (mode == Mode.MINIS) {
			List<MiniData> roster = be.getRoster();
			if (roster.isEmpty()) {
				g.text(this.font, "Sem miniaturas.", panelX, LIST_Y + 4, 0xFFCCCCCC, false);
			}
			for (int i = 0; i < roster.size(); i++) {
				int y = LIST_Y + i * ROW;
				boolean sel = i == slot;
				boolean hov = inRow(mx, my, i, LIST_Y);
				g.fill(panelX, y, panelX + PANEL_W, y + ROW - 2, sel ? 0xFF5C3C20 : hov ? 0xFF3A2916 : 0xFF241810);
				SkinPreview.head(g, roster.get(i), panelX + 2, y + 1, 16);
				g.text(this.font, UiKit.fit(this.font, roster.get(i).name(), PANEL_W - 26), panelX + 22, y + 5,
						sel ? UiKit.GOLD : UiKit.CREAM, false);
				if (sel) g.outline(panelX, y, PANEL_W, ROW - 2, UiKit.GOLD);
			}
		} else {
			List<Entry> entries = buildEntries();
			for (int i = 0; i < entries.size(); i++) {
				Entry e = entries.get(i);
				int x = panelX + (i % 2) * (COL_W + 2), y = LIST_Y + (i / 2) * BROW;
				boolean sel = e.kind == tool && e.value == toolValue;
				boolean hov = inBuildCell(mx, my, i);
				g.fill(x, y, x + COL_W, y + BROW - 2, sel ? 0xFF5C3C20 : hov ? 0xFF3A2916 : 0xFF241810);
				if (e.swatch != 0) {
					g.fill(x + 3, y + 2, x + 13, y + BROW - 4, e.swatch);
					g.outline(x + 3, y + 2, 10, BROW - 6, 0xFF000000);
				}
				g.text(this.font, UiKit.fit(this.font, e.label, COL_W - (e.swatch != 0 ? 18 : 8)),
						x + (e.swatch != 0 ? 17 : 4), y + 4, sel ? UiKit.GOLD : UiKit.CREAM, false);
				if (sel) g.outline(x, y, COL_W, BROW - 2, UiKit.GOLD);
			}
		}

		int by = buttonsY();
		UiKit.button(g, this.font, panelX, by, PANEL_W, ROW - 2, mode == Mode.MINIS ? "Limpar minis" : "Resetar mapa",
				inRow(mx, my, 0, by), false, true);
		if (mode == Mode.BUILD) {
			UiKit.button(g, this.font, panelX, by + ROW, PANEL_W, ROW - 2, "Preencher tudo",
					inRow(mx, my, 1, by), false, true);
		}
		UiKit.button(g, this.font, panelX, by + 2 * ROW, PANEL_W, ROW - 2, "Fechar", inRow(mx, my, 2, by), true, true);
	}

	private void drawHelp(GuiGraphicsExtractor g) {
		String[] lines = mode == Mode.MINIS
				? new String[]{"Esq: por / arrastar miniatura", "R: girar a miniatura", "Dir: remover",
				"Caixa de Miniaturas + botão direito", "no tabuleiro troca os modelos"}
				: new String[]{"Esq (arrastar): pintar com a ferramenta", "Dir: remover objeto da casa",
				"Preencher tudo usa o terreno escolhido"};
		int h = lines.length * 11 + 6;
		int y = this.height - h - 4;
		g.fill(4, y, 4 + 190, y + h, 0x99000000);
		for (int i = 0; i < lines.length; i++) {
			g.text(this.font, lines[i], 8, y + 4 + i * 11, 0xFFCCCCCC, false);
		}
		g.text(this.font, "Dir+arrastar: girar camera   Roda: zoom", 8, y - 12, 0xFFAAAAAA, false);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
