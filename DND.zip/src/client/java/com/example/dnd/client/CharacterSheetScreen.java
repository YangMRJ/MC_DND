package com.example.dnd.client;

import com.example.dnd.network.SaveSheetPayload;
import com.example.dnd.sheet.CharacterSheetData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

/**
 * Editable character sheet drawn on aged parchment.
 * Closing the screen (Esc or "Salvar") saves; "Cancelar" throws the changes away.
 */
public class CharacterSheetScreen extends Screen {
	private static final int W = 356;
	private static final int H = 236;
	private static final int FIELD_H = 14;

	private static final int INK = 0xFF2B1D0E;
	private static final int LABEL = 0xFF6B4E2A;
	private static final int ORNAMENT = 0xFF8A6232;

	private static final Identifier BG = UiKit.gui("sheet_bg");
	private static final Identifier ICON_HEART = UiKit.gui("icon_heart");
	private static final Identifier ICON_SHIELD = UiKit.gui("icon_shield");
	private static final Identifier ICON_BOOT = UiKit.gui("icon_boot");

	private static final String[] ABILITY_LABELS = {"FOR", "DES", "CON", "INT", "SAB", "CAR"};
	private static final String[] ABILITY_FULL = {"Força", "Destreza", "Constituição", "Inteligência", "Sabedoria", "Carisma"};

	// Layout (relative to the top-left corner of the sheet).
	private static final int STRIP_Y = 34, CARD_W = 52, CARD_H = 34, CARD_STEP = 56, MARGIN = 12;
	private static final int ID_Y1 = 73, ID_Y2 = 98, ID_Y3 = 123;
	private static final int RIGHT_X = 192;
	private static final int NOTES_LABEL_Y = 152, NOTES_Y = 162, NOTES_H = 38;
	private static final int BUTTON_Y = 204, BUTTON_W = 100, BUTTON_H = 20;

	private record Label(String text, int x, int y, int color) {
	}

	private record Rect(int x, int y, int w, int h) {
	}

	/** An ability card: the score box is a real EditBox, the modifier is computed from it. */
	private record AbilityCard(String key, int index, int x, int y) {
	}

	/** A dark leather card holding an icon and a title (vitals). */
	private record VitalCard(Identifier icon, String title, int x, int y, int w, int h) {
	}

	private final InteractionHand hand;
	/** Current text of every field; survives window resizes (init() runs again on resize). */
	private final Map<String, String> values = new LinkedHashMap<>();
	private final Map<String, String> initialValues = new LinkedHashMap<>();
	private final List<Label> labels = new ArrayList<>();
	private final List<Rect> backdrops = new ArrayList<>();
	private final List<AbilityCard> abilityCards = new ArrayList<>();
	private final List<VitalCard> vitalCards = new ArrayList<>();
	private int left;
	private int top;
	private boolean discard;

	/** Id do item pousado na mesa que esta sendo editado, ou -1 quando a ficha esta na mao. */
	private final int entityId;

	public CharacterSheetScreen(ItemStack stack, InteractionHand hand) {
		this(stack, hand, -1);
	}

	/** Ficha pousada na mesa. */
	public CharacterSheetScreen(ItemStack stack, int entityId) {
		this(stack, InteractionHand.MAIN_HAND, entityId);
	}

	private CharacterSheetScreen(ItemStack stack, InteractionHand hand, int entityId) {
		super(Component.literal("Ficha de Personagem"));
		this.hand = hand;
		this.entityId = entityId;
		CompoundTag saved = CharacterSheetData.read(stack);
		for (String key : saved.keySet()) {
			values.put(key, saved.getStringOr(key, ""));
		}
		initialValues.putAll(values);
	}

	@Override
	protected void init() {
		left = (this.width - W) / 2;
		top = Math.max(4, (this.height - H) / 2);
		labels.clear();
		backdrops.clear();
		abilityCards.clear();
		vitalCards.clear();

		// ---- ability strip -------------------------------------------------------------
		for (int i = 0; i < CharacterSheetData.ABILITIES.length; i++) {
			String key = CharacterSheetData.ABILITIES[i];
			int cx = left + MARGIN + i * CARD_STEP;
			int cy = top + STRIP_Y;
			abilityCards.add(new AbilityCard(key, i, cx, cy));
			EditBox box = addBox(key, ABILITY_LABELS[i], cx + 12, cy + 21, 28, 12);
			backdrops.add(new Rect(cx + 12, cy + 21, 28, 12));
			box.setCentered(true);
		}

		// ---- identity (left column) ----------------------------------------------------
		int lx = left + MARGIN;
		EditBox nameBox = addField(CharacterSheetData.NAME, "Nome", lx, top + ID_Y1, 128);
		addField(CharacterSheetData.LEVEL, "N\u00edvel", lx + 132, top + ID_Y1, 42);
		addField(CharacterSheetData.CLASS, "Classe", lx, top + ID_Y2, 85);
		addField(CharacterSheetData.RACE, "Ra\u00e7a", lx + 89, top + ID_Y2, 85);
		addField(CharacterSheetData.BACKGROUND, "Antecedente", lx, top + ID_Y3, 85);
		addField(CharacterSheetData.ALIGNMENT, "Tend\u00eancia", lx + 89, top + ID_Y3, 85);

		// ---- vitals (right column) -----------------------------------------------------
		int rx = left + RIGHT_X;
		vitalCards.add(new VitalCard(ICON_HEART, "Pontos de Vida", rx, top + 73, 152, 37));
		addBox(CharacterSheetData.HP, "PV", rx + 20, top + 73 + 17, 50, FIELD_H);
		backdrops.add(new Rect(rx + 20, top + 73 + 17, 50, FIELD_H));
		addBox(CharacterSheetData.MAX_HP, "PV M\u00e1x.", rx + 86, top + 73 + 17, 50, FIELD_H);
		backdrops.add(new Rect(rx + 86, top + 73 + 17, 50, FIELD_H));

		vitalCards.add(new VitalCard(ICON_SHIELD, "CA", rx, top + 113, 74, 34));
		addBox(CharacterSheetData.AC, "CA", rx + 9, top + 113 + 17, 56, FIELD_H);
		backdrops.add(new Rect(rx + 9, top + 113 + 17, 56, FIELD_H));

		vitalCards.add(new VitalCard(ICON_BOOT, "Desloc.", rx + 78, top + 113, 74, 34));
		addBox(CharacterSheetData.SPEED, "Desloc.", rx + 78 + 9, top + 113 + 17, 56, FIELD_H);
		backdrops.add(new Rect(rx + 78 + 9, top + 113 + 17, 56, FIELD_H));

		// ---- notes (multi-line) --------------------------------------------------------
		int notesY = top + NOTES_Y;
		labels.add(new Label("Anota\u00e7\u00f5es", lx, top + NOTES_LABEL_Y, LABEL));
		backdrops.add(new Rect(lx, notesY, W - 2 * MARGIN, NOTES_H));
		MultiLineEditBox notes = MultiLineEditBox.builder()
				.setX(lx + 3)
				.setY(notesY + 2)
				.setPlaceholder(Component.literal("Equipamento, magias, hist\u00f3ria..."))
				.setTextColor(INK)
				.setTextShadow(false)
				.setCursorColor(INK)
				.setShowBackground(false)
				.build(this.font, W - 2 * MARGIN - 6, NOTES_H - 4, Component.literal("Anota\u00e7\u00f5es"));
		notes.setCharacterLimit(CharacterSheetData.maxLength(CharacterSheetData.NOTES));
		notes.setValue(values.getOrDefault(CharacterSheetData.NOTES, ""));
		notes.setValueListener(v -> values.put(CharacterSheetData.NOTES, v));
		this.addRenderableWidget(notes);

		this.setInitialFocus(nameBox);
	}

	/** A labelled single-line field: small label above, box below. */
	private EditBox addField(String key, String label, int x, int y, int w) {
		labels.add(new Label(label, x, y, LABEL));
		backdrops.add(new Rect(x, y + 10, w, FIELD_H));
		return addBox(key, label, x, y + 10, w, FIELD_H);
	}

	/** Borderless edit box; the parchment backdrop is drawn separately. */
	private EditBox addBox(String key, String name, int x, int y, int w, int h) {
		EditBox box = new EditBox(this.font, x + 3, y, w - 6, h, Component.literal(name));
		box.setBordered(false);
		box.setTextColor(INK);
		box.setTextShadow(false);
		box.setMaxLength(CharacterSheetData.maxLength(key));
		box.setValue(values.getOrDefault(key, ""));
		box.setResponder(v -> values.put(key, v));
		this.addRenderableWidget(box);
		return box;
	}

	// ------------------------------------------------------------------ input

	private int saveX() {
		return left + W / 2 - BUTTON_W - 5;
	}

	private int cancelX() {
		return left + W / 2 + 5;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (super.mouseClicked(event, doubleClick)) return true;
		if (event.button() != 0) return false;
		int mx = (int) event.x(), my = (int) event.y();
		if (UiKit.in(mx, my, saveX(), top + BUTTON_Y, BUTTON_W, BUTTON_H)) {
			UiKit.click();
			this.onClose();
			return true;
		}
		if (UiKit.in(mx, my, cancelX(), top + BUTTON_Y, BUTTON_W, BUTTON_H)) {
			UiKit.click();
			this.cancel();
			return true;
		}
		return false;
	}

	// ------------------------------------------------------------------ rendering

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		super.extractBackground(g, mouseX, mouseY, delta);

		// Soft drop shadow, then the parchment itself.
		g.fill(left + 3, top + 4, left + W + 3, top + H + 4, 0x55000000);
		UiKit.image(g, BG, left, top, W, H);

		Component title = Component.literal("Ficha de Personagem").withStyle(ChatFormatting.BOLD);
		g.text(this.font, title, left + (W - this.font.width(title)) / 2, top + 16, 0xFFFFE9A8, true);

		// Ability cards.
		for (AbilityCard c : abilityCards) {
			g.fill(c.x(), c.y(), c.x() + CARD_W, c.y() + CARD_H, 0xFF2A0F0A);
			g.fillGradient(c.x() + 1, c.y() + 1, c.x() + CARD_W - 1, c.y() + CARD_H - 1, 0xFF7E2C24, 0xFF4A1610);
			g.outline(c.x() + 1, c.y() + 1, CARD_W - 2, CARD_H - 2, 0xFFB8893F);
			String label = ABILITY_LABELS[c.index()];
			g.text(this.font, label, c.x() + (CARD_W - this.font.width(label)) / 2, c.y() + 3, UiKit.GOLD_DIM, false);

			String modifier = modifierText(values.getOrDefault(c.key(), ""));
			boolean empty = modifier.isEmpty();
			String shown = empty ? "--" : modifier;
			float scale = 1.5F;
			float tw = this.font.width(shown) * scale;
			UiKit.scaledText(g, this.font, shown, c.x() + (CARD_W - tw) / 2.0F, c.y() + 10, scale, empty ? 0xFF9A7A66 : 0xFFFFF1C8);
		}

		// Vital cards (dark leather with an icon).
		for (VitalCard v : vitalCards) {
			g.fill(v.x(), v.y(), v.x() + v.w(), v.y() + v.h(), 0xFF1E1209);
			g.fillGradient(v.x() + 1, v.y() + 1, v.x() + v.w() - 1, v.y() + v.h() - 1, 0xFF4A3220, 0xFF33200F);
			g.outline(v.x() + 1, v.y() + 1, v.w() - 2, v.h() - 2, 0xFF9C7A45);
			UiKit.image(g, v.icon(), v.x() + 5, v.y() + 3, 16, 16);
			g.text(this.font, v.title(), v.x() + 25, v.y() + 7, UiKit.CREAM, false);
		}
		drawSlash(g);
		drawHealthBar(g);

		// Faint vertical divider between identity and vitals.
		g.fill(left + 189, top + ID_Y1, left + 190, top + ID_Y3 + 24, 0x558A6232);

		// Field backdrops + labels.
		for (Rect r : backdrops) {
			UiKit.paperInset(g, r.x(), r.y(), r.w(), r.h());
		}
		for (Label l : labels) {
			g.text(this.font, l.text(), l.x(), l.y(), l.color(), false);
		}

		// Ornamental line next to the notes label.
		int notesLineX = left + MARGIN + this.font.width("Anota\u00e7\u00f5es") + 6;
		UiKit.divider(g, notesLineX, top + NOTES_LABEL_Y + 4, left + W - MARGIN - notesLineX, ORNAMENT);
	}

	/** The "/" between current and maximum hit points. */
	private void drawSlash(GuiGraphicsExtractor g) {
		int x = left + RIGHT_X + 78;
		int y = top + 73 + 17 + 3;
		g.text(this.font, "/", x, y, UiKit.GOLD, false);
	}

	/** Thin bar at the bottom of the hit point card, green -> amber -> red as the character gets hurt. */
	private void drawHealthBar(GuiGraphicsExtractor g) {
		int x = left + RIGHT_X + 5, y = top + 73 + 32, w = 142;
		g.fill(x, y, x + w, y + 3, 0xFF120A04);
		try {
			int hp = Integer.parseInt(values.getOrDefault(CharacterSheetData.HP, "").trim());
			int max = Integer.parseInt(values.getOrDefault(CharacterSheetData.MAX_HP, "").trim());
			if (max > 0) {
				float ratio = Math.max(0.0F, Math.min(1.0F, (float) hp / max));
				int fill = Math.round((w - 2) * ratio);
				int color = ratio > 0.5F ? 0xFF4CAF50 : ratio > 0.25F ? 0xFFE0A030 : 0xFFD03030;
				if (fill > 0) g.fill(x + 1, y + 1, x + 1 + fill, y + 2, color);
			}
		} catch (NumberFormatException ignored) {
			// no bar until both numbers are filled in
		}
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		super.extractRenderState(g, mouseX, mouseY, delta);

		int by = top + BUTTON_Y;
		UiKit.button(g, this.font, saveX(), by, BUTTON_W, BUTTON_H, "Salvar",
				UiKit.in(mouseX, mouseY, saveX(), by, BUTTON_W, BUTTON_H), true, true);
		UiKit.button(g, this.font, cancelX(), by, BUTTON_W, BUTTON_H, "Cancelar",
				UiKit.in(mouseX, mouseY, cancelX(), by, BUTTON_W, BUTTON_H), false, true);

		// Tooltip with the full ability name when hovering a card.
		for (AbilityCard c : abilityCards) {
			if (UiKit.in(mouseX, mouseY, c.x(), c.y(), CARD_W, 20)) {
				g.setTooltipForNextFrame(this.font, Component.literal(ABILITY_FULL[c.index()]), mouseX, mouseY);
			}
		}
	}

	/** D&D ability modifier: (score - 10) / 2, rounded down. Empty when the score is not a number. */
	private static String modifierText(String score) {
		try {
			int mod = Math.floorDiv(Integer.parseInt(score.trim()) - 10, 2);
			return (mod >= 0 ? "+" : "") + mod;
		} catch (NumberFormatException e) {
			return "";
		}
	}

	private void cancel() {
		discard = true;
		super.onClose();
	}

	@Override
	public void onClose() {
		if (!discard && !values.equals(initialValues)) {
			CompoundTag sheet = new CompoundTag();
			for (Map.Entry<String, String> entry : values.entrySet()) {
				sheet.putString(entry.getKey(), entry.getValue());
			}
			ClientPlayNetworking.send(new SaveSheetPayload(hand == InteractionHand.MAIN_HAND, entityId, sheet));
		}
		super.onClose();
	}
}
