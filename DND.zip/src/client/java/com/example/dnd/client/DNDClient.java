package com.example.dnd.client;

import com.example.dnd.ModBlockEntities;
import com.example.dnd.block.BoardBlock;
import com.example.dnd.DND;
import com.example.dnd.ModEntities;
import com.example.dnd.ModItems;
import com.example.dnd.client.render.BoardRenderer;
import com.example.dnd.client.render.MiniBoxSpecialRenderer;
import com.example.dnd.client.render.MiniFigureRenderer;
import com.example.dnd.client.render.MiniFigureSpecialRenderer;
import com.example.dnd.client.render.PlacedItemRenderer;
import com.example.dnd.entity.PlacedItemEntity;
import com.example.dnd.network.MiniBoxPayload;
import com.example.dnd.network.MiniBoxViewPayload;
import com.example.dnd.sheet.SheetItems;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.world.InteractionHand;
import com.example.dnd.item.DiceBoxItem;
import com.example.dnd.item.MiniBoxItem;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.special.SpecialModelRenderers;

public class DNDClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		BoardBlock.clientOpener = pos -> Minecraft.getInstance().gui.setScreen(new BoardScreen(pos));
		MiniBoxItem.clientOpener = (stack, hand) -> Minecraft.getInstance().gui.setScreen(new MiniatureBoxScreen(
				hand == InteractionHand.MAIN_HAND ? MiniBoxPayload.TARGET_MAIN : MiniBoxPayload.TARGET_OFF));
		DiceBoxItem.clientOpener = player -> Minecraft.getInstance().gui.setScreen(new DiceRollerScreen());
		BlockEntityRenderers.register(ModBlockEntities.BOARD, BoardRenderer::new);

		// a tela da caixa recebe do servidor a aba e a pagina que esta mostrando
		ClientPlayNetworking.registerGlobalReceiver(MiniBoxViewPayload.TYPE,
				(payload, context) -> MiniatureBoxScreen.view = payload);

		// itens pousados na mesa: desenho e uso (abrir a tela do item sem ele estar no inventario)
		EntityRenderers.register(ModEntities.PLACED_ITEM, PlacedItemRenderer::new);
		PlacedItemEntity.clientOpener = placed -> {
			var stack = placed.getStack();
			Minecraft mc = Minecraft.getInstance();
			if (stack.is(ModItems.DICE_BOX)) {
				mc.gui.setScreen(new DiceRollerScreen());
			} else if (stack.is(ModItems.MINIATURE_BOX)) {
				mc.gui.setScreen(new MiniatureBoxScreen(MiniBoxPayload.TARGET_ENTITY + placed.getId()));
			} else if (stack.is(SheetItems.CHARACTER_SHEET)) {
				mc.gui.setScreen(new CharacterSheetScreen(stack, placed.getId()));
			}
		};

		// miniatura em pe no mundo
		EntityRenderers.register(ModEntities.MINI_FIGURE, MiniFigureRenderer::new);
		// item da miniatura: desenha a skin dela (tipo usado em assets/dnd/items/miniature.json)
		SpecialModelRenderers.ID_MAPPER.put(DND.id("mini_figure"), MiniFigureSpecialRenderer.Unbaked.CODEC);
		// caixa de miniaturas na mao: desenha as minis que ela carrega
		SpecialModelRenderers.ID_MAPPER.put(DND.id("mini_box"), MiniBoxSpecialRenderer.Unbaked.CODEC);
	}
}
