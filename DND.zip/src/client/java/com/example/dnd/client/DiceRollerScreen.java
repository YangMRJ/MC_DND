package com.example.dnd.client;

import com.example.dnd.network.DiceRollPayload;
import com.example.dnd.sheet.CharacterSheetData;
import com.example.dnd.sheet.SheetItems;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

/**
 * Dice tray: an inventory-like screen with clickable dice sprites.
 * Left click on a die adds one, right click removes one, shift = 5 at a time, middle click or the wheel also work.
 */
public class DiceRollerScreen extends Screen {
	private static final int[] SIDES = {4, 6, 8, 10, 12, 20, 100};
	private static final String[] ABILITIES = {"str", "dex", "con", "int", "wis", "cha"};
	private static final String[] ABILITY_NAMES = {"FOR", "DES", "CON", "INT", "SAB", "CAR"};
	private static final String[] ABILITY_FULL = {"Força", "Destreza", "Constituição", "Inteligência", "Sabedoria", "Carisma"};

	private static final int W = 320, H = 220;
	private static final int MAX_PER_DIE = 20, MAX_TOTAL = 50;
	private static final int SLOT_W = 40, SLOT_H = 44;
	private static final int CLEAR_TILE = 7; // 8th tile of the grid is the "Limpar" action

	private static final Identifier PANEL = UiKit.gui("dice_panel");
	private static final Identifier SLOT = UiKit.gui("slot");
	private static final Identifier SLOT_HOVER = UiKit.gui("slot_hover");
	private static final Identifier SLOT_ACTIVE = UiKit.gui("slot_active");
	private static final Identifier[] DIE_SPRITES = new Identifier[SIDES.length];

	static {
		for (int i = 0; i < SIDES.length; i++) {
			DIE_SPRITES[i] = UiKit.gui("dice_d" + SIDES[i]);
		}
	}

	private final int[] quantities = new int[SIDES.length];
	private final List<Integer> sheetSlots = new ArrayList<>();
	private int selectedSheetIndex;
	/** -1 = no ability modifier. */
	private int abilityIndex = -1;
	private int left, top;
	private String error = "";

	public DiceRollerScreen() {
		super(Component.literal("Caixa de Dados"));
	}

	@Override
	protected void init() {
		left = (this.width - W) / 2;
		top = (this.height - H) / 2;
		refreshSheetSlots();
	}

	// ------------------------------------------------------------------ layout

	private int slotX(int i) { return left + 16 + (i % 4) * 44; }
	private int slotY(int i) { return top + 46 + (i / 4) * 48; }

	private int sheetX() { return left + 204; }
	private int sheetY() { return top + 46; }
	private static final int SHEET_W = 100, SHEET_H = 44;

	private int abilityX(int i) { return left + 204 + (i % 3) * 34; }
	private int abilityY(int i) { return top + 106 + (i / 3) * 18; }
	private static final int ABILITY_W = 31, ABILITY_H = 16;

	private int rollX() { return left + 16; }
	private int quickX() { return left + 172; }
	private int closeX() { return left + 258; }
	private int buttonsY() { return top + 176; }

	// ------------------------------------------------------------------ sheet handling

	private void refreshSheetSlots() {
		int previous = sheetSlots.isEmpty() ? -1 : sheetSlots.get(Math.min(selectedSheetIndex, sheetSlots.size() - 1));
		sheetSlots.clear();
		sheetSlots.add(-1); // rolling without a sheet is always available
		if (Minecraft.getInstance().player != null) {
			var inventory = Minecraft.getInstance().player.getInventory();
			for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
				if (inventory.getItem(slot).is(SheetItems.CHARACTER_SHEET)) sheetSlots.add(slot);
			}
		}
		selectedSheetIndex = Math.max(0, sheetSlots.indexOf(previous));
	}

	private void cycleSheet(int direction) {
		refreshSheetSlots();
		int n = sheetSlots.size();
		selectedSheetIndex = ((selectedSheetIndex + direction) % n + n) % n;
		if (selectedSlot() < 0) abilityIndex = -1;
	}

	/** Inventory slot of the chosen sheet, or -1 for none. */
	private int selectedSlot() {
		return sheetSlots.isEmpty() ? -1 : sheetSlots.get(Math.min(selectedSheetIndex, sheetSlots.size() - 1));
	}

	private ItemStack selectedStack() {
		int slot = selectedSlot();
		if (slot < 0 || Minecraft.getInstance().player == null) return ItemStack.EMPTY;
		return Minecraft.getInstance().player.getInventory().getItem(slot);
	}

	private CompoundTag selectedSheet() {
		ItemStack stack = selectedStack();
		return stack.isEmpty() ? new CompoundTag() : CharacterSheetData.read(stack);
	}

	/** Ability modifier from the selected sheet, or null when there is none / the score is not a number. */
	private Integer modifierOf(int ability) {
		if (selectedSlot() < 0) return null;
		try {
			int score = Integer.parseInt(selectedSheet().getStringOr(ABILITIES[ability], "").trim());
			return Math.floorDiv(score - 10, 2);
		} catch (NumberFormatException e) {
			return null;
		}
	}

	private static String signed(int v) {
		return v >= 0 ? "+" + v : Integer.toString(v);
	}

	// ------------------------------------------------------------------ dice logic

	private int totalDice() {
		int total = 0;
		for (int q : quantities) total += q;
		return total;
	}

	private void changeDie(int index, int delta) {
		error = "";
		int next = quantities[index] + delta;
		next = Math.max(0, Math.min(MAX_PER_DIE, next));
		int others = totalDice() - quantities[index];
		next = Math.min(next, MAX_TOTAL - others);
		quantities[index] = Math.max(0, next);
	}

	private void clearAll() {
		error = "";
		java.util.Arrays.fill(quantities, 0);
	}

	private void roll() {
		error = "";
		int total = totalDice();
		if (total < 1) { error = "Escolha pelo menos um dado."; return; }
		if (total > MAX_TOTAL) { error = "O limite por rolagem é de 50 dados."; return; }
		StringBuilder encoded = new StringBuilder();
		for (int i = 0; i < quantities.length; i++) {
			if (i > 0) encoded.append(',');
			encoded.append(quantities[i]);
		}
		String ability = abilityIndex >= 0 && selectedSlot() >= 0 ? ABILITIES[abilityIndex] : "";
		ClientPlayNetworking.send(new DiceRollPayload(selectedSlot(), ability, encoded.toString()));
		this.onClose();
	}

	/** Shortcut: one d20 plus the chosen ability. */
	private void quickD20() {
		java.util.Arrays.fill(quantities, 0);
		quantities[5] = 1;
		roll();
	}

	private String formula() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < SIDES.length; i++) {
			if (quantities[i] == 0) continue;
			if (!sb.isEmpty()) sb.append(" + ");
			sb.append(quantities[i]).append('d').append(SIDES[i]);
		}
		if (sb.isEmpty()) return "";
		if (abilityIndex >= 0 && selectedSlot() >= 0) {
			Integer mod = modifierOf(abilityIndex);
			sb.append(" + ").append(ABILITY_NAMES[abilityIndex]).append(" (").append(signed(mod == null ? 0 : mod)).append(')');
		}
		return sb.toString();
	}

	// ------------------------------------------------------------------ input

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (super.mouseClicked(event, doubleClick)) return true;
		int mx = (int) event.x(), my = (int) event.y(), button = event.button();
		boolean shift = (event.modifiers() & 1) != 0;

		for (int i = 0; i < SIDES.length; i++) {
			if (UiKit.in(mx, my, slotX(i), slotY(i), SLOT_W, SLOT_H)) {
				if (button == 0) changeDie(i, shift ? 5 : 1);
				else if (button == 1) changeDie(i, shift ? -5 : -1);
				else if (button == 2) changeDie(i, -MAX_PER_DIE);
				else return false;
				UiKit.click();
				return true;
			}
		}
		if (UiKit.in(mx, my, slotX(CLEAR_TILE), slotY(CLEAR_TILE), SLOT_W, SLOT_H)) {
			clearAll();
			UiKit.click();
			return true;
		}
		if (UiKit.in(mx, my, sheetX(), sheetY(), SHEET_W, SHEET_H)) {
			cycleSheet(button == 1 ? -1 : 1);
			UiKit.click();
			return true;
		}
		if (selectedSlot() >= 0) {
			for (int i = 0; i < ABILITIES.length; i++) {
				if (UiKit.in(mx, my, abilityX(i), abilityY(i), ABILITY_W, ABILITY_H)) {
					abilityIndex = abilityIndex == i ? -1 : i; // click again to deselect
					UiKit.click();
					return true;
				}
			}
		}
		if (button != 0) return false;
		if (UiKit.in(mx, my, rollX(), buttonsY(), 150, 22)) { UiKit.click(); roll(); return true; }
		if (UiKit.in(mx, my, quickX(), buttonsY(), 80, 22)) { UiKit.click(); quickD20(); return true; }
		if (UiKit.in(mx, my, closeX(), buttonsY(), 46, 22)) { UiKit.click(); this.onClose(); return true; }
		return false;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		for (int i = 0; i < SIDES.length; i++) {
			if (UiKit.in((int) mouseX, (int) mouseY, slotX(i), slotY(i), SLOT_W, SLOT_H)) {
				if (scrollY != 0) changeDie(i, scrollY > 0 ? 1 : -1);
				return true;
			}
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		int key = event.key();
		if (key == 257 || key == 335) { // Enter / keypad Enter
			roll();
			return true;
		}
		return super.keyPressed(event);
	}

	// ------------------------------------------------------------------ rendering

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		super.extractBackground(g, mouseX, mouseY, delta);
		g.fill(left + 3, top + 4, left + W + 3, top + H + 4, 0x55000000); // sombra
		UiKit.image(g, PANEL, left, top, W, H);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		super.extractRenderState(g, mouseX, mouseY, delta);

		Component title = Component.literal("CAIXA DE DADOS").withStyle(ChatFormatting.BOLD);
		g.text(this.font, title, left + (W - this.font.width(title)) / 2, top + 11, 0xFFFFE9A8, true);

		sectionLabel(g, "DADOS", left + 16, top + 34, left + 188);
		sectionLabel(g, "FICHA", left + 204, top + 34, left + 304);
		sectionLabel(g, "ATRIBUTO", left + 204, top + 94, left + 304);

		List<Component> tooltip = null;

		// dice grid
		for (int i = 0; i < SIDES.length; i++) {
			int x = slotX(i), y = slotY(i);
			boolean hovered = UiKit.in(mouseX, mouseY, x, y, SLOT_W, SLOT_H);
			boolean active = quantities[i] > 0;
			UiKit.image(g, hovered ? SLOT_HOVER : active ? SLOT_ACTIVE : SLOT, x, y, SLOT_W, SLOT_H);
			UiKit.image(g, DIE_SPRITES[i], x + 8, y + 4 + (hovered ? -1 : 0), 24, 24);
			String label = "d" + SIDES[i];
			g.text(this.font, label, x + (SLOT_W - this.font.width(label)) / 2, y + 32, active ? UiKit.GOLD : UiKit.CREAM, false);
			if (active) {
				String n = Integer.toString(quantities[i]);
				int bw = Math.max(13, this.font.width(n) + 5);
				int bx = x + SLOT_W - bw - 1, by = y + 2;
				g.fill(bx, by, bx + bw, by + 11, 0xFF120A04);
				g.fill(bx + 1, by + 1, bx + bw - 1, by + 10, 0xFFB8362E);
				g.fill(bx + 1, by + 1, bx + bw - 1, by + 2, 0xFFE0705E);
				g.text(this.font, n, bx + (bw - this.font.width(n)) / 2 + 1, by + 2, 0xFFFFFFFF, false);
			}
			if (hovered) {
				tooltip = List.of(
						Component.literal("d" + SIDES[i]).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
						Component.literal("Clique esquerdo: +1").withStyle(ChatFormatting.GRAY),
						Component.literal("Clique direito: -1").withStyle(ChatFormatting.GRAY),
						Component.literal("Shift: de 5 em 5 · Roda do mouse também funciona").withStyle(ChatFormatting.DARK_GRAY));
			}
		}

		// "Limpar" tile
		{
			int x = slotX(CLEAR_TILE), y = slotY(CLEAR_TILE);
			boolean hovered = UiKit.in(mouseX, mouseY, x, y, SLOT_W, SLOT_H);
			UiKit.image(g, hovered ? SLOT_HOVER : SLOT, x, y, SLOT_W, SLOT_H);
			UiKit.scaledText(g, this.font, "X", x + SLOT_W / 2.0F - 5, y + 8, 2.0F, hovered ? 0xFFFF7766 : 0xFFA85A4E);
			String label = "Limpar";
			g.text(this.font, label, x + (SLOT_W - this.font.width(label)) / 2, y + 32, hovered ? UiKit.GOLD : UiKit.CREAM, false);
			if (hovered) tooltip = List.of(Component.literal("Zerar todos os dados").withStyle(ChatFormatting.GRAY));
		}

		// sheet selector card
		{
			int x = sheetX(), y = sheetY();
			boolean hovered = UiKit.in(mouseX, mouseY, x, y, SHEET_W, SHEET_H);
			UiKit.image(g, hovered ? SLOT_HOVER : SLOT, x, y, SHEET_W, SHEET_H);
			ItemStack stack = selectedStack();
			if (!stack.isEmpty()) {
				CompoundTag sheet = CharacterSheetData.read(stack);
				String name = sheet.getStringOr(CharacterSheetData.NAME, "").trim();
				if (name.isEmpty()) name = "Sem nome";
				g.item(stack, x + 6, y + 6);
				g.text(this.font, UiKit.fit(this.font, name, SHEET_W - 32), x + 28, y + 8, UiKit.GOLD, false);
				String cls = sheet.getStringOr(CharacterSheetData.CLASS, "").trim();
				String lvl = sheet.getStringOr(CharacterSheetData.LEVEL, "").trim();
				String info = (cls + (lvl.isEmpty() ? "" : " " + lvl)).trim();
				if (!info.isEmpty()) g.text(this.font, UiKit.fit(this.font, info, SHEET_W - 32), x + 28, y + 20, UiKit.CREAM, false);
				g.text(this.font, "Slot " + (selectedSlot() + 1), x + 28, y + 32, 0xFF8A7F72, false);
			} else {
				g.text(this.font, "Sem ficha", x + (SHEET_W - this.font.width("Sem ficha")) / 2, y + 12, UiKit.CREAM, false);
				String hint = "clique p/ trocar";
				g.text(this.font, hint, x + (SHEET_W - this.font.width(hint)) / 2, y + 26, 0xFF8A7F72, false);
			}
			if (hovered) {
				int found = sheetSlots.size() - 1;
				tooltip = List.of(
						Component.literal("Ficha de personagem").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
						Component.literal(found == 0 ? "Nenhuma ficha no inventário" : found + " ficha(s) no inventário").withStyle(ChatFormatting.GRAY),
						Component.literal("Esquerdo: próxima · Direito: anterior").withStyle(ChatFormatting.DARK_GRAY));
			}
		}

		// ability buttons
		boolean hasSheet = selectedSlot() >= 0;
		for (int i = 0; i < ABILITIES.length; i++) {
			int x = abilityX(i), y = abilityY(i);
			boolean hovered = hasSheet && UiKit.in(mouseX, mouseY, x, y, ABILITY_W, ABILITY_H);
			boolean selected = hasSheet && abilityIndex == i;
			if (selected) {
				g.fill(x, y, x + ABILITY_W, y + ABILITY_H, 0xFF120A04);
				g.fillGradient(x + 1, y + 1, x + ABILITY_W - 1, y + ABILITY_H - 1, 0xFFE0B050, 0xFFB07A28);
				g.fill(x + 1, y + 1, x + ABILITY_W - 1, y + 2, 0xFFFFE9A8);
				String t = ABILITY_NAMES[i];
				g.text(this.font, t, x + (ABILITY_W - this.font.width(t)) / 2, y + 4, 0xFF2B1D0E, false);
			} else {
				UiKit.button(g, this.font, x, y, ABILITY_W, ABILITY_H, ABILITY_NAMES[i], hovered, false, hasSheet);
			}
			if (UiKit.in(mouseX, mouseY, x, y, ABILITY_W, ABILITY_H)) {
				if (!hasSheet) {
					tooltip = List.of(Component.literal("Selecione uma ficha para usar atributos").withStyle(ChatFormatting.GRAY));
				} else {
					Integer mod = modifierOf(i);
					String score = selectedSheet().getStringOr(ABILITIES[i], "").trim();
					tooltip = List.of(
							Component.literal(ABILITY_FULL[i]).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
							Component.literal(mod == null ? "Valor não preenchido na ficha" : "Valor " + score + " · modificador " + signed(mod)).withStyle(ChatFormatting.GRAY),
							Component.literal(selected ? "Clique para remover o bônus" : "Clique para somar ao resultado").withStyle(ChatFormatting.DARK_GRAY));
				}
			}
		}

		// formula strip
		UiKit.darkInset(g, left + 16, top + 146, 288, 20);
		String formula = formula();
		if (formula.isEmpty()) {
			g.text(this.font, "Clique nos dados para montar a rolagem", left + 22, top + 152, 0xFF8A7F72, false);
		} else {
			g.text(this.font, UiKit.fit(this.font, formula, 236), left + 22, top + 152, UiKit.CREAM, false);
		}
		String count = totalDice() + "/" + MAX_TOTAL;
		g.text(this.font, count, left + 298 - this.font.width(count), top + 152, totalDice() >= MAX_TOTAL ? 0xFFFF7766 : UiKit.GOLD_DIM, false);

		// action buttons
		int by = buttonsY();
		UiKit.button(g, this.font, rollX(), by, 150, 22, "Rolar e enviar ao chat",
				UiKit.in(mouseX, mouseY, rollX(), by, 150, 22), true, true);
		boolean quickHover = UiKit.in(mouseX, mouseY, quickX(), by, 80, 22);
		UiKit.button(g, this.font, quickX(), by, 80, 22, "      d20", quickHover, false, true);
		UiKit.image(g, DIE_SPRITES[5], quickX() + 6, by + 2, 18, 18);
		boolean closeHover = UiKit.in(mouseX, mouseY, closeX(), by, 46, 22);
		UiKit.button(g, this.font, closeX(), by, 46, 22, "Fechar", closeHover, false, true);
		if (quickHover) {
			tooltip = List.of(
					Component.literal("Teste rápido").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
					Component.literal("Rola 1d20 agora (com o atributo escolhido)").withStyle(ChatFormatting.GRAY));
		}

		if (!error.isEmpty()) {
			g.text(this.font, error, left + (W - this.font.width(error)) / 2, top + 201, 0xFFFF7777, true);
		}

		if (tooltip != null) {
			g.setComponentTooltipForNextFrame(this.font, tooltip, mouseX, mouseY);
		}
	}

	private void sectionLabel(GuiGraphicsExtractor g, String text, int x, int y, int rightEdge) {
		g.text(this.font, text, x, y, UiKit.GOLD_DIM, false);
		int lineX = x + this.font.width(text) + 4;
		if (lineX < rightEdge) g.fill(lineX, y + 4, rightEdge, y + 5, 0x66C9A25E);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
