package com.example.dnd.client;

import com.example.dnd.DND;
import com.example.dnd.block.MiniData;
import com.mojang.blaze3d.platform.NativeImage;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

/** Turns a miniature's skin PNG into a registered texture (cached by hash). Default miniatures use Steve. */
public final class MiniTextures {
	private static final Identifier STEVE_WIDE = Identifier.fromNamespaceAndPath("minecraft", "textures/entity/player/wide/steve.png");
	private static final Identifier STEVE_SLIM = Identifier.fromNamespaceAndPath("minecraft", "textures/entity/player/slim/steve.png");
	private static final Map<String, Identifier> CACHE = new HashMap<>();

	private MiniTextures() {
	}

	public static Identifier get(MiniData m) {
		if (m.isDefault()) return m.slim() ? STEVE_SLIM : STEVE_WIDE;
		return CACHE.computeIfAbsent(m.hash(), h -> load(h, m.png()));
	}

	private static Identifier load(String hash, byte[] png) {
		try {
			NativeImage img = NativeImage.read(png);
			if (img.getWidth() != 64 || img.getHeight() != 64) {
				img.close();
				return STEVE_WIDE;
			}
			// like vanilla: the base layer of a skin is always opaque
			opaque(img, 0, 0, 32, 16);
			opaque(img, 0, 16, 64, 32);
			opaque(img, 16, 48, 48, 64);
			Identifier id = DND.id("skin/" + hash);
			DynamicTexture tex = new DynamicTexture(() -> "dnd_skin_" + hash, img);
			tex.upload();
			Minecraft.getInstance().getTextureManager().register(id, tex);
			return id;
		} catch (Exception e) {
			DND.LOGGER.warn("Could not load miniature skin", e);
			return STEVE_WIDE;
		}
	}

	private static void opaque(NativeImage img, int x0, int y0, int x1, int y1) {
		for (int y = y0; y < y1; y++) {
			for (int x = x0; x < x1; x++) {
				img.setPixel(x, y, img.getPixel(x, y) | 0xFF000000);
			}
		}
	}

	/** True when the arms of the skin look slim (the last arm column is empty), like a vanilla "Alex" skin. */
	public static boolean looksSlim(byte[] png) {
		try (NativeImage img = NativeImage.read(png)) {
			if (img.getWidth() != 64 || img.getHeight() != 64) return false;
			return ((img.getPixel(55, 20) >>> 24) & 255) == 0 && ((img.getPixel(47, 20) >>> 24) & 255) == 0;
		} catch (Exception e) {
			return false;
		}
	}
}
