package com.example.dnd.client;

import com.example.dnd.block.MiniData;
import com.example.dnd.network.MiniBoxPayload;
import com.example.dnd.network.MiniBoxViewPayload;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/**
 * A caixa de miniaturas: abas para organizar, quantas minis couber, paginas de 8. O conteudo mora no servidor;
 * esta tela mostra a ultima vista recebida ({@link #view}) e manda pedidos de edicao.
 * Arraste um .png de skin (64x64) para a janela para adicionar na aba aberta.
 */
public class MiniatureBoxScreen extends Screen {
	private static final int W = 270, H = 288, CARD_W = 126, CARD_H = 36, GAP = 6, ROW_GAP = 4;
	private static final int TABS_SHOWN = 3, TAB_W = 62;

	/** Ultima vista enviada pelo servidor (preenchida pelo receptor em {@link DNDClient}). */
	public static volatile MiniBoxViewPayload view;

	private final int target;
	private int selected = -1; // posicao dentro da pagina
	private int tabScroll;
	private int lastTab = -1, lastPage = -1;
	private int syncedTab = -2;
	private String syncedTabName = "";
	private boolean requested;
	private EditBox nameBox, tabBox;
	private String status = "Arraste um arquivo .png de skin (64x64) para esta janela.";
	private int statusColor = UiKit.CREAM;
	private int left, top;

	/** @param target {@link MiniBoxPayload#TARGET_MAIN}, {@link MiniBoxPayload#TARGET_OFF} ou TARGET_ENTITY + id do item pousado */
	public MiniatureBoxScreen(int target) {
		super(Component.literal("Caixa de Miniaturas"));
		this.target = target;
		view = null;
	}

	// ---------------------------------------------------------------- dados

	private List<MiniData> minis() {
		MiniBoxViewPayload v = view;
		return v == null ? List.of() : v.minis();
	}

	private int curTab() {
		MiniBoxViewPayload v = view;
		return v == null ? 0 : v.tab();
	}

	private int curPage() {
		MiniBoxViewPayload v = view;
		return v == null ? 0 : v.page();
	}

	private int tabCount() {
		MiniBoxViewPayload v = view;
		return v == null ? 1 : v.tabNames().size();
	}

	private int pageCount() {
		MiniBoxViewPayload v = view;
		return v == null ? 1 : MiniBoxViewPayload.pages(v.count());
	}

	private int total() {
		MiniBoxViewPayload v = view;
		if (v == null) return 0;
		int n = 0;
		for (int c : v.tabCounts()) n += c;
		return n;
	}

	private void send(int action, int tab, int index, int page, String name, byte[] png, boolean slim, int extra) {
		ClientPlayNetworking.send(new MiniBoxPayload(target, action, tab, index, page, name, png, slim, extra));
	}

	private void goTo(int tab, int page) {
		send(MiniBoxPayload.VIEW, tab, 0, page, "", new byte[0], false, 0);
	}

	private int absolute(int slot) {
		return curPage() * MiniBoxViewPayload.PAGE + slot;
	}

	@Override
	protected void init() {
		left = (this.width - W) / 2;
		top = Math.max(4, (this.height - H) / 2);
		tabBox = new EditBox(this.font, left + 12, top + 42, 110, 16, Component.literal("Aba"));
		tabBox.setMaxLength(14);
		this.addRenderableWidget(tabBox);
		nameBox = new EditBox(this.font, left + 40, top + 226, 104, 16, Component.literal("Nome"));
		nameBox.setMaxLength(MiniData.MAX_NAME);
		this.addRenderableWidget(nameBox);
		syncedTab = -2; // forca copiar o nome da aba para a caixa de texto
		syncNameBox();
		if (!requested) {
			requested = true;
			goTo(-1, 0); // -1 = a aba que estava ativa
		}
	}

	private void syncNameBox() {
		List<MiniData> list = minis();
		boolean ok = selected >= 0 && selected < list.size();
		nameBox.setEditable(ok);
		nameBox.setValue(ok ? list.get(selected).name() : "");
	}

	private void syncTabBox() {
		MiniBoxViewPayload v = view;
		if (v == null) return;
		String name = v.tab() < v.tabNames().size() ? v.tabNames().get(v.tab()) : "";
		if (v.tab() != syncedTab || !name.equals(syncedTabName)) {
			syncedTab = v.tab();
			syncedTabName = name;
			tabBox.setValue(name);
		}
	}

	// ---------------------------------------------------------------- layout

	private int cardX(int s) {
		return left + 12 + (s % 2) * (CARD_W + GAP);
	}

	private int cardY(int s) {
		return top + 66 + (s / 2) * (CARD_H + ROW_GAP);
	}

	private int tabX(int k) {
		return left + 28 + k * (TAB_W + 4);
	}

	// ---------------------------------------------------------------- arquivos

	@Override
	public void onFilesDrop(List<Path> paths) {
		for (Path p : paths) {
			String fn = p.getFileName() == null ? "" : p.getFileName().toString();
			if (!fn.toLowerCase().endsWith(".png")) continue;
			try {
				if (Files.size(p) > MiniData.MAX_PNG) {
					say("Skin grande demais (máx. " + (MiniData.MAX_PNG / 1024) + " KB).", 0xFFFF8080);
					return;
				}
				byte[] png = Files.readAllBytes(p);
				if (!MiniData.validPng(png)) {
					say("A skin precisa ser um PNG de 64x64.", 0xFFFF8080);
					return;
				}
				String name = fn.substring(0, fn.length() - 4);
				send(MiniBoxPayload.ADD, curTab(), 0, curPage(), name, png, MiniTextures.looksSlim(png), 0);
				say("Adicionada: " + MiniData.cleanName(name), 0xFF9BE37A);
				return;
			} catch (Exception e) {
				say("Não consegui ler o arquivo.", 0xFFFF8080);
				return;
			}
		}
		say("Só arquivos .png são aceitos.", 0xFFFF8080);
	}

	private void say(String s, int color) {
		status = s;
		statusColor = color;
	}

	// ---------------------------------------------------------------- input

	private boolean over(MouseButtonEvent e, int x, int y, int w, int h) {
		return UiKit.in((int) e.x(), (int) e.y(), x, y, w, h);
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (super.mouseClicked(event, doubleClick)) return true;
		if (event.button() != 0 || view == null) return false;
		List<MiniData> list = minis();
		int tabs = tabCount();
		int tab = curTab();
		int page = curPage();

		// ---- abas
		if (over(event, left + 12, top + 22, 14, 16)) {
			UiKit.click();
			tabScroll = Math.max(0, tabScroll - 1);
			return true;
		}
		if (over(event, left + 224, top + 22, 14, 16)) {
			UiKit.click();
			tabScroll = Math.min(Math.max(0, tabs - TABS_SHOWN), tabScroll + 1);
			return true;
		}
		for (int k = 0; k < TABS_SHOWN; k++) {
			int idx = tabScroll + k;
			if (idx >= tabs) break;
			if (over(event, tabX(k), top + 22, TAB_W, 16)) {
				UiKit.click();
				if (idx != tab) goTo(idx, 0);
				return true;
			}
		}
		if (over(event, left + 240, top + 22, 18, 16)) {
			UiKit.click();
			send(MiniBoxPayload.TAB_ADD, tab, 0, 0, "Aba " + (tabs + 1), new byte[0], false, 0);
			say("Aba criada.", 0xFF9BE37A);
			return true;
		}
		if (over(event, left + 126, top + 41, 70, 18)) {
			UiKit.click();
			send(MiniBoxPayload.TAB_RENAME, tab, 0, page, tabBox.getValue(), new byte[0], false, 0);
			return true;
		}
		if (over(event, left + 200, top + 41, 58, 18) && tabs > 1) {
			UiKit.click();
			send(MiniBoxPayload.TAB_DELETE, tab, 0, 0, "", new byte[0], false, 0);
			say("Aba apagada (as minis foram para a primeira aba).", 0xFF9BE37A);
			return true;
		}

		// ---- cartoes
		for (int s = 0; s < list.size(); s++) {
			int x = cardX(s), y = cardY(s);
			if (!over(event, x, y, CARD_W, CARD_H)) continue;
			int abs = absolute(s);
			if (over(event, x + CARD_W - 20, y + 3, 16, 14)) {
				UiKit.click();
				send(MiniBoxPayload.REMOVE, tab, abs, page, "", new byte[0], false, 0);
				selected = -1;
				syncNameBox();
				return true;
			}
			if (over(event, x + CARD_W - 38, y + 19, 16, 14)) {
				UiKit.click();
				send(MiniBoxPayload.TAKE, tab, abs, page, "", new byte[0], false, 0);
				say("Retirada da caixa: " + list.get(s).name(), 0xFF9BE37A);
				selected = -1;
				syncNameBox();
				return true;
			}
			if (over(event, x + CARD_W - 20, y + 19, 16, 14)) {
				UiKit.click();
				send(MiniBoxPayload.SLIM, tab, abs, page, "", new byte[0], !list.get(s).slim(), 0);
				return true;
			}
			selected = s;
			syncNameBox();
			return true;
		}

		boolean hasSel = selected >= 0 && selected < list.size();
		// ---- renomear / mover a mini selecionada
		if (over(event, left + 148, top + 225, 58, 18) && hasSel) {
			UiKit.click();
			send(MiniBoxPayload.RENAME, tab, absolute(selected), page, nameBox.getValue(), new byte[0], false, 0);
			return true;
		}
		if (over(event, left + 210, top + 225, 48, 18) && hasSel && tabs > 1) {
			UiKit.click();
			send(MiniBoxPayload.MOVE, tab, absolute(selected), page, "", new byte[0], false, (tab + 1) % tabs);
			say("Movida para a aba seguinte.", 0xFF9BE37A);
			selected = -1;
			syncNameBox();
			return true;
		}

		// ---- paginas
		if (over(event, left + 190, top + 245, 14, 14) && page > 0) {
			UiKit.click();
			goTo(tab, page - 1);
			return true;
		}
		if (over(event, left + 240, top + 245, 18, 14) && page < pageCount() - 1) {
			UiKit.click();
			goTo(tab, page + 1);
			return true;
		}

		// ---- rodape
		if (over(event, left + 12, top + 266, 120, 18)) {
			UiKit.click();
			send(MiniBoxPayload.ADD, tab, 0, page, "Steve", new byte[0], false, 0);
			return true;
		}
		if (over(event, left + 138, top + 266, 120, 18)) {
			UiKit.click();
			this.onClose();
			return true;
		}
		return false;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		if (view != null && UiKit.in((int) mouseX, (int) mouseY, left, top, W, H)) {
			int page = curPage() + (scrollY < 0 ? 1 : -1);
			if (page >= 0 && page < pageCount()) goTo(curTab(), page);
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	// ---------------------------------------------------------------- render

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		MiniBoxViewPayload v = view;
		List<MiniData> list = minis();
		int tabs = tabCount();
		int tab = curTab();
		int page = curPage();

		if (v != null) {
			if (tab != lastTab || page != lastPage) {
				lastTab = tab;
				lastPage = page;
				selected = -1;
				syncNameBox();
			}
			// mantem a aba aberta visivel na faixa de abas
			if (tab < tabScroll) tabScroll = tab;
			if (tab >= tabScroll + TABS_SHOWN) tabScroll = tab - TABS_SHOWN + 1;
			tabScroll = Math.max(0, Math.min(tabScroll, Math.max(0, tabs - TABS_SHOWN)));
			syncTabBox();
		}
		if (selected >= list.size()) {
			selected = -1;
			syncNameBox();
		}

		g.fill(left, top, left + W, top + H, 0xFF120A04);
		g.fill(left + 2, top + 2, left + W - 2, top + H - 2, 0xFF3A2916);
		g.fill(left + 4, top + 4, left + W - 4, top + H - 4, 0xFF4A331B);
		g.text(this.font, "Caixa de Miniaturas", left + 12, top + 8, UiKit.GOLD, false);
		String count = v == null ? "..." : v.count() + " na aba · " + total() + " no total";
		g.text(this.font, count, left + W - 12 - this.font.width(count), top + 8, UiKit.GOLD_DIM, false);

		// faixa de abas
		boolean canL = tabScroll > 0, canR = tabScroll + TABS_SHOWN < tabs;
		UiKit.button(g, this.font, left + 12, top + 22, 14, 16, "<",
				UiKit.in(mouseX, mouseY, left + 12, top + 22, 14, 16), false, canL);
		for (int k = 0; k < TABS_SHOWN; k++) {
			int idx = tabScroll + k;
			if (idx >= tabs || v == null) break;
			String name = v.tabNames().get(idx) + " (" + v.tabCounts().get(idx) + ")";
			UiKit.button(g, this.font, tabX(k), top + 22, TAB_W, 16, UiKit.fit(this.font, name, TAB_W - 6),
					UiKit.in(mouseX, mouseY, tabX(k), top + 22, TAB_W, 16), idx == tab, true);
		}
		UiKit.button(g, this.font, left + 224, top + 22, 14, 16, ">",
				UiKit.in(mouseX, mouseY, left + 224, top + 22, 14, 16), false, canR);
		UiKit.button(g, this.font, left + 240, top + 22, 18, 16, "+",
				UiKit.in(mouseX, mouseY, left + 240, top + 22, 18, 16), false, v != null);

		UiKit.button(g, this.font, left + 126, top + 41, 70, 18, "Renomear aba",
				UiKit.in(mouseX, mouseY, left + 126, top + 41, 70, 18), false, v != null);
		UiKit.button(g, this.font, left + 200, top + 41, 58, 18, "Excluir aba",
				UiKit.in(mouseX, mouseY, left + 200, top + 41, 58, 18), false, tabs > 1);
		UiKit.divider(g, left + 12, top + 62, W - 24, UiKit.GOLD_DIM);

		// grade de minis (8 por pagina)
		for (int s = 0; s < MiniBoxViewPayload.PAGE; s++) {
			int x = cardX(s), y = cardY(s);
			UiKit.darkInset(g, x, y, CARD_W, CARD_H);
			if (s >= list.size()) {
				String empty = v == null ? "..." : "vazio";
				g.text(this.font, empty, x + CARD_W / 2 - this.font.width(empty) / 2, y + 14, 0xFF6F5A43, false);
				continue;
			}
			MiniData m = list.get(s);
			SkinPreview.doll(g, m, x + 6, y + 2, 1);
			g.text(this.font, UiKit.fit(this.font, m.name(), CARD_W - 64), x + 30, y + 7, UiKit.CREAM, false);
			g.text(this.font, m.isDefault() ? "padrão" : "skin custom", x + 30, y + 21, 0xFF9C8A6C, false);
			boolean hx = UiKit.in(mouseX, mouseY, x + CARD_W - 20, y + 3, 16, 14);
			boolean hs = UiKit.in(mouseX, mouseY, x + CARD_W - 20, y + 19, 16, 14);
			boolean ht = UiKit.in(mouseX, mouseY, x + CARD_W - 38, y + 19, 16, 14);
			UiKit.button(g, this.font, x + CARD_W - 20, y + 3, 16, 14, "x", hx, false, true);
			UiKit.button(g, this.font, x + CARD_W - 20, y + 19, 16, 14, m.slim() ? "F" : "L", hs, false, true);
			UiKit.button(g, this.font, x + CARD_W - 38, y + 19, 16, 14, "^", ht, false, true);
			if (s == selected) g.outline(x, y, CARD_W, CARD_H, UiKit.GOLD);
		}

		// editar a mini selecionada
		boolean hasSel = selected >= 0 && selected < list.size();
		g.text(this.font, "Nome", left + 12, top + 230, UiKit.CREAM, false);
		UiKit.button(g, this.font, left + 148, top + 225, 58, 18, "Renomear",
				UiKit.in(mouseX, mouseY, left + 148, top + 225, 58, 18), false, hasSel);
		UiKit.button(g, this.font, left + 210, top + 225, 48, 18, "Mover >",
				UiKit.in(mouseX, mouseY, left + 210, top + 225, 48, 18), false, hasSel && tabs > 1);

		// status e paginas
		g.text(this.font, UiKit.fit(this.font, status, 172), left + 12, top + 249, statusColor, false);
		UiKit.button(g, this.font, left + 190, top + 245, 14, 14, "<",
				UiKit.in(mouseX, mouseY, left + 190, top + 245, 14, 14), false, page > 0);
		String pg = (page + 1) + "/" + pageCount();
		g.text(this.font, pg, left + 222 - this.font.width(pg) / 2, top + 249, UiKit.CREAM, false);
		UiKit.button(g, this.font, left + 240, top + 245, 18, 14, ">",
				UiKit.in(mouseX, mouseY, left + 240, top + 245, 18, 14), false, page < pageCount() - 1);

		UiKit.button(g, this.font, left + 12, top + 266, 120, 18, "+ Steve padrão",
				UiKit.in(mouseX, mouseY, left + 12, top + 266, 120, 18), false, v != null);
		UiKit.button(g, this.font, left + 138, top + 266, 120, 18, "Fechar",
				UiKit.in(mouseX, mouseY, left + 138, top + 266, 120, 18), true, true);

		super.extractRenderState(g, mouseX, mouseY, delta);

		if (UiKit.in(mouseX, mouseY, left, top, W, H)) {
			for (int s = 0; s < list.size(); s++) {
				if (UiKit.in(mouseX, mouseY, cardX(s) + CARD_W - 38, cardY(s) + 19, 16, 14)) {
					g.setTooltipForNextFrame(Component.literal("Tirar da caixa (vira um item para colocar no mundo)"), mouseX, mouseY);
				}
				if (UiKit.in(mouseX, mouseY, cardX(s) + CARD_W - 20, cardY(s) + 19, 16, 14)) {
					g.setTooltipForNextFrame(Component.literal(list.get(s).slim() ? "Braço fino (clique: largo)" : "Braço largo (clique: fino)"), mouseX, mouseY);
				}
				if (UiKit.in(mouseX, mouseY, cardX(s) + CARD_W - 20, cardY(s) + 3, 16, 14)) {
					g.setTooltipForNextFrame(Component.literal("Apagar da caixa"), mouseX, mouseY);
				}
			}
			if (UiKit.in(mouseX, mouseY, left + 210, top + 225, 48, 18) && hasSel && tabs > 1) {
				String next = v.tabNames().get((tab + 1) % tabs);
				g.setTooltipForNextFrame(Component.literal("Mover para a aba \"" + next + "\""), mouseX, mouseY);
			}
			if (UiKit.in(mouseX, mouseY, left + 200, top + 41, 58, 18) && tabs > 1) {
				g.setTooltipForNextFrame(Component.literal("As minis da aba vão para a primeira aba"), mouseX, mouseY);
			}
		}
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
