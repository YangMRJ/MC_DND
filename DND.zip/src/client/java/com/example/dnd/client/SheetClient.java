package com.example.dnd.client;

import com.example.dnd.item.CharacterSheetItem;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;

/** Client side of the character sheet: opens the editor when the item is used. */
public class SheetClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		CharacterSheetItem.clientOpener = (stack, hand) ->
				Minecraft.getInstance().gui.setScreen(new CharacterSheetScreen(stack, hand));
	}
}
