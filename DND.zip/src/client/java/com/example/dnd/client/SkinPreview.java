package com.example.dnd.client;

import com.example.dnd.block.MiniData;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

/** Flat 2D drawings of a skin for the GUIs. */
final class SkinPreview {
	private SkinPreview() {
	}

	private static void part(GuiGraphicsExtractor g, Identifier tex, int sx, int sy, int sw, int sh,
							 int u, int v, int uw, int vh) {
		g.blit(tex, sx, sy, sx + sw, sy + sh, u / 64F, (u + uw) / 64F, v / 64F, (v + vh) / 64F);
	}

	/** Head (with hat layer) as a size x size square. */
	static void head(GuiGraphicsExtractor g, MiniData m, int x, int y, int size) {
		Identifier tex = MiniTextures.get(m);
		part(g, tex, x, y, size, size, 8, 8, 8, 8);
		part(g, tex, x, y, size, size, 40, 8, 8, 8);
	}

	/** Whole character from the front: 16 x 32 skin pixels scaled by {@code s}. */
	static void doll(GuiGraphicsExtractor g, MiniData m, int x, int y, int s) {
		Identifier tex = MiniTextures.get(m);
		int aw = m.slim() ? 3 : 4;
		// base layer, then outer layer on top
		for (int layer = 0; layer < 2; layer++) {
			int o = layer * 16;
			part(g, tex, x + 4 * s, y, 8 * s, 8 * s, 8 + (layer == 1 ? 32 : 0), 8, 8, 8);                // head / hat
			part(g, tex, x + 4 * s, y + 8 * s, 8 * s, 12 * s, 20, 20 + o, 8, 12);                           // body / jacket
			part(g, tex, x + (4 - aw) * s, y + 8 * s, aw * s, 12 * s, 44, 20 + o, aw, 12);                  // right arm
			part(g, tex, x + 12 * s, y + 8 * s, aw * s, 12 * s, layer == 0 ? 36 : 52, 52, aw, 12); // left arm
			part(g, tex, x + 4 * s, y + 20 * s, 4 * s, 12 * s, 4, 20 + o, 4, 12);                           // right leg
			part(g, tex, x + 8 * s, y + 20 * s, 4 * s, 12 * s, layer == 0 ? 20 : 4, 52, 4, 12);             // left leg
		}
	}
}
