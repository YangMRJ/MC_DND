package com.example.dnd.client;

import com.example.dnd.DND;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;

/** Small drawing helpers shared by the mod's screens (textured images, bevelled buttons, insets). */
final class UiKit {
	static final int GOLD = 0xFFFFD98A;
	static final int GOLD_DIM = 0xFFC9A25E;
	static final int CREAM = 0xFFF3E2BA;

	private UiKit() {
	}

	/** Texture under assets/dnd/textures/gui/. */
	static Identifier gui(String name) {
		return DND.id("textures/gui/" + name + ".png");
	}

	/** Draws a whole texture stretched to the given rectangle (use the texture's own size for pixel-perfect). */
	static void image(GuiGraphicsExtractor g, Identifier id, int x, int y, int w, int h) {
		g.blit(id, x, y, x + w, y + h, 0.0F, 1.0F, 0.0F, 1.0F);
	}

	static boolean in(int mx, int my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	static void click() {
		Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
	}

	/** Leather/wood bevelled button. {@code primary} gives it the crimson "call to action" look. */
	static void button(GuiGraphicsExtractor g, Font font, int x, int y, int w, int h, String label,
			boolean hovered, boolean primary, boolean enabled) {
		int top, bottom, hi, lo, text;
		if (!enabled) {
			top = 0xFF3A3029; bottom = 0xFF2C241E; hi = 0xFF4A4038; lo = 0xFF1E1813; text = 0xFF8A7F72;
		} else if (primary) {
			top = hovered ? 0xFFB8403A : 0xFF9A2E2A;
			bottom = hovered ? 0xFF8A2622 : 0xFF70201E;
			hi = 0xFFE07A6E; lo = 0xFF4A1210; text = 0xFFFFE9A8;
		} else {
			top = hovered ? 0xFF7E5630 : 0xFF684626;
			bottom = hovered ? 0xFF5C3C20 : 0xFF4A2F18;
			hi = 0xFFA87A44; lo = 0xFF2E1B0B; text = CREAM;
		}
		g.fill(x, y, x + w, y + h, 0xFF120A04);
		g.fillGradient(x + 1, y + 1, x + w - 1, y + h - 1, top, bottom);
		g.fill(x + 1, y + 1, x + w - 1, y + 2, hi);
		g.fill(x + 1, y + 1, x + 2, y + h - 1, hi);
		g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, lo);
		g.fill(x + w - 2, y + 1, x + w - 1, y + h - 1, lo);
		if (hovered && enabled) {
			g.outline(x, y, w, h, GOLD);
		}
		g.text(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2 + (hovered && enabled ? 0 : 1), text, false);
	}

	/** Sunken box (dark leather style). */
	static void darkInset(GuiGraphicsExtractor g, int x, int y, int w, int h) {
		g.fill(x, y, x + w, y + h, 0xFF0F0905);
		g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF1F150D);
		g.fill(x + 1, y + 1, x + w - 1, y + 2, 0xFF140D08);
		g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, 0xFF3A2A1A);
	}

	/** Sunken parchment box used behind editable fields on the character sheet. */
	static void paperInset(GuiGraphicsExtractor g, int x, int y, int w, int h) {
		g.fill(x, y, x + w, y + h, 0xFFF7EFD3);
		g.fill(x, y, x + w, y + 1, 0xFF8A6232);          // sombra no topo
		g.fill(x, y, x + 1, y + h, 0xFF8A6232);          // sombra na esquerda
		g.fill(x, y + h - 1, x + w, y + h, 0xFFFFF8E0);  // luz embaixo
		g.fill(x + w - 1, y, x + w, y + h, 0xFFFFF8E0);  // luz na direita
		g.fill(x + 1, y + 1, x + w - 1, y + 2, 0xFFDCC590);
	}

	/** Draws text scaled by {@code scale} with its top-left corner at (x, y). */
	static void scaledText(GuiGraphicsExtractor g, Font font, String text, float x, float y, float scale, int color) {
		g.pose().pushMatrix();
		g.pose().translate(x, y);
		g.pose().scale(scale, scale);
		g.text(font, text, 0, 0, color, false);
		g.pose().popMatrix();
	}

	/** Cuts the text with "..." so that it fits in {@code maxWidth} pixels. */
	static String fit(Font font, String text, int maxWidth) {
		if (font.width(text) <= maxWidth) {
			return text;
		}
		String s = text;
		while (s.length() > 1 && font.width(s + "...") > maxWidth) {
			s = s.substring(0, s.length() - 1);
		}
		return s + "...";
	}

	/** Thin horizontal ornament line with a diamond in the middle. */
	static void divider(GuiGraphicsExtractor g, int x, int y, int w, int color) {
		int mid = x + w / 2;
		g.fill(x, y, mid - 4, y + 1, color);
		g.fill(mid + 4, y, x + w, y + 1, color);
		g.fill(mid - 1, y - 1, mid + 1, y + 2, color);
	}
}
