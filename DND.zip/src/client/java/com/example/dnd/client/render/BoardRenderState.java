package com.example.dnd.client.render;

import com.example.dnd.block.BoardBlockEntity;
import com.example.dnd.block.MiniData;
import java.util.List;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;

public class BoardRenderState extends BlockEntityRenderState {
	public List<BoardBlockEntity.Token> tokens = List.of();
	public List<MiniData> roster = List.of();
	public byte[] tiles = new byte[0];
	public byte[] heights = new byte[0];
	public byte[] props = new byte[0];
}
