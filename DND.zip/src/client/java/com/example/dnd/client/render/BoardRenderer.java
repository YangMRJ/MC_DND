package com.example.dnd.client.render;

import com.example.dnd.DND;
import com.example.dnd.block.BoardBlockEntity;
import com.example.dnd.block.MiniData;
import com.example.dnd.client.MiniTextures;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.List;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

public class BoardRenderer implements BlockEntityRenderer<BoardBlockEntity, BoardRenderState> {
	private static final Identifier WHITE = DND.id("textures/misc/white.png");
	public static final float BOARD_SIZE = 1.75F;
	public static final float ORIGIN = -6.0F / 16.0F;
	public static final float CELL = BOARD_SIZE / BoardBlockEntity.SIZE;
	public static final float TOP = 2.0F / 16.0F;
	/** Top of the wooden board; terrain columns start here. */
	public static final float BASE = 0.5F / 16.0F;
	/** Height of one terrain level. */
	public static final float LEVEL = CELL * 0.5F;
	/** Size of one skin pixel: a miniature is 16 skin pixels wide (arm to arm) and 32 tall. */
	public static final float PX = CELL * 0.9F / 16.0F;
	public static final float MINI_BASE = CELL * 0.06F;
	public static final float MINI_H = 32 * PX + MINI_BASE;

	public BoardRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public BoardRenderState createRenderState() {
		return new BoardRenderState();
	}

	@Override
	public void extractRenderState(BoardBlockEntity be, BoardRenderState state, float partialTick, Vec3 cameraPos,
								   ModelFeatureRenderer.@org.jspecify.annotations.Nullable CrumblingOverlay crumblingOverlay) {
		BlockEntityRenderer.super.extractRenderState(be, state, partialTick, cameraPos, crumblingOverlay);
		state.tokens = List.copyOf(be.getTokens());
		state.roster = List.copyOf(be.getRoster());
		state.tiles = be.tilesSnapshot();
		state.heights = be.heightsSnapshot();
		state.props = be.propsSnapshot();
	}

	/** Block-local X/Z of the center of a cell. */
	public static float cellCenter(int c) {
		return ORIGIN + (c + 0.5F) * CELL;
	}

	@Override
	public void submit(BoardRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState cameraState) {
		int light = state.lightCoords;

		// terrain, props and the pedestals under the miniatures
		collector.submitCustomGeometry(poseStack, RenderTypes.entitySolid(WHITE), (pose, consumer) -> {
			TerrainMesher.emit(pose, consumer, light, state.tiles, state.heights, state.props);
			for (BoardBlockEntity.Token t : state.tokens) {
				int i = t.z() * BoardBlockEntity.SIZE + t.x();
				if (i < 0 || i >= state.tiles.length) continue;
				float y = TerrainMesher.surface(state.tiles[i], state.heights[i]);
				TerrainMesher.base(pose, consumer, light, cellCenter(t.x()), y, cellCenter(t.z()));
			}
		});

		// one draw per miniature model, each with its own skin texture
		for (int m = 0; m < state.roster.size(); m++) {
			final int mi = m;
			final MiniData mini = state.roster.get(m);
			boolean any = false;
			for (BoardBlockEntity.Token t : state.tokens) {
				if (t.mini() == mi) {
					any = true;
					break;
				}
			}
			if (!any) continue;
			collector.submitCustomGeometry(poseStack, RenderTypes.entityCutout(MiniTextures.get(mini)), (pose, consumer) -> {
				for (BoardBlockEntity.Token t : state.tokens) {
					if (t.mini() != mi) continue;
					int i = t.z() * BoardBlockEntity.SIZE + t.x();
					if (i < 0 || i >= state.tiles.length) continue;
					float y = TerrainMesher.surface(state.tiles[i], state.heights[i]) + MINI_BASE;
					MiniMesher.emit(pose, consumer, mini.slim(), cellCenter(t.x()), y, cellCenter(t.z()), PX, t.rot(), light);
				}
			});
		}
	}
}
