package com.example.dnd.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;

/** Flat-colored axis-aligned boxes (terrain and props). Quads are counter-clockwise seen from outside. */
final class BoxMesher {
	private BoxMesher() {
	}

	static int shade(int rgb, float f) {
		int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
		int g = Math.min(255, (int) (((rgb >> 8) & 255) * f));
		int b = Math.min(255, (int) ((rgb & 255) * f));
		return 0xFF000000 | (r << 16) | (g << 8) | b;
	}

	static void box(PoseStack.Pose pose, VertexConsumer c, int rgb, int light,
					float x0, float y0, float z0, float x1, float y1, float z1, boolean bottom) {
		int color = 0xFF000000 | rgb;
		quad(pose, c, color, light, 0, 1, 0, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0);
		if (bottom) quad(pose, c, color, light, 0, -1, 0, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
		quad(pose, c, color, light, 0, 0, -1, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0);
		quad(pose, c, color, light, 0, 0, 1, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
		quad(pose, c, color, light, -1, 0, 0, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);
		quad(pose, c, color, light, 1, 0, 0, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1);
	}

	private static void quad(PoseStack.Pose pose, VertexConsumer c, int color, int light, float nx, float ny, float nz,
							 float ax, float ay, float az, float bx, float by, float bz,
							 float cx, float cy, float cz, float dx, float dy, float dz) {
		vertex(pose, c, color, light, nx, ny, nz, ax, ay, az);
		vertex(pose, c, color, light, nx, ny, nz, bx, by, bz);
		vertex(pose, c, color, light, nx, ny, nz, cx, cy, cz);
		vertex(pose, c, color, light, nx, ny, nz, dx, dy, dz);
	}

	private static void vertex(PoseStack.Pose pose, VertexConsumer c, int color, int light, float nx, float ny, float nz,
							   float x, float y, float z) {
		c.addVertex(pose, x, y, z)
				.setColor(color)
				.setUv(0.5F, 0.5F)
				.setOverlay(OverlayTexture.NO_OVERLAY)
				.setLight(light)
				.setNormal(pose, nx, ny, nz);
	}
}
