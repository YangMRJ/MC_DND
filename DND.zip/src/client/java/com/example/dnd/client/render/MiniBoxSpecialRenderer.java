package com.example.dnd.client.render;

import com.example.dnd.block.MiniData;
import com.example.dnd.client.MiniTextures;
import com.example.dnd.item.MiniBoxItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.jspecify.annotations.Nullable;

/**
 * Desenha, dentro da bandeja 3D da caixa de miniaturas (models/item/miniature_box_3d.json), as miniaturas que a
 * caixa carrega de verdade, cada uma com a skin dela. Caixa vazia = bandeja vazia.
 * Coordenadas em unidades de modelo (16 = 1 bloco): o interior da bandeja vai de x 1..15 e z 4..12.
 */
public final class MiniBoxSpecialRenderer implements SpecialModelRenderer<List<MiniData>> {
	/** Tamanho de um pixel de skin em unidades de modelo: 16 pixels de largura = 3,2 unidades. */
	private static final float PX = 0.2F;
	private static final float FLOOR = 1.25F;
	private static final float[] COLS = {2.75F, 6.25F, 9.75F, 13.25F};
	private static final float[] ROWS = {6.0F, 10.0F};

	@Override
	public @Nullable List<MiniData> extractArgument(ItemStack stack) {
		return MiniBoxItem.readCached(stack);
	}

	@Override
	public void submit(@Nullable List<MiniData> minis, PoseStack poseStack, SubmitNodeCollector collector, int light,
					   int overlay, boolean hasFoil, int outlineColor) {
		if (minis == null) return;
		for (int i = 0; i < Math.min(minis.size(), COLS.length * ROWS.length); i++) {
			final MiniData mini = minis.get(i);
			final float cx = COLS[i % COLS.length] / 16.0F;
			final float cz = ROWS[i / COLS.length] / 16.0F;
			collector.submitCustomGeometry(poseStack, RenderTypes.entityCutout(MiniTextures.get(mini)),
					// rot 2 = virada para +z, o lado do fecho da caixa
					(pose, c) -> MiniMesher.emit(pose, c, mini.slim(), cx, FLOOR / 16.0F, cz, PX / 16.0F, 2, light));
		}
	}

	@Override
	public void getExtents(Consumer<Vector3fc> out) {
		out.accept(new Vector3f(0.0F, 0.0F, 3.0F / 16.0F));
		out.accept(new Vector3f(1.0F, 0.6F, 13.0F / 16.0F));
	}

	public record Unbaked() implements SpecialModelRenderer.Unbaked<List<MiniData>> {
		public static final Unbaked INSTANCE = new Unbaked();
		public static final MapCodec<Unbaked> CODEC = MapCodec.unit(INSTANCE);

		@Override
		public SpecialModelRenderer<List<MiniData>> bake(SpecialModelRenderer.BakingContext context) {
			return new MiniBoxSpecialRenderer();
		}

		@Override
		public MapCodec<Unbaked> type() {
			return CODEC;
		}
	}
}
