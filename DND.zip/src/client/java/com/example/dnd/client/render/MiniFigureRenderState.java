package com.example.dnd.client.render;

import com.example.dnd.block.MiniData;
import net.minecraft.client.renderer.entity.state.EntityRenderState;

public class MiniFigureRenderState extends EntityRenderState {
	public MiniData mini = MiniData.steve();
	public float rot;
}
