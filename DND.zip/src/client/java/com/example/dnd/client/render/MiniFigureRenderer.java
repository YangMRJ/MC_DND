package com.example.dnd.client.render;

import com.example.dnd.client.MiniTextures;
import com.example.dnd.block.MiniData;
import com.example.dnd.entity.MiniFigureEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;

/** Desenha a miniatura em pe no mundo, com a skin dela, reaproveitando o mesmo modelo do tabuleiro. */
public class MiniFigureRenderer extends EntityRenderer<MiniFigureEntity, MiniFigureRenderState> {
	/** Tamanho de um pixel de skin em blocos: a figura tem 32 pixels de altura = 0,375 bloco. */
	public static final float PX = 3.0F / 256.0F;

	public MiniFigureRenderer(EntityRendererProvider.Context context) {
		super(context);
	}

	@Override
	public MiniFigureRenderState createRenderState() {
		return new MiniFigureRenderState();
	}

	@Override
	public void extractRenderState(MiniFigureEntity entity, MiniFigureRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.mini = entity.getMini();
		state.rot = entity.getYRot(partialTick);
	}

	@Override
	public void submit(MiniFigureRenderState state, PoseStack poseStack, SubmitNodeCollector collector,
					   CameraRenderState cameraState) {
		super.submit(state, poseStack, collector, cameraState);
		final MiniData mini = state.mini;
		final int light = state.lightCoords;
		poseStack.pushPose();
		// a frente da figura (-z no modelo) aponta para onde a entidade "olha"
		poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - state.rot));
		collector.submitCustomGeometry(poseStack, RenderTypes.entityCutout(MiniTextures.get(mini)),
				(pose, consumer) -> MiniMesher.emit(pose, consumer, mini.slim(), 0.0F, 0.0F, 0.0F, PX, 0, light));
		poseStack.popPose();
	}
}
