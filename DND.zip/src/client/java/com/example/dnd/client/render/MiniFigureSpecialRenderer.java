package com.example.dnd.client.render;

import com.example.dnd.block.MiniData;
import com.example.dnd.client.MiniTextures;
import com.example.dnd.item.MiniFigureItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.function.Consumer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.jspecify.annotations.Nullable;

/**
 * Renderizador do item "miniatura", que desenha a skin da propria miniatura:
 * <ul>
 *   <li>{@code flat = true} (hotbar, inventario, chao, moldura): o boneco de frente, plano, nao isometrico;</li>
 *   <li>{@code flat = false} (na mao): o boneco 3D.</li>
 * </ul>
 * O item model escolhe qual dos dois usar pelo contexto de exibicao (ver assets/dnd/items/miniature.json).
 * Tudo e desenhado no espaco 0..1 do modelo de item, com o centro em (0.5, 0.5, 0.5).
 */
public final class MiniFigureSpecialRenderer implements SpecialModelRenderer<MiniData> {
	private final boolean flat;

	public MiniFigureSpecialRenderer(boolean flat) {
		this.flat = flat;
	}

	@Override
	public @Nullable MiniData extractArgument(ItemStack stack) {
		return MiniFigureItem.read(stack);
	}

	@Override
	public void submit(@Nullable MiniData mini, PoseStack poseStack, SubmitNodeCollector collector, int light,
					   int overlay, boolean hasFoil, int outlineColor) {
		final MiniData m = mini == null ? MiniData.steve() : mini;
		final Identifier tex = MiniTextures.get(m);
		if (flat) {
			collector.submitCustomGeometry(poseStack, RenderTypes.entityCutout(tex),
					(pose, c) -> emitFlat(pose, c, m.slim(), light, overlay));
		} else {
			// 32 pixels de skin = 0,8 do item; pes um pouco acima da base
			final float px = 0.8F / 32.0F;
			collector.submitCustomGeometry(poseStack, RenderTypes.entityCutout(tex),
					(pose, c) -> MiniMesher.emit(pose, c, m.slim(), 0.5F, 0.1F, 0.5F, px, 0, light));
		}
	}

	@Override
	public void getExtents(Consumer<Vector3fc> out) {
		if (flat) {
			out.accept(new Vector3f(0.26F, 0.03F, 0.497F));
			out.accept(new Vector3f(0.74F, 0.97F, 0.503F));
		} else {
			out.accept(new Vector3f(0.3F, 0.1F, 0.4F));
			out.accept(new Vector3f(0.7F, 0.9F, 0.6F));
		}
	}

	// ------------------------------------------------------------ boneco plano de frente

	/** Pedacos da skin, no mesmo layout do {@code SkinPreview.doll}: destino (x, y, w, h) e origem (u, v, w, h). */
	private static void emitFlat(PoseStack.Pose pose, VertexConsumer c, boolean slim, int light, int overlay) {
		final float s = 0.94F / 32.0F;   // tamanho de um pixel de skin
		final float ox = 0.5F - 8.0F * s; // canto esquerdo da figura (16 px de largura)
		final float oy = 0.97F;           // topo da figura
		final int aw = slim ? 3 : 4;
		for (int layer = 0; layer < 2; layer++) {
			int o = layer * 16;
			float dz = 0.001F * layer;
			part(pose, c, light, overlay, dz, ox, oy, s, 4, 0, 8, 8, 8 + (layer == 1 ? 32 : 0), 8, 8, 8);              // cabeca / chapeu
			part(pose, c, light, overlay, dz, ox, oy, s, 4, 8, 8, 12, 20, 20 + o, 8, 12);                                // corpo / jaqueta
			part(pose, c, light, overlay, dz, ox, oy, s, 4 - aw, 8, aw, 12, 44, 20 + o, aw, 12);                         // braco direito
			part(pose, c, light, overlay, dz, ox, oy, s, 12, 8, aw, 12, layer == 0 ? 36 : 52, 52, aw, 12);               // braco esquerdo
			part(pose, c, light, overlay, dz, ox, oy, s, 4, 20, 4, 12, 4, 20 + o, 4, 12);                                // perna direita
			part(pose, c, light, overlay, dz, ox, oy, s, 8, 20, 4, 12, layer == 0 ? 20 : 4, 52, 4, 12);                  // perna esquerda
		}
	}

	/**
	 * Um retangulo da skin, desenhado dos dois lados (uma face para quem olha de +z, outra para quem olha de -z),
	 * em planos separados para nao brigar na profundidade, independente do culling do render type.
	 */
	private static void part(PoseStack.Pose pose, VertexConsumer c, int light, int overlay, float dz,
							 float ox, float oy, float s, int dx, int dy, int dw, int dh,
							 int u, int v, int uw, int vh) {
		float x0 = ox + dx * s, x1 = ox + (dx + dw) * s;
		float y1 = oy - dy * s, y0 = oy - (dy + dh) * s;
		float ua = u / 64F, ub = (u + uw) / 64F, va = v / 64F, vb = (v + vh) / 64F;
		float zf = 0.5F + 0.003F + dz;
		float zb = 0.5F - 0.003F - dz;
		// frente (vista de +z): sentido anti-horario
		vertex(pose, c, light, overlay, x0, y1, zf, ua, va, 0, 0, 1);
		vertex(pose, c, light, overlay, x0, y0, zf, ua, vb, 0, 0, 1);
		vertex(pose, c, light, overlay, x1, y0, zf, ub, vb, 0, 0, 1);
		vertex(pose, c, light, overlay, x1, y1, zf, ub, va, 0, 0, 1);
		// verso (vista de -z): espelhado em x, para a imagem continuar certa
		vertex(pose, c, light, overlay, x1, y1, zb, ua, va, 0, 0, -1);
		vertex(pose, c, light, overlay, x1, y0, zb, ua, vb, 0, 0, -1);
		vertex(pose, c, light, overlay, x0, y0, zb, ub, vb, 0, 0, -1);
		vertex(pose, c, light, overlay, x0, y1, zb, ub, va, 0, 0, -1);
	}

	private static void vertex(PoseStack.Pose pose, VertexConsumer c, int light, int overlay,
							   float x, float y, float z, float u, float v, float nx, float ny, float nz) {
		c.addVertex(pose, x, y, z)
				.setColor(0xFFFFFFFF)
				.setUv(u, v)
				.setOverlay(overlay)
				.setLight(light)
				.setNormal(pose, nx, ny, nz);
	}

	// ------------------------------------------------------------ registro do tipo "dnd:mini_figure"

	public record Unbaked(boolean flat) implements SpecialModelRenderer.Unbaked<MiniData> {
		public static final MapCodec<Unbaked> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
				Codec.BOOL.optionalFieldOf("flat", true).forGetter(Unbaked::flat)
		).apply(i, Unbaked::new));

		@Override
		public SpecialModelRenderer<MiniData> bake(SpecialModelRenderer.BakingContext context) {
			return new MiniFigureSpecialRenderer(flat);
		}

		@Override
		public MapCodec<Unbaked> type() {
			return CODEC;
		}
	}
}
