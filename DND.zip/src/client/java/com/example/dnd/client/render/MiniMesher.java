package com.example.dnd.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;

/**
 * Draws a Minecraft player model (head, body, arms, legs + the second skin layer) as a tiny figure.
 * Model space is in skin pixels: x+ = the character's right, y+ = up, front faces -z (toward the default camera).
 * Face and UV layout follow the standard 64x64 skin.
 */
public final class MiniMesher {
	private final PoseStack.Pose pose;
	private final VertexConsumer c;
	private final int light;
	private final float cx, cy, cz, px;
	private final int rot;

	private MiniMesher(PoseStack.Pose pose, VertexConsumer c, int light, float cx, float cy, float cz, float px, int rot) {
		this.pose = pose;
		this.c = c;
		this.light = light;
		this.cx = cx;
		this.cy = cy;
		this.cz = cz;
		this.px = px;
		this.rot = rot & 3;
	}

	/** @param cx,cy,cz block-local point at the center of the figure's feet; px = size of one skin pixel */
	public static void emit(PoseStack.Pose pose, VertexConsumer c, boolean slim, float cx, float cy, float cz,
							float px, int rot, int light) {
		MiniMesher m = new MiniMesher(pose, c, light, cx, cy, cz, px, rot);
		int aw = slim ? 3 : 4;
		// base layer
		m.cuboid(-4, 12, -2, 8, 12, 4, 0, 16, 16);       // body
		m.cuboid(-4, 24, -4, 8, 8, 8, 0, 0, 0);          // head
		m.cuboid(0, 0, -2, 4, 12, 4, 0, 0, 16);          // right leg
		m.cuboid(-4, 0, -2, 4, 12, 4, 0, 16, 48);        // left leg
		m.cuboid(4, 12, -2, aw, 12, 4, 0, 40, 16);       // right arm
		m.cuboid(-4 - aw, 12, -2, aw, 12, 4, 0, 32, 48); // left arm
		// outer layer (slightly inflated)
		float i = 0.5F;
		m.cuboid(-4, 12, -2, 8, 12, 4, i, 16, 32);
		m.cuboid(-4, 24, -4, 8, 8, 8, i, 32, 0);
		m.cuboid(0, 0, -2, 4, 12, 4, i, 0, 32);
		m.cuboid(-4, 0, -2, 4, 12, 4, i, 0, 48);
		m.cuboid(4, 12, -2, aw, 12, 4, i, 40, 32);
		m.cuboid(-4 - aw, 12, -2, aw, 12, 4, i, 48, 48);
	}

	private void cuboid(float x0, float y0, float z0, float sx, float sy, float sz, float inf, int u, int v) {
		float X0 = x0 - inf, X1 = x0 + sx + inf, Y0 = y0 - inf, Y1 = y0 + sy + inf, Z0 = z0 - inf, Z1 = z0 + sz + inf;
		float lx = X1 - X0, ly = Y1 - Y0, lz = Z1 - Z0;
		// front (-z)
		face(X1, Y1, Z0, -1, 0, 0, 0, -1, 0, lx, ly, u + sz, v + sz, sx, sy);
		// back (+z)
		face(X0, Y1, Z1, 1, 0, 0, 0, -1, 0, lx, ly, u + 2 * sz + sx, v + sz, sx, sy);
		// character's right side (+x)
		face(X1, Y1, Z1, 0, 0, -1, 0, -1, 0, lz, ly, u, v + sz, sz, sy);
		// character's left side (-x)
		face(X0, Y1, Z0, 0, 0, 1, 0, -1, 0, lz, ly, u + sz + sx, v + sz, sz, sy);
		// top (+y)
		face(X1, Y1, Z1, -1, 0, 0, 0, 0, -1, lx, lz, u + sz, v, sx, sz);
		// bottom (-y)
		face(X1, Y0, Z0, -1, 0, 0, 0, 0, 1, lx, lz, u + sz + sx, v, sx, sz);
	}

	/**
	 * One quad. (tx,ty,tz) is the top-left corner seen from outside, R the "right" and D the "down" direction,
	 * w and h the lengths along them; (u0,v0,uw,vh) is the skin rectangle in pixels.
	 */
	private void face(float tx, float ty, float tz, float rx, float ry, float rz, float dx, float dy, float dz,
					  float w, float h, float u0, float v0, float uw, float vh) {
		// outward normal = D x R
		float nx = dy * rz - dz * ry, ny = dz * rx - dx * rz, nz = dx * ry - dy * rx;
		float blx = tx + dx * h, bly = ty + dy * h, blz = tz + dz * h;
		float brx = blx + rx * w, bry = bly + ry * w, brz = blz + rz * w;
		float trx = tx + rx * w, try_ = ty + ry * w, trz = tz + rz * w;
		float ua = u0 / 64F, ub = (u0 + uw) / 64F, va = v0 / 64F, vb = (v0 + vh) / 64F;
		vertex(tx, ty, tz, ua, va, nx, ny, nz);
		vertex(blx, bly, blz, ua, vb, nx, ny, nz);
		vertex(brx, bry, brz, ub, vb, nx, ny, nz);
		vertex(trx, try_, trz, ub, va, nx, ny, nz);
	}

	/** Quarter turns about the figure's vertical axis. */
	private float rx(float x, float z) {
		return switch (rot) {
			case 1 -> -z;
			case 2 -> -x;
			case 3 -> z;
			default -> x;
		};
	}

	private float rz(float x, float z) {
		return switch (rot) {
			case 1 -> x;
			case 2 -> -z;
			case 3 -> -x;
			default -> z;
		};
	}

	private void vertex(float x, float y, float z, float u, float v, float nx, float ny, float nz) {
		c.addVertex(pose, cx + rx(x, z) * px, cy + y * px, cz + rz(x, z) * px)
				.setColor(0xFFFFFFFF)
				.setUv(u, v)
				.setOverlay(OverlayTexture.NO_OVERLAY)
				.setLight(light)
				.setNormal(pose, rx(nx, nz), ny, rz(nx, nz));
	}
}
