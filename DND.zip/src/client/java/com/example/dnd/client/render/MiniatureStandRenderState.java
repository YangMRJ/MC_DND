package com.example.dnd.client.render;

import com.example.dnd.block.MiniData;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;

public class MiniatureStandRenderState extends BlockEntityRenderState {
	public MiniData miniature = MiniData.steve();
	public int rotation;
}
