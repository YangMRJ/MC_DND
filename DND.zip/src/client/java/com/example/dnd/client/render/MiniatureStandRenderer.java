package com.example.dnd.client.render;

import com.example.dnd.block.MiniatureStandBlock;
import com.example.dnd.block.MiniatureStandBlockEntity;
import com.example.dnd.client.MiniTextures;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.phys.Vec3;

public class MiniatureStandRenderer implements BlockEntityRenderer<MiniatureStandBlockEntity, MiniatureStandRenderState> {
	private static final float PIXEL = 0.018F;

	public MiniatureStandRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public MiniatureStandRenderState createRenderState() {
		return new MiniatureStandRenderState();
	}

	@Override
	public void extractRenderState(MiniatureStandBlockEntity be, MiniatureStandRenderState state, float partialTick,
								  Vec3 cameraPos, ModelFeatureRenderer.@org.jspecify.annotations.Nullable CrumblingOverlay crumblingOverlay) {
		BlockEntityRenderer.super.extractRenderState(be, state, partialTick, cameraPos, crumblingOverlay);
		state.miniature = be.miniature();
		state.rotation = switch (be.getBlockState().getValue(MiniatureStandBlock.FACING)) {
			case EAST -> 1;
			case SOUTH -> 2;
			case WEST -> 3;
			default -> 0;
		};
	}

	@Override
	public void submit(MiniatureStandRenderState state, PoseStack poseStack, SubmitNodeCollector collector,
					   CameraRenderState cameraState) {
		collector.submitCustomGeometry(poseStack, RenderTypes.entityCutout(MiniTextures.get(state.miniature)),
				(pose, consumer) -> MiniMesher.emit(pose, consumer, state.miniature.slim(),
						0.5F, 0, 0.5F, PIXEL, state.rotation, state.lightCoords));
	}
}
