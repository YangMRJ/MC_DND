package com.example.dnd.client.render;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;

public class PlacedItemRenderState extends EntityRenderState {
	public final ItemStackRenderState item = new ItemStackRenderState();
	/** A ficha de personagem e uma folha: deita sobre a mesa em vez de ficar de pe. */
	public boolean flat;
	public float rot;
}
