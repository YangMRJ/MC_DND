package com.example.dnd.client.render;

import com.example.dnd.entity.PlacedItemEntity;
import com.example.dnd.sheet.SheetItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Desenha o item pousado na mesa com o mesmo modelo 3D que ele tem na mao (o ramo "fallback" de assets/dnd/items/*.json,
 * que e o que vale para contextos como NONE), em escala pequena. A caixa de miniaturas mostra as minis dentro.
 */
public class PlacedItemRenderer extends EntityRenderer<PlacedItemEntity, PlacedItemRenderState> {
	/** Os modelos 3D ocupam 1 bloco; na mesa ficam com ~0,28. */
	private static final float SCALE = 0.28F;
	private static final float SHEET_SCALE = 0.34F;

	public PlacedItemRenderer(EntityRendererProvider.Context context) {
		super(context);
	}

	@Override
	public PlacedItemRenderState createRenderState() {
		return new PlacedItemRenderState();
	}

	@Override
	public void extractRenderState(PlacedItemEntity entity, PlacedItemRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		ItemStack stack = entity.getStack();
		state.rot = entity.getYRot(partialTick);
		state.flat = stack.is(SheetItems.CHARACTER_SHEET);
		if (stack.isEmpty()) {
			state.item.clear();
		} else {
			Minecraft.getInstance().getItemModelResolver()
					.updateForNonLiving(state.item, stack, ItemDisplayContext.NONE, entity);
		}
	}

	@Override
	public void submit(PlacedItemRenderState state, PoseStack poseStack, SubmitNodeCollector collector,
					   CameraRenderState cameraState) {
		super.submit(state, poseStack, collector, cameraState);
		if (state.item.isEmpty()) return;
		poseStack.pushPose();
		// o lado da frente do item (o fecho das caixas, o topo da ficha) fica virado para quem colocou
		poseStack.mulPose(Axis.YP.rotationDegrees(-state.rot));
		if (state.flat) {
			poseStack.translate(0.0F, 0.01F, 0.0F);
			poseStack.scale(SHEET_SCALE, SHEET_SCALE, SHEET_SCALE);
			poseStack.mulPose(Axis.XP.rotationDegrees(-90.0F)); // deita a folha sobre a mesa
		} else {
			poseStack.scale(SCALE, SCALE, SCALE);
			// o modelo ja vem centrado na origem (de -0,5 a +0,5): sobe meio bloco para a base ficar no chao
			poseStack.translate(0.0F, 0.5F, 0.0F);
		}
		state.item.submit(poseStack, collector, state.lightCoords, OverlayTexture.NO_OVERLAY, 0);
		poseStack.popPose();
	}
}
