package com.example.dnd.client.render;

import com.example.dnd.block.BoardBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

/** Builds the map: one colored column per cell (with a thin gap showing the wooden board) plus props. */
public final class TerrainMesher {
	public static final int[] TILE_RGB = {
			0x5DA13C, // grama
			0x8A8A8A, // pedra
			0xDCC98A, // areia
			0x3A6FD8, // agua
			0x7A5230, // terra
			0xA9794A, // piso de madeira
			0xF0F4F8, // neve
			0xE8661A  // lava
	};
	public static final String[] TILE_NAMES = {"Grama", "Pedra", "Areia", "Água", "Terra", "Madeira", "Neve", "Lava"};
	public static final String[] PROP_NAMES = {"Remover", "Árvore", "Pedra", "Baú", "Fogueira", "Muro", "Pilar"};

	private static final float GAP = BoardRenderer.CELL * 0.025F;

	private TerrainMesher() {
	}

	/** Top surface of a cell, in block-local Y. Water and lava sit a little lower than the ground. */
	public static float surface(int tile, int height) {
		float y = BoardRenderer.BASE + BoardRenderer.LEVEL * (height + 1);
		if (tile == 3) y -= BoardRenderer.LEVEL * 0.35F;
		if (tile == 7) y -= BoardRenderer.LEVEL * 0.2F;
		return y;
	}

	public static void emit(PoseStack.Pose pose, VertexConsumer c, int light, byte[] tiles, byte[] heights, byte[] props) {
		final float cell = BoardRenderer.CELL;
		final int n = BoardBlockEntity.SIZE;
		for (int z = 0; z < n; z++) {
			for (int x = 0; x < n; x++) {
				int i = z * n + x;
				float x0 = BoardRenderer.ORIGIN + x * cell + GAP, z0 = BoardRenderer.ORIGIN + z * cell + GAP;
				float x1 = x0 + cell - 2 * GAP, z1 = z0 + cell - 2 * GAP;
				float top = surface(tiles[i], heights[i]);
				int rgb = TILE_RGB[tiles[i]];
				// subtle checkerboard so the grid reads even on flat ground
				if (((x + z) & 1) == 1) rgb = BoxMesher.shade(rgb, 0.93F) & 0xFFFFFF;
				BoxMesher.box(pose, c, rgb, light, x0, BoardRenderer.BASE, z0, x1, top, z1, false);

				if (props[i] != 0) {
					prop(pose, c, light, props[i], x0 - GAP, top, z0 - GAP);
				}
			}
		}
	}

	/** Box in cell-relative units (1.0 = one cell), standing on y0. */
	private static void cb(PoseStack.Pose pose, VertexConsumer c, int light, int rgb, float ox, float y0, float oz,
						   float ax, float ay, float az, float bx, float by, float bz) {
		float s = BoardRenderer.CELL;
		BoxMesher.box(pose, c, rgb, light, ox + ax * s, y0 + ay * s, oz + az * s, ox + bx * s, y0 + by * s, oz + bz * s, false);
	}

	private static void prop(PoseStack.Pose pose, VertexConsumer c, int light, int id, float ox, float y0, float oz) {
		switch (id) {
			case BoardBlockEntity.PROP_TREE -> {
				cb(pose, c, light, 0x6B4A2A, ox, y0, oz, 0.40F, 0F, 0.40F, 0.60F, 1.0F, 0.60F);
				cb(pose, c, light, 0x2F7A2F, ox, y0, oz, 0.12F, 0.8F, 0.12F, 0.88F, 1.7F, 0.88F);
				cb(pose, c, light, 0x3C9438, ox, y0, oz, 0.27F, 1.7F, 0.27F, 0.73F, 2.3F, 0.73F);
			}
			case BoardBlockEntity.PROP_ROCK -> {
				cb(pose, c, light, 0x7C7C7C, ox, y0, oz, 0.18F, 0F, 0.25F, 0.80F, 0.45F, 0.75F);
				cb(pose, c, light, 0x929292, ox, y0, oz, 0.34F, 0.45F, 0.38F, 0.66F, 0.65F, 0.62F);
			}
			case BoardBlockEntity.PROP_CHEST -> {
				cb(pose, c, light, 0x8B5A2B, ox, y0, oz, 0.2F, 0F, 0.3F, 0.8F, 0.45F, 0.7F);
				cb(pose, c, light, 0x6E4520, ox, y0, oz, 0.2F, 0.45F, 0.3F, 0.8F, 0.62F, 0.7F);
				cb(pose, c, light, 0xFFD54A, ox, y0, oz, 0.45F, 0.35F, 0.27F, 0.55F, 0.52F, 0.30F);
			}
			case BoardBlockEntity.PROP_FIRE -> {
				cb(pose, c, light, 0x5A3A1C, ox, y0, oz, 0.20F, 0F, 0.42F, 0.80F, 0.14F, 0.58F);
				cb(pose, c, light, 0x4A2F16, ox, y0, oz, 0.42F, 0F, 0.20F, 0.58F, 0.14F, 0.80F);
				cb(pose, c, light, 0xFF8A1E, ox, y0, oz, 0.38F, 0.14F, 0.38F, 0.62F, 0.50F, 0.62F);
				cb(pose, c, light, 0xFFD23A, ox, y0, oz, 0.45F, 0.30F, 0.45F, 0.55F, 0.65F, 0.55F);
			}
			case BoardBlockEntity.PROP_WALL -> {
				cb(pose, c, light, 0x7A7A7A, ox, y0, oz, 0.0F, 0F, 0.0F, 1.0F, 1.8F, 1.0F);
				cb(pose, c, light, 0x909090, ox, y0, oz, 0.0F, 1.8F, 0.0F, 1.0F, 2.0F, 1.0F);
			}
			case BoardBlockEntity.PROP_PILLAR -> {
				cb(pose, c, light, 0xD9D2C3, ox, y0, oz, 0.22F, 0F, 0.22F, 0.78F, 0.18F, 0.78F);
				cb(pose, c, light, 0xEDE7DA, ox, y0, oz, 0.30F, 0.18F, 0.30F, 0.70F, 2.3F, 0.70F);
				cb(pose, c, light, 0xD9D2C3, ox, y0, oz, 0.22F, 2.3F, 0.22F, 0.78F, 2.5F, 0.78F);
			}
			default -> {
			}
		}
	}

	/** A thin round-ish pedestal under a miniature. */
	public static void base(PoseStack.Pose pose, VertexConsumer c, int light, float cx, float y0, float cz) {
		float h = BoardRenderer.CELL * 0.45F;
		BoxMesher.box(pose, c, 0x2B2118, light, cx - h, y0, cz - h, cx + h, y0 + BoardRenderer.MINI_BASE, cz + h, false);
		float h2 = h - BoardRenderer.CELL * 0.03F;
		BoxMesher.box(pose, c, 0x4A3A28, light, cx - h2, y0 + BoardRenderer.MINI_BASE * 0.8F, cz - h2, cx + h2,
				y0 + BoardRenderer.MINI_BASE + 0.0004F, cz + h2, false);
	}
}
