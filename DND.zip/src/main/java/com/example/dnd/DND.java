package com.example.dnd;

import com.example.dnd.network.BoardNetworking;
import com.example.dnd.box.MiniBoxStore;
import com.example.dnd.network.DiceNetworking;
import com.example.dnd.network.MiniBoxNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DND implements ModInitializer {
	public static final String MOD_ID = "dnd";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModBlocks.initialize();
		ModEntities.initialize();
		ModItems.initialize();
		ModBlockEntities.initialize();
		BoardNetworking.register();
		DiceNetworking.register();
		MiniBoxNetworking.register();
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> MiniBoxStore.clearCache());
		LOGGER.info("DND tabletop board loaded");
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
