package com.example.dnd;

import com.example.dnd.block.BoardBlockEntity;
import com.example.dnd.block.MiniatureStandBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.entity.BlockEntityType;

public class ModBlockEntities {
	public static final BlockEntityType<BoardBlockEntity> BOARD = Registry.register(
			BuiltInRegistries.BLOCK_ENTITY_TYPE,
			DND.id("board"),
			FabricBlockEntityTypeBuilder.<BoardBlockEntity>create(BoardBlockEntity::new, ModBlocks.BOARD).build()
	);
	public static final BlockEntityType<MiniatureStandBlockEntity> MINIATURE_STAND = Registry.register(
			BuiltInRegistries.BLOCK_ENTITY_TYPE,
			DND.id("miniature_stand"),
			FabricBlockEntityTypeBuilder.<MiniatureStandBlockEntity>create(MiniatureStandBlockEntity::new, ModBlocks.MINIATURE_STAND).build()
	);

	public static void initialize() {
	}
}
