package com.example.dnd;

import com.example.dnd.entity.MiniFigureEntity;
import com.example.dnd.entity.PlacedItemEntity;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public class ModEntities {
	private static final ResourceKey<EntityType<?>> MINI_FIGURE_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DND.id("mini_figure"));

	/** Uma miniatura em pe: ~0,19 bloco de largura por ~0,38 de altura. */
	public static final EntityType<MiniFigureEntity> MINI_FIGURE = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			MINI_FIGURE_KEY,
			EntityType.Builder.<MiniFigureEntity>of(MiniFigureEntity::new, MobCategory.MISC)
					.sized(0.22F, 0.4F)
					.clientTrackingRange(8)
					.updateInterval(10)
					.fireImmune()
					.noSummon()
					.noLootTable()
					.build(MINI_FIGURE_KEY)
	);

	private static final ResourceKey<EntityType<?>> PLACED_ITEM_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DND.id("placed_item"));

	/** Caixa de dados, caixa de minis ou ficha pousada na mesa: pequena (~0,3 bloco), vários por bloco. */
	public static final EntityType<PlacedItemEntity> PLACED_ITEM = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			PLACED_ITEM_KEY,
			EntityType.Builder.<PlacedItemEntity>of(PlacedItemEntity::new, MobCategory.MISC)
					.sized(0.3F, 0.16F)
					.clientTrackingRange(8)
					.updateInterval(10)
					.fireImmune()
					.noSummon()
					.noLootTable()
					.build(PLACED_ITEM_KEY)
	);

	public static void initialize() {
	}
}
