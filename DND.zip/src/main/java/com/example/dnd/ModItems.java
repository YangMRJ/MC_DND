package com.example.dnd;

import com.example.dnd.block.MiniData;
import com.example.dnd.item.MiniBoxItem;
import com.example.dnd.item.MiniFigureItem;
import com.example.dnd.item.DiceBoxItem;
import java.util.function.Function;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public class ModItems {
	public static final Item DICE_BOX = register(
			"dice_box",
			DiceBoxItem::new,
			new Item.Properties().useItemDescriptionPrefix().stacksTo(1)
	);

	public static final Item MINIATURE_BOX = register(
			"miniature_box",
			MiniBoxItem::new,
			new Item.Properties().useItemDescriptionPrefix().stacksTo(1)
	);

	/** Uma miniatura solta (tirada da caixa). Cada uma carrega a skin dela. */
	public static final Item MINIATURE = register(
			"miniature",
			MiniFigureItem::new,
			new Item.Properties().useItemDescriptionPrefix().stacksTo(16)
	);

	private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
		Identifier id = DND.id(name);
		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
		T item = factory.apply(props.setId(itemKey));
		return Registry.register(BuiltInRegistries.ITEM, itemKey, item);
	}

	public static void initialize() {
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS)
				.register(tab -> {
					tab.accept(MINIATURE_BOX);
					tab.accept(DICE_BOX);
					tab.accept(MiniFigureItem.create(MiniData.steve()));
				});
	}
}
