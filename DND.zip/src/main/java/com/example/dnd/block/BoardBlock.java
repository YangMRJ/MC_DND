package com.example.dnd.block;

import com.mojang.serialization.MapCodec;
import com.example.dnd.item.MiniBoxItem;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jspecify.annotations.Nullable;

public class BoardBlock extends BaseEntityBlock {
	private static final VoxelShape SHAPE = Block.box(-6, 0, -6, 22, 2, 22);

	/** Set by the client entrypoint; opens the top-view screen. Does nothing on a dedicated server. */
	public static Consumer<BlockPos> clientOpener = pos -> {};

	public BoardBlock(Properties properties) {
		super(properties);
	}

	@Override
	protected MapCodec<? extends BaseEntityBlock> codec() {
		return simpleCodec(BoardBlock::new);
	}

	@Nullable
	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new BoardBlockEntity(pos, state);
	}

	@Override
	protected RenderShape getRenderShape(BlockState state) {
		return RenderShape.MODEL;
	}

	@Override
	protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
		return SHAPE;
	}

	/** Holding a miniature box and right-clicking the board attaches the box's miniatures to it. */
	@Override
	protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
										  InteractionHand hand, BlockHitResult hit) {
		if (!(stack.getItem() instanceof MiniBoxItem)) {
			return InteractionResult.TRY_WITH_EMPTY_HAND;
		}
		if (!level.isClientSide() && level.getBlockEntity(pos) instanceof BoardBlockEntity board) {
			var server = level.getServer();
			List<MiniData> minis = MiniBoxItem.boardRoster(server, stack);
			Component msg;
			if (minis.isEmpty()) {
				msg = Component.literal("A aba ativa da caixa está vazia.");
			} else {
				board.setRoster(minis);
				String tab = MiniBoxItem.box(server, stack).activeTab().name;
				msg = Component.literal("Aba \"" + tab + "\" acoplada ao tabuleiro: " + minis.size() + " (máx. " + MiniData.MAX + ")");
			}
			if (player instanceof ServerPlayer sp) sp.sendSystemMessage(msg, true);
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (level.isClientSide()) {
			clientOpener.accept(pos);
		}
		return InteractionResult.SUCCESS;
	}
}
