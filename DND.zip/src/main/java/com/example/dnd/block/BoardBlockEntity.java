package com.example.dnd.block;

import com.example.dnd.ModBlockEntities;
import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/** The map (terrain, props), the attached miniature roster and the miniatures standing on the board. */
public class BoardBlockEntity extends BlockEntity {
	public static final int SIZE = 12;
	public static final int MAX_HEIGHT = 4;
	public static final int TILES = 8;
	public static final int PROPS = 7;

	// prop ids (0 = none)
	public static final int PROP_TREE = 1, PROP_ROCK = 2, PROP_CHEST = 3, PROP_FIRE = 4, PROP_WALL = 5, PROP_PILLAR = 6;

	public record Token(int id, int x, int z, int mini, int rot) {
	}

	private final List<Token> tokens = new ArrayList<>();
	private final List<MiniData> roster = new ArrayList<>();
	private final byte[] tile = new byte[SIZE * SIZE];
	private final byte[] height = new byte[SIZE * SIZE];
	private final byte[] prop = new byte[SIZE * SIZE];
	private int nextId = 1;

	public BoardBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.BOARD, pos, state);
		roster.add(MiniData.steve());
	}

	// ------------------------------------------------------------ cells

	public static int pack(int tile, int height, int prop) {
		return (tile & 15) | ((height & 7) << 4) | ((prop & 15) << 8);
	}

	private static int idx(int x, int z) {
		return z * SIZE + x;
	}

	private static boolean inBounds(int x, int z) {
		return x >= 0 && z >= 0 && x < SIZE && z < SIZE;
	}

	public int tileAt(int x, int z) {
		return tile[idx(x, z)];
	}

	public int heightAt(int x, int z) {
		return height[idx(x, z)];
	}

	public int propAt(int x, int z) {
		return prop[idx(x, z)];
	}

	public byte[] tilesSnapshot() {
		return tile.clone();
	}

	public byte[] heightsSnapshot() {
		return height.clone();
	}

	public byte[] propsSnapshot() {
		return prop.clone();
	}

	private static boolean blocks(int prop) {
		return prop == PROP_TREE || prop == PROP_WALL || prop == PROP_PILLAR;
	}

	public boolean setCell(int x, int z, int packed) {
		if (!inBounds(x, z)) return false;
		int t = packed & 15, h = (packed >> 4) & 7, p = (packed >> 8) & 15;
		if (t >= TILES || h > MAX_HEIGHT || p >= PROPS) return false;
		int i = idx(x, z);
		tile[i] = (byte) t;
		height[i] = (byte) h;
		prop[i] = (byte) p;
		if (blocks(p)) {
			Token on = tokenAt(x, z);
			if (on != null) tokens.remove(on);
		}
		setChanged();
		return true;
	}

	public void fill(int tileId) {
		if (tileId < 0 || tileId >= TILES) return;
		for (int i = 0; i < tile.length; i++) tile[i] = (byte) tileId;
		setChanged();
	}

	public void resetMap() {
		for (int i = 0; i < tile.length; i++) {
			tile[i] = 0;
			height[i] = 0;
			prop[i] = 0;
		}
		setChanged();
	}

	// ------------------------------------------------------------ roster

	public List<MiniData> getRoster() {
		return Collections.unmodifiableList(roster);
	}

	public void setRoster(List<MiniData> minis) {
		roster.clear();
		for (int i = 0; i < Math.min(MiniData.MAX, minis.size()); i++) roster.add(minis.get(i));
		tokens.removeIf(t -> t.mini() >= roster.size());
		setChanged();
	}

	// ------------------------------------------------------------ tokens

	public List<Token> getTokens() {
		return Collections.unmodifiableList(tokens);
	}

	public Token tokenAt(int x, int z) {
		for (Token t : tokens) {
			if (t.x() == x && t.z() == z) return t;
		}
		return null;
	}

	public Token tokenById(int id) {
		for (Token t : tokens) {
			if (t.id() == id) return t;
		}
		return null;
	}

	private boolean free(int x, int z) {
		return inBounds(x, z) && tokenAt(x, z) == null && !blocks(prop[idx(x, z)]);
	}

	public boolean addToken(int x, int z, int mini) {
		if (mini < 0 || mini >= roster.size() || !free(x, z)) return false;
		tokens.add(new Token(nextId++, x, z, mini, 0));
		setChanged();
		return true;
	}

	public boolean moveToken(int id, int x, int z) {
		Token t = tokenById(id);
		if (t == null || !free(x, z)) return false;
		tokens.set(tokens.indexOf(t), new Token(t.id(), x, z, t.mini(), t.rot()));
		setChanged();
		return true;
	}

	public boolean rotateToken(int id) {
		Token t = tokenById(id);
		if (t == null) return false;
		tokens.set(tokens.indexOf(t), new Token(t.id(), t.x(), t.z(), t.mini(), (t.rot() + 1) & 3));
		setChanged();
		return true;
	}

	public boolean removeToken(int id) {
		Token t = tokenById(id);
		if (t == null) return false;
		tokens.remove(t);
		setChanged();
		return true;
	}

	public void clearTokens() {
		tokens.clear();
		setChanged();
	}

	// ------------------------------------------------------------ persistence / sync

	@Override
	protected void saveAdditional(ValueOutput output) {
		List<Integer> flat = new ArrayList<>();
		for (Token t : tokens) {
			flat.add(t.id());
			flat.add(t.x());
			flat.add(t.z());
			flat.add(t.mini());
			flat.add(t.rot());
		}
		output.store("tokens2", Codec.INT.listOf(), flat);
		output.putInt("next_id", nextId);

		StringBuilder cells = new StringBuilder(tile.length * 3);
		for (int i = 0; i < tile.length; i++) {
			cells.append((char) ('A' + tile[i])).append((char) ('A' + height[i])).append((char) ('A' + prop[i]));
		}
		output.putString("cells", cells.toString());

		output.putInt("roster_n", roster.size());
		for (int i = 0; i < roster.size(); i++) {
			MiniData m = roster.get(i);
			output.putString("rname" + i, m.name());
			output.putString("rskin" + i, MiniData.encodePng(m.png()));
			output.putBoolean("rslim" + i, m.slim());
		}
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		tokens.clear();
		input.read("tokens2", Codec.INT.listOf()).ifPresent(flat -> {
			for (int i = 0; i + 4 < flat.size(); i += 5) {
				tokens.add(new Token(flat.get(i), flat.get(i + 1), flat.get(i + 2), flat.get(i + 3), flat.get(i + 4) & 3));
			}
		});
		nextId = input.getIntOr("next_id", 1);

		String cells = input.getStringOr("cells", "");
		if (cells.length() == tile.length * 3) {
			for (int i = 0; i < tile.length; i++) {
				int t = cells.charAt(i * 3) - 'A', h = cells.charAt(i * 3 + 1) - 'A', p = cells.charAt(i * 3 + 2) - 'A';
				tile[i] = (byte) (t >= 0 && t < TILES ? t : 0);
				height[i] = (byte) (h >= 0 && h <= MAX_HEIGHT ? h : 0);
				prop[i] = (byte) (p >= 0 && p < PROPS ? p : 0);
			}
		}

		if (input.getIntOr("roster_n", -1) >= 0) {
			roster.clear();
			int n = Math.min(MiniData.MAX, input.getIntOr("roster_n", 0));
			for (int i = 0; i < n; i++) {
				roster.add(new MiniData(
						input.getStringOr("rname" + i, "Mini"),
						MiniData.decodePng(input.getStringOr("rskin" + i, "")),
						input.getBooleanOr("rslim" + i, false)));
			}
		}
		tokens.removeIf(t -> t.mini() >= roster.size());
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registryLookup) {
		return saveWithoutMetadata(registryLookup);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}
}
