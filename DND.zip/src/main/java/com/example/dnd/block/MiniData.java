package com.example.dnd.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.HexFormat;

/** A miniature: a name, an optional custom 64x64 skin PNG (empty = default Steve) and the arm model. */
public final class MiniData {
	/** Quantas minis o tabuleiro e a pre-visualizacao da caixa mostram (a caixa em si nao tem limite pratico). */
	public static final int MAX = 8;
	/** Trava de seguranca por caixa, so para um cliente malicioso nao encher o disco. */
	public static final int MAX_TOTAL = 5000;
	public static final int MAX_PNG = 12 * 1024;
	public static final int MAX_NAME = 16;

	private final String name;
	private final byte[] png;
	private final boolean slim;
	private String hash;

	public MiniData(String name, byte[] png, boolean slim) {
		this.name = cleanName(name);
		this.png = png == null ? new byte[0] : png.clone();
		this.slim = slim;
	}

	public static MiniData steve() {
		return new MiniData("Steve", new byte[0], false);
	}

	public String name() {
		return name;
	}

	public byte[] png() {
		return png;
	}

	public boolean slim() {
		return slim;
	}

	public boolean isDefault() {
		return png.length == 0;
	}

	public MiniData withName(String n) {
		return new MiniData(n, png, slim);
	}

	public MiniData withSlim(boolean s) {
		return new MiniData(name, png, s);
	}

	/** Stable id of the skin, used to cache textures on the client. */
	public String hash() {
		if (hash == null) {
			if (png.length == 0) {
				hash = slim ? "steve_slim" : "steve_wide";
			} else {
				try {
					hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-1").digest(png));
				} catch (Exception e) {
					hash = Integer.toHexString(Arrays.hashCode(png)) + "_" + png.length;
				}
			}
		}
		return hash;
	}

	public static String cleanName(String s) {
		if (s == null) return "Mini";
		StringBuilder b = new StringBuilder();
		for (char c : s.toCharArray()) {
			if (c >= 32 && c != 127 && c != '\u00a7') b.append(c);
		}
		String r = b.toString().trim();
		if (r.length() > MAX_NAME) r = r.substring(0, MAX_NAME).trim();
		return r.isEmpty() ? "Mini" : r;
	}

	/** Server-side sanity check: PNG signature, size limit and a 64x64 image. Never trusts the client. */
	public static boolean validPng(byte[] b) {
		if (b == null || b.length < 33 || b.length > MAX_PNG) return false;
		byte[] magic = {(byte) 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};
		for (int i = 0; i < 8; i++) {
			if (b[i] != magic[i]) return false;
		}
		// first chunk must be IHDR, width at 16..19, height at 20..23 (big endian)
		if (b[12] != 'I' || b[13] != 'H' || b[14] != 'D' || b[15] != 'R') return false;
		int w = ((b[16] & 255) << 24) | ((b[17] & 255) << 16) | ((b[18] & 255) << 8) | (b[19] & 255);
		int h = ((b[20] & 255) << 24) | ((b[21] & 255) << 16) | ((b[22] & 255) << 8) | (b[23] & 255);
		return w == 64 && h == 64;
	}

	public static String encodePng(byte[] png) {
		return Base64.getEncoder().encodeToString(png);
	}

	public static byte[] decodePng(String s) {
		if (s == null || s.isEmpty()) return new byte[0];
		try {
			byte[] d = Base64.getDecoder().decode(s.getBytes(StandardCharsets.US_ASCII));
			return validPng(d) ? d : new byte[0];
		} catch (IllegalArgumentException e) {
			return new byte[0];
		}
	}
}
