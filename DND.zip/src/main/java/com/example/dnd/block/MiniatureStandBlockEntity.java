package com.example.dnd.block;

import com.example.dnd.ModBlockEntities;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

public class MiniatureStandBlockEntity extends BlockEntity {
	private MiniData miniature = MiniData.steve();

	public MiniatureStandBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntities.MINIATURE_STAND, pos, state);
	}

	public MiniData miniature() {
		return miniature;
	}

	public void setMiniature(MiniData mini) {
		miniature = mini;
		setChanged();
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		output.putString("mini_name", miniature.name());
		output.putString("mini_skin", MiniData.encodePng(miniature.png()));
		output.putBoolean("mini_slim", miniature.slim());
		super.saveAdditional(output);
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		miniature = new MiniData(
				input.getStringOr("mini_name", "Steve"),
				MiniData.decodePng(input.getStringOr("mini_skin", "")),
				input.getBooleanOr("mini_slim", false));
	}

	@Override
	public CompoundTag getUpdateTag(HolderLookup.Provider registryLookup) {
		return saveWithoutMetadata(registryLookup);
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override
	public void setChanged() {
		super.setChanged();
		if (level == null) return;
		BlockState state = getBlockState();
		level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
	}
}
