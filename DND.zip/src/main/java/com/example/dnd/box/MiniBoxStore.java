package com.example.dnd.box;

import com.example.dnd.block.MiniData;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

/**
 * Conteudo das caixas de miniaturas, guardado no servidor (pasta "dnd_boxes" do mundo), um arquivo por caixa.
 * O item so carrega o id da caixa e uma pre-visualizacao pequena, entao a caixa pode ter quantas minis e abas
 * quiser sem pesar no inventario nem nos pacotes.
 */
public final class MiniBoxStore {
	public static final int MAX_TABS = 64;
	public static final int MAX_TAB_NAME = 14;

	/** Uma aba: um nome e as minis dela. */
	public static final class Tab {
		public String name;
		public final List<MiniData> minis = new ArrayList<>();

		public Tab(String name) {
			this.name = cleanTabName(name);
		}
	}

	/** Uma caixa inteira: abas + qual aba esta ativa (a que o tabuleiro e a pre-visualizacao usam). */
	public static final class Box {
		public final List<Tab> tabs = new ArrayList<>();
		public int active;

		public Box() {
			tabs.add(new Tab("Geral"));
		}

		public Tab activeTab() {
			active = Math.max(0, Math.min(active, tabs.size() - 1));
			return tabs.get(active);
		}

		public int total() {
			int n = 0;
			for (Tab t : tabs) n += t.minis.size();
			return n;
		}
	}

	private static final Map<UUID, Box> CACHE = new HashMap<>();

	private MiniBoxStore() {
	}

	public static String cleanTabName(String s) {
		if (s == null) return "Aba";
		StringBuilder b = new StringBuilder();
		for (char c : s.toCharArray()) {
			if (c >= 32 && c != 127 && c != '\u00a7') b.append(c);
		}
		String r = b.toString().trim();
		if (r.length() > MAX_TAB_NAME) r = r.substring(0, MAX_TAB_NAME).trim();
		return r.isEmpty() ? "Aba" : r;
	}

	/** Chamar quando o servidor fecha: um mundo novo nao pode herdar o cache do anterior. */
	public static synchronized void clearCache() {
		CACHE.clear();
	}

	private static Path file(MinecraftServer server, UUID id) {
		return server.getWorldPath(LevelResource.ROOT).resolve("dnd_boxes").resolve(id + ".dat");
	}

	/** Caixa com esse id (carrega do disco na primeira vez; cria vazia se nao existir). */
	public static synchronized Box get(MinecraftServer server, UUID id) {
		Box cached = CACHE.get(id);
		if (cached != null) return cached;
		Box box = new Box();
		Path path = file(server, id);
		if (Files.exists(path)) {
			try {
				box = decode(NbtIo.readCompressed(path, NbtAccounter.unlimitedHeap()));
			} catch (IOException e) {
				com.example.dnd.DND.LOGGER.error("Nao consegui ler a caixa {}", id, e);
			}
		}
		CACHE.put(id, box);
		return box;
	}

	/** Registra uma caixa nova (migracao de caixas antigas, que guardavam as minis no proprio item). */
	public static synchronized void put(MinecraftServer server, UUID id, Box box) {
		CACHE.put(id, box);
		save(server, id, box);
	}

	public static synchronized void save(MinecraftServer server, UUID id, Box box) {
		Path path = file(server, id);
		try {
			Files.createDirectories(path.getParent());
			NbtIo.writeCompressed(encode(box), path);
		} catch (IOException e) {
			com.example.dnd.DND.LOGGER.error("Nao consegui salvar a caixa {}", id, e);
		}
	}

	// Formato plano (sem listas aninhadas): t<i>n = nome da aba, t<i>c = quantidade, t<i>m<j>n/s/l = mini.
	private static CompoundTag encode(Box box) {
		CompoundTag tag = new CompoundTag();
		tag.putInt("tabs", box.tabs.size());
		tag.putInt("active", box.active);
		for (int i = 0; i < box.tabs.size(); i++) {
			Tab t = box.tabs.get(i);
			tag.putString("t" + i + "n", t.name);
			tag.putInt("t" + i + "c", t.minis.size());
			for (int j = 0; j < t.minis.size(); j++) {
				MiniData m = t.minis.get(j);
				String k = "t" + i + "m" + j;
				tag.putString(k + "n", m.name());
				tag.putByteArray(k + "s", m.png());
				tag.putBoolean(k + "l", m.slim());
			}
		}
		return tag;
	}

	private static Box decode(CompoundTag tag) {
		Box box = new Box();
		box.tabs.clear();
		int tabs = Math.max(1, Math.min(MAX_TABS, tag.getIntOr("tabs", 1)));
		for (int i = 0; i < tabs; i++) {
			Tab t = new Tab(tag.getStringOr("t" + i + "n", "Aba"));
			int n = Math.min(MiniData.MAX_TOTAL, tag.getIntOr("t" + i + "c", 0));
			for (int j = 0; j < n; j++) {
				String k = "t" + i + "m" + j;
				byte[] png = tag.getByteArray(k + "s").orElse(new byte[0]);
				if (png.length > 0 && !MiniData.validPng(png)) png = new byte[0];
				t.minis.add(new MiniData(tag.getStringOr(k + "n", "Mini"), png, tag.getBooleanOr(k + "l", false)));
			}
			box.tabs.add(t);
		}
		box.active = Math.max(0, Math.min(tag.getIntOr("active", 0), box.tabs.size() - 1));
		return box;
	}
}
