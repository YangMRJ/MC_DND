package com.example.dnd.entity;

import com.example.dnd.block.MiniData;
import com.example.dnd.item.MiniBoxItem;
import com.example.dnd.item.MiniFigureItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

/**
 * Uma miniatura em pe no mundo. Guarda o proprio item (com a skin) num dado sincronizado, assim o cliente sabe
 * qual skin desenhar e quem quebra a figura recebe exatamente o mesmo item de volta.
 * <ul>
 *   <li>Clique direito com a caixa de miniaturas: guarda a figura na caixa.</li>
 *   <li>Agachado + clique direito: pega a figura como item.</li>
 *   <li>Clique direito: gira a figura 22,5 graus.</li>
 *   <li>Bater: quebra e solta o item.</li>
 * </ul>
 */
public class MiniFigureEntity extends Entity {
	private static final EntityDataAccessor<ItemStack> DATA_STACK =
			SynchedEntityData.defineId(MiniFigureEntity.class, EntityDataSerializers.ITEM_STACK);

	private ItemStack cachedStack = ItemStack.EMPTY;
	private MiniData cachedMini = MiniData.steve();

	public MiniFigureEntity(EntityType<? extends MiniFigureEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		builder.define(DATA_STACK, ItemStack.EMPTY);
	}

	public ItemStack getStack() {
		return this.entityData.get(DATA_STACK);
	}

	public void setStack(ItemStack stack) {
		this.entityData.set(DATA_STACK, stack);
	}

	/** A miniatura desta figura (com cache: o renderizador chama isso todo frame). */
	public MiniData getMini() {
		ItemStack stack = getStack();
		if (stack != cachedStack) {
			cachedStack = stack;
			cachedMini = stack.isEmpty() ? MiniData.steve() : MiniFigureItem.read(stack);
		}
		return cachedMini;
	}

	// ------------------------------------------------------------ comportamento

	@Override
	public boolean isPickable() {
		return true;
	}

	@Override
	public boolean canBeCollidedWith(Entity other) {
		return false;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	@Override
	public ItemStack getPickResult() {
		return getStack().copy();
	}

	@Override
	public void tick() {
		super.tick();
		// sem chao embaixo (bloco quebrado): a figura cai como item
		if (this.level() instanceof ServerLevel server && this.tickCount % 10 == 0) {
			if (server.noCollision(this, this.getBoundingBox().move(0.0D, -0.04D, 0.0D))) {
				this.spawnAtLocation(server, getStack().copy());
				this.discard();
			}
		}
	}

	@Override
	public InteractionResult interact(Player player, InteractionHand hand, Vec3 location) {
		if (!(this.level() instanceof ServerLevel server)) {
			return InteractionResult.SUCCESS;
		}
		ItemStack held = player.getItemInHand(hand);

		if (held.getItem() instanceof MiniBoxItem) {
			if (!MiniBoxItem.addMini(server.getServer(), held, getMini())) {
				message(player, "A caixa está lotada.");
			} else {
				server.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.ITEM_PICKUP,
						net.minecraft.sounds.SoundSource.PLAYERS, 0.5F, 1.3F);
				message(player, "Guardada na caixa: " + getMini().name() + " (" + MiniBoxItem.total(held) + " no total)");
				this.discard();
			}
			return InteractionResult.SUCCESS;
		}

		if (player.isShiftKeyDown()) {
			ItemStack stack = getStack().copy();
			if (!player.getInventory().add(stack)) {
				player.drop(stack, false);
			}
			server.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.ITEM_PICKUP,
					net.minecraft.sounds.SoundSource.PLAYERS, 0.5F, 1.0F);
			this.discard();
			return InteractionResult.SUCCESS;
		}

		this.setYRot(this.getYRot() + 22.5F);
		server.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.ITEM_FRAME_ROTATE_ITEM,
				net.minecraft.sounds.SoundSource.BLOCKS, 0.5F, 1.4F);
		return InteractionResult.SUCCESS;
	}

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		if (this.isRemoved() || this.isInvulnerableToBase(source)) return false;
		if (source.getEntity() instanceof Player player) {
			if (!player.hasInfiniteMaterials()) {
				this.spawnAtLocation(level, getStack().copy());
			}
			level.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.ARMOR_STAND_BREAK,
					net.minecraft.sounds.SoundSource.BLOCKS, 0.6F, 1.4F);
			this.discard();
			return true;
		}
		return false;
	}

	private static void message(Player player, String text) {
		if (player instanceof ServerPlayer sp) {
			sp.sendSystemMessage(Component.literal(text), true);
		}
	}

	// ------------------------------------------------------------ persistencia

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		output.store("stack", ItemStack.OPTIONAL_CODEC, getStack());
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		setStack(input.read("stack", ItemStack.OPTIONAL_CODEC).orElse(ItemStack.EMPTY));
	}
}
