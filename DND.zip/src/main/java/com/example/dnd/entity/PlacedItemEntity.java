package com.example.dnd.entity;

import com.example.dnd.ModEntities;
import com.example.dnd.ModItems;
import com.example.dnd.box.MiniBoxStore;
import com.example.dnd.item.MiniBoxItem;
import com.example.dnd.item.MiniFigureItem;
import com.example.dnd.sheet.SheetItems;
import java.util.function.Consumer;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

/**
 * Um item pousado na mesa (caixa de dados, caixa de miniaturas ou ficha de personagem). E pequeno, fica no ponto
 * exato do clique (da para botar nos cantinhos e varios no mesmo bloco) e continua funcionando:
 * <ul>
 *   <li>Clique direito: usa o item, como se estivesse na mao (rola dados, abre a caixa, abre a ficha).</li>
 *   <li>Clique direito com uma miniatura na mao, numa caixa: guarda a miniatura na caixa.</li>
 *   <li>Agachado + clique direito: pega o item de volta.</li>
 *   <li>Bater: quebra e solta o item.</li>
 * </ul>
 * Colocar: agachado + clique direito em cima de um bloco com o item na mao.
 */
public class PlacedItemEntity extends Entity {
	private static final EntityDataAccessor<ItemStack> DATA_STACK =
			SynchedEntityData.defineId(PlacedItemEntity.class, EntityDataSerializers.ITEM_STACK);

	/** Definido pelo cliente: abre a tela do item pousado. Nao faz nada no servidor dedicado. */
	public static Consumer<PlacedItemEntity> clientOpener = e -> {};

	public PlacedItemEntity(EntityType<? extends PlacedItemEntity> type, Level level) {
		super(type, level);
	}

	public static boolean isPlaceable(ItemStack stack) {
		return stack.is(ModItems.DICE_BOX) || stack.is(ModItems.MINIATURE_BOX) || stack.is(SheetItems.CHARACTER_SHEET);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		builder.define(DATA_STACK, ItemStack.EMPTY);
	}

	public ItemStack getStack() {
		return this.entityData.get(DATA_STACK);
	}

	public void setStack(ItemStack stack) {
		this.entityData.set(DATA_STACK, stack);
	}

	// ------------------------------------------------------------ colocar

	/** Poe o item da mao em cima do bloco clicado. */
	public static InteractionResult place(UseOnContext context) {
		Level level = context.getLevel();
		Player player = context.getPlayer();
		if (context.getClickedFace() != Direction.UP) {
			message(player, "Coloque o item em cima de um bloco.");
			return InteractionResult.FAIL;
		}
		if (!(level instanceof ServerLevel server)) {
			return InteractionResult.SUCCESS;
		}
		Vec3 hit = context.getClickLocation();
		PlacedItemEntity placed = new PlacedItemEntity(ModEntities.PLACED_ITEM, server);
		float yaw = player == null ? 0.0F : Math.round((player.getYRot() + 180.0F) / 22.5F) * 22.5F;
		placed.snapTo(hit.x, hit.y, hit.z, yaw, 0.0F);
		placed.setStack(context.getItemInHand().copyWithCount(1));
		if (!server.noCollision(placed)) {
			message(player, "Sem espaço para o item aqui.");
			return InteractionResult.FAIL;
		}
		server.addFreshEntity(placed);
		server.playSound(null, hit.x, hit.y, hit.z, SoundEvents.ARMOR_STAND_PLACE, SoundSource.BLOCKS, 0.5F, 1.5F);
		if (player != null) context.getItemInHand().consume(1, player);
		return InteractionResult.SUCCESS;
	}

	// ------------------------------------------------------------ comportamento

	@Override
	public boolean isPickable() {
		return true;
	}

	@Override
	public boolean canBeCollidedWith(Entity other) {
		return false;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	@Override
	public ItemStack getPickResult() {
		return getStack().copy();
	}

	@Override
	public void tick() {
		super.tick();
		// sem chao embaixo (bloco quebrado): o item cai
		if (this.level() instanceof ServerLevel server && this.tickCount % 10 == 0) {
			if (server.noCollision(this, this.getBoundingBox().move(0.0D, -0.04D, 0.0D))) {
				this.spawnAtLocation(server, getStack().copy());
				this.discard();
			}
		}
	}

	@Override
	public InteractionResult interact(Player player, InteractionHand hand, Vec3 location) {
		ItemStack held = player.getItemInHand(hand);
		boolean storeMini = held.getItem() instanceof MiniFigureItem && getStack().is(ModItems.MINIATURE_BOX);

		if (this.level().isClientSide()) {
			// usar o item: abre a tela dele (agachado e guardar mini sao tratados no servidor)
			if (!player.isShiftKeyDown() && !storeMini) clientOpener.accept(this);
			return InteractionResult.SUCCESS;
		}
		if (!(this.level() instanceof ServerLevel server)) return InteractionResult.SUCCESS;

		if (player.isShiftKeyDown()) {
			ItemStack stack = getStack().copy();
			if (!player.getInventory().add(stack)) {
				player.drop(stack, false);
			}
			server.playSound(null, getX(), getY(), getZ(), SoundEvents.ITEM_PICKUP, SoundSource.BLOCKS, 0.5F, 1.0F);
			this.discard();
			return InteractionResult.SUCCESS;
		}

		if (storeMini) {
			ItemStack box = getStack().copy();
			if (MiniBoxItem.addMini(server.getServer(), box, MiniFigureItem.read(held))) {
				setStack(box);
				held.shrink(1);
				server.playSound(null, getX(), getY(), getZ(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.5F, 1.3F);
				MiniBoxStore.Box content = MiniBoxItem.box(server.getServer(), box);
				message(player, "Guardada na caixa: " + content.activeTab().name + " (" + content.total() + " no total)");
			} else {
				message(player, "A caixa está lotada.");
			}
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		if (this.isRemoved() || this.isInvulnerableToBase(source)) return false;
		if (source.getEntity() instanceof Player player) {
			if (!player.hasInfiniteMaterials()) {
				this.spawnAtLocation(level, getStack().copy());
			}
			level.playSound(null, getX(), getY(), getZ(), SoundEvents.ARMOR_STAND_BREAK, SoundSource.BLOCKS, 0.5F, 1.5F);
			this.discard();
			return true;
		}
		return false;
	}

	private static void message(Player player, String text) {
		if (player instanceof ServerPlayer sp) {
			sp.sendSystemMessage(Component.literal(text), true);
		}
	}

	// ------------------------------------------------------------ persistencia

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		output.store("stack", ItemStack.OPTIONAL_CODEC, getStack());
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		setStack(input.read("stack", ItemStack.OPTIONAL_CODEC).orElse(ItemStack.EMPTY));
	}
}
