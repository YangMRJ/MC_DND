package com.example.dnd.item;

import java.util.function.BiConsumer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** A sheet of paper that opens an editable character sheet when used. */
public class CharacterSheetItem extends Item {
	/** Set by the client entrypoint; does nothing on a dedicated server. */
	public static BiConsumer<ItemStack, InteractionHand> clientOpener = (stack, hand) -> {};

	public CharacterSheetItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide()) {
			clientOpener.accept(player.getItemInHand(hand), hand);
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Player player = context.getPlayer();
		if (player != null) {
			if (player.isShiftKeyDown()) return com.example.dnd.entity.PlacedItemEntity.place(context);
			return use(context.getLevel(), player, context.getHand());
		}
		return InteractionResult.PASS;
	}
}
