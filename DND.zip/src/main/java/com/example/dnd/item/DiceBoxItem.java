package com.example.dnd.item;

import java.util.function.Consumer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Opens the dice roller when used. */
public class DiceBoxItem extends Item {
	public static Consumer<Player> clientOpener = player -> {};

	public DiceBoxItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide()) {
			clientOpener.accept(player);
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Player player = context.getPlayer();
		if (player != null) {
			if (player.isShiftKeyDown()) return com.example.dnd.entity.PlacedItemEntity.place(context);
			return use(context.getLevel(), player, context.getHand());
		}
		return InteractionResult.PASS;
	}
}
