package com.example.dnd.item;

import com.example.dnd.block.MiniData;
import com.example.dnd.box.MiniBoxStore;
import com.example.dnd.entity.PlacedItemEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/**
 * "Caixa de miniaturas": sem limite de minis e com abas. O conteudo fica no servidor ({@link MiniBoxStore});
 * o item so guarda o id da caixa e uma pre-visualizacao (as primeiras {@link MiniData#MAX} minis da aba ativa),
 * que e o que o render da bandeja 3D e o tabuleiro usam.
 * Clique direito abre a caixa; agachado + clique direito em cima de um bloco coloca a caixa na mesa.
 */
public class MiniBoxItem extends Item {
	public static BiConsumer<ItemStack, InteractionHand> clientOpener = (stack, hand) -> {};

	public MiniBoxItem(Properties properties) {
		super(properties);
	}

	// ------------------------------------------------------------ pre-visualizacao (dentro do item)

	/** A pre-visualizacao guardada no item (so as primeiras minis da aba ativa). */
	public static List<MiniData> read(ItemStack stack) {
		List<MiniData> out = new ArrayList<>();
		CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		if (data == null) return out;
		CompoundTag tag = data.copyTag();
		int n = Math.min(MiniData.MAX, tag.getIntOr("n", 0));
		for (int i = 0; i < n; i++) {
			byte[] png = tag.getByteArray("skin" + i).orElse(new byte[0]);
			if (png.length > 0 && !MiniData.validPng(png)) png = new byte[0];
			out.add(new MiniData(tag.getStringOr("name" + i, "Mini"), png, tag.getBooleanOr("slim" + i, false)));
		}
		return out;
	}

	private static final int CACHE = 8;
	private static final CustomData[] CACHE_KEYS = new CustomData[CACHE];
	private static final List<MiniData>[] CACHE_VALUES = newCache();
	private static int cacheNext = 0;

	@SuppressWarnings("unchecked")
	private static List<MiniData>[] newCache() {
		return (List<MiniData>[]) new List[CACHE];
	}

	/** Igual a {@link #read}, mas com cache por item e lista imutavel: para o render, que le todo frame. */
	public static List<MiniData> readCached(ItemStack stack) {
		CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		if (data == null) return List.of();
		synchronized (CACHE_KEYS) {
			for (int i = 0; i < CACHE; i++) {
				if (CACHE_KEYS[i] == data) return CACHE_VALUES[i];
			}
		}
		List<MiniData> value = List.copyOf(read(stack));
		synchronized (CACHE_KEYS) {
			CACHE_KEYS[cacheNext] = data;
			CACHE_VALUES[cacheNext] = value;
			cacheNext = (cacheNext + 1) % CACHE;
		}
		return value;
	}

	/** Quantas minis a caixa tem no total (todas as abas), segundo o item. */
	public static int total(ItemStack stack) {
		CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		if (data == null) return 0;
		CompoundTag tag = data.copyTag();
		return tag.getIntOr("total", Math.min(MiniData.MAX, tag.getIntOr("n", 0)));
	}

	private static UUID id(ItemStack stack) {
		CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		if (data == null) return null;
		String s = data.copyTag().getStringOr("id", "");
		if (s.isEmpty()) return null;
		try {
			return UUID.fromString(s);
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	/** Grava o id, a pre-visualizacao e o total no item, a partir da caixa. */
	public static void sync(ItemStack stack, UUID id, MiniBoxStore.Box box) {
		List<MiniData> preview = box.activeTab().minis;
		int total = box.total();
		CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> {
			for (int i = 0; i < MiniData.MAX; i++) {
				tag.remove("name" + i);
				tag.remove("skin" + i);
				tag.remove("slim" + i);
			}
			tag.putString("id", id.toString());
			tag.putInt("total", total);
			int n = Math.min(MiniData.MAX, preview.size());
			tag.putInt("n", n);
			for (int i = 0; i < n; i++) {
				MiniData m = preview.get(i);
				tag.putString("name" + i, m.name());
				tag.putByteArray("skin" + i, m.png());
				tag.putBoolean("slim" + i, m.slim());
			}
		});
	}

	// ------------------------------------------------------------ conteudo (no servidor)

	/** Id da caixa; caixas novas ou antigas (minis dentro do item) ganham um id e sao migradas aqui. */
	public static UUID ensureId(MinecraftServer server, ItemStack stack) {
		UUID id = id(stack);
		if (id != null) return id;
		id = UUID.randomUUID();
		MiniBoxStore.Box box = new MiniBoxStore.Box();
		box.activeTab().minis.addAll(read(stack)); // caixa antiga: as minis estavam no item
		MiniBoxStore.put(server, id, box);
		sync(stack, id, box);
		return id;
	}

	/** O conteudo da caixa. Chamar so no servidor. */
	public static MiniBoxStore.Box box(MinecraftServer server, ItemStack stack) {
		return MiniBoxStore.get(server, ensureId(server, stack));
	}

	/** Salva a caixa no disco e atualiza a pre-visualizacao do item. */
	public static void commit(MinecraftServer server, ItemStack stack, MiniBoxStore.Box box) {
		UUID id = ensureId(server, stack);
		MiniBoxStore.save(server, id, box);
		sync(stack, id, box);
	}

	/** Poe uma mini na aba ativa. Falso se a caixa bateu na trava de seguranca. */
	public static boolean addMini(MinecraftServer server, ItemStack stack, MiniData mini) {
		MiniBoxStore.Box box = box(server, stack);
		if (box.total() >= MiniData.MAX_TOTAL) return false;
		box.activeTab().minis.add(mini);
		commit(server, stack, box);
		return true;
	}

	/** As minis da aba ativa que cabem no tabuleiro. */
	public static List<MiniData> boardRoster(MinecraftServer server, ItemStack stack) {
		List<MiniData> all = box(server, stack).activeTab().minis;
		return new ArrayList<>(all.subList(0, Math.min(MiniData.MAX, all.size())));
	}

	// ------------------------------------------------------------ uso

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide()) {
			clientOpener.accept(player.getItemInHand(hand), hand);
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Player player = context.getPlayer();
		if (player == null) return InteractionResult.PASS;
		if (player.isShiftKeyDown()) return PlacedItemEntity.place(context);
		return use(context.getLevel(), player, context.getHand());
	}

	/** Guardar pelo inventario: segura uma miniatura no cursor e clica com o botao direito na caixa. */
	@Override
	public boolean overrideOtherStackedOnMe(ItemStack self, ItemStack other, Slot slot, ClickAction action,
											Player player, SlotAccess carried) {
		if (action != ClickAction.SECONDARY || !slot.allowModification(player)) return false;
		if (!(other.getItem() instanceof MiniFigureItem)) return false;
		if (player.level().isClientSide()) return true; // o servidor faz e sincroniza
		if (addMini(player.level().getServer(), self, MiniFigureItem.read(other))) {
			other.shrink(1);
			player.playSound(SoundEvents.ITEM_PICKUP, 0.5F, 1.3F);
		}
		return true;
	}

	/** Guardar pelo inventario (ao contrario): segura a caixa no cursor e clica com o botao direito numa miniatura. */
	@Override
	public boolean overrideStackedOnOther(ItemStack self, Slot slot, ClickAction action, Player player) {
		if (action != ClickAction.SECONDARY || !slot.allowModification(player)) return false;
		ItemStack target = slot.getItem();
		if (!(target.getItem() instanceof MiniFigureItem)) return false;
		if (player.level().isClientSide()) return true;
		if (addMini(player.level().getServer(), self, MiniFigureItem.read(target))) {
			slot.remove(1);
			player.playSound(SoundEvents.ITEM_PICKUP, 0.5F, 1.3F);
		}
		return true;
	}

	@Override
	public void appendHoverText(ItemStack stack, Item.TooltipContext context, TooltipDisplay display,
								Consumer<Component> lines, TooltipFlag flag) {
		lines.accept(Component.literal(total(stack) + " miniaturas").withStyle(ChatFormatting.GRAY));
		for (MiniData m : read(stack)) {
			lines.accept(Component.literal(" - " + m.name()).withStyle(ChatFormatting.DARK_GRAY));
		}
	}
}
