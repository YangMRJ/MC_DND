package com.example.dnd.item;

import com.example.dnd.ModEntities;
import com.example.dnd.block.MiniData;
import com.example.dnd.entity.MiniFigureEntity;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Uma miniatura solta: guarda UMA {@link MiniData} (nome, skin e modelo de braco) nos dados customizados do item.
 * Clique direito em cima de um bloco coloca a miniatura no mundo ({@link MiniFigureEntity}); clique direito na
 * figura com a caixa de miniaturas na mao guarda ela de volta.
 */
public class MiniFigureItem extends Item {
	private static final int CACHE = 16;
	private static final CustomData[] CACHE_KEYS = new CustomData[CACHE];
	private static final MiniData[] CACHE_VALUES = new MiniData[CACHE];
	private static int cacheNext = 0;

	public MiniFigureItem(Properties properties) {
		super(properties);
	}

	// ------------------------------------------------------------ dados

	public static MiniData read(ItemStack stack) {
		CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		if (data == null) return MiniData.steve();
		synchronized (CACHE_KEYS) {
			// o render le o item todo frame: evita copiar e hashear o PNG a cada vez
			for (int i = 0; i < CACHE; i++) {
				if (CACHE_KEYS[i] == data) return CACHE_VALUES[i];
			}
		}
		CompoundTag tag = data.copyTag();
		byte[] png = tag.getByteArray("skin").orElse(new byte[0]);
		if (png.length > 0 && !MiniData.validPng(png)) png = new byte[0];
		MiniData mini = new MiniData(tag.getStringOr("name", "Mini"), png, tag.getBooleanOr("slim", false));
		synchronized (CACHE_KEYS) {
			CACHE_KEYS[cacheNext] = data;
			CACHE_VALUES[cacheNext] = mini;
			cacheNext = (cacheNext + 1) % CACHE;
		}
		return mini;
	}

	public static void write(ItemStack stack, MiniData mini) {
		CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> {
			tag.putString("name", mini.name());
			tag.putByteArray("skin", mini.png());
			tag.putBoolean("slim", mini.slim());
		});
	}

	public static ItemStack create(MiniData mini) {
		ItemStack stack = new ItemStack(com.example.dnd.ModItems.MINIATURE);
		write(stack, mini);
		return stack;
	}

	// ------------------------------------------------------------ item

	@Override
	public Component getName(ItemStack stack) {
		return Component.literal(read(stack).name());
	}

	@Override
	public void appendHoverText(ItemStack stack, Item.TooltipContext context, TooltipDisplay display,
								Consumer<Component> lines, TooltipFlag flag) {
		MiniData m = read(stack);
		lines.accept(Component.literal("Miniatura").withStyle(ChatFormatting.GRAY));
		lines.accept(Component.literal(m.isDefault() ? "Skin padrão" : "Skin personalizada")
				.withStyle(ChatFormatting.DARK_GRAY));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Level level = context.getLevel();
		Player player = context.getPlayer();

		if (context.getClickedFace() != Direction.UP) {
			if (player instanceof ServerPlayer sp) {
				sp.sendSystemMessage(Component.literal("Coloque a miniatura em cima de um bloco."), true);
			}
			return InteractionResult.FAIL;
		}
		if (!(level instanceof ServerLevel server)) {
			return InteractionResult.SUCCESS;
		}

		Vec3 hit = context.getClickLocation();
		MiniFigureEntity figure = new MiniFigureEntity(ModEntities.MINI_FIGURE, server);
		// de frente para quem colocou, em passos de 22,5 graus
		float yaw = player == null ? 0.0F : Math.round((player.getYRot() + 180.0F) / 22.5F) * 22.5F;
		figure.snapTo(hit.x, hit.y, hit.z, yaw, 0.0F);
		figure.setStack(context.getItemInHand().copyWithCount(1));

		if (!server.noCollision(figure)) {
			if (player instanceof ServerPlayer sp) {
				sp.sendSystemMessage(Component.literal("Sem espaço para a miniatura aqui."), true);
			}
			return InteractionResult.FAIL;
		}

		server.addFreshEntity(figure);
		server.playSound(null, hit.x, hit.y, hit.z, SoundEvents.ARMOR_STAND_PLACE,
				net.minecraft.sounds.SoundSource.BLOCKS, 0.6F, 1.4F);
		if (player != null) context.getItemInHand().consume(1, player);
		return InteractionResult.SUCCESS;
	}
}
