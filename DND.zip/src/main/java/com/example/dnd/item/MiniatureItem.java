package com.example.dnd.item;

import com.example.dnd.ModBlocks;
import com.example.dnd.DND;
import com.example.dnd.block.MiniData;
import com.example.dnd.block.MiniatureStandBlock;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class MiniatureItem extends Item {
	public MiniatureItem(Properties properties) {
		super(properties);
	}

	public static ItemStack create(MiniData mini) {
		ItemStack stack = new ItemStack(com.example.dnd.ModItems.MINIATURE);
		CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> write(tag, mini));
		stack.set(DataComponents.CUSTOM_MODEL_DATA, modelData(mini));
		return stack;
	}

	public static CustomModelData defaultModelData() {
		return new CustomModelData(List.of(), List.of(), List.of(), modelColors(MiniData.steve()));
	}

	private static CustomModelData modelData(MiniData mini) {
		return new CustomModelData(List.of(), List.of(), List.of(), modelColors(mini));
	}

	public static MiniData read(ItemStack stack) {
		CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		if (data == null) return MiniData.steve();
		CompoundTag tag = data.copyTag();
		byte[] png = tag.getByteArray("skin").orElse(new byte[0]);
		if (png.length > 0 && !MiniData.validPng(png)) png = new byte[0];
		return new MiniData(tag.getStringOr("name", "Mini"), png, tag.getBooleanOr("slim", false));
	}

	@Override
	public Component getName(ItemStack stack) {
		return Component.literal(read(stack).name());
	}

	private static void write(CompoundTag tag, MiniData mini) {
		tag.putString("name", mini.name());
		tag.putByteArray("skin", mini.png());
		tag.putBoolean("slim", mini.slim());
	}

	private static List<Integer> modelColors(MiniData mini) {
		try {
			if (mini.isDefault()) return defaultModelColors();
			BufferedImage skin = ImageIO.read(new ByteArrayInputStream(mini.png()));
			if (skin == null || skin.getWidth() != 64 || skin.getHeight() != 64) {
				throw new IOException("Invalid miniature skin image");
			}

			int[] doll = new int[16 * 32];
			int armWidth = mini.slim() ? 3 : 4;
			drawPart(skin, doll, 4, 0, 8, 8, 8, 8, true);
			drawPart(skin, doll, 4, 8, 8, 12, 20, 20, true);
			drawPart(skin, doll, 4 - armWidth, 8, armWidth, 12, 44, 20, true);
			drawPart(skin, doll, 12, 8, armWidth, 12, 36, 52, true);
			drawPart(skin, doll, 4, 20, 4, 12, 4, 20, true);
			drawPart(skin, doll, 8, 20, 4, 12, 20, 52, true);
			drawPart(skin, doll, 4, 0, 8, 8, 40, 8, false);
			drawPart(skin, doll, 4, 8, 8, 12, 20, 36, false);
			drawPart(skin, doll, 4 - armWidth, 8, armWidth, 12, 44, 36, false);
			drawPart(skin, doll, 12, 8, armWidth, 12, 52, 52, false);
			drawPart(skin, doll, 4, 20, 4, 12, 4, 36, false);
			drawPart(skin, doll, 8, 20, 4, 12, 4, 52, false);

			List<Integer> colors = new ArrayList<>(128);
			for (int y = 0; y < 16; y++) {
				for (int x = 0; x < 8; x++) {
					colors.add(downsample(doll, x * 2, y * 2));
				}
			}
			return colors;
		} catch (IOException e) {
			DND.LOGGER.warn("Could not build miniature item sprite; using Steve colors", e);
			return defaultModelColors();
		}
	}

	private static List<Integer> defaultModelColors() {
		try {
			BufferedImage sprite;
			try (InputStream input = MiniatureItem.class.getResourceAsStream("/assets/dnd/textures/item/miniature.png")) {
				if (input == null) throw new IOException("Missing default miniature sprite");
				sprite = ImageIO.read(input);
			}
			if (sprite == null) throw new IOException("Could not read default miniature sprite");
			List<Integer> colors = new ArrayList<>(128);
			for (int y = 0; y < 16; y++) {
				for (int x = 0; x < 8; x++) {
					int sx = 9 + x * 14 / 8;
					int sy = 1 + y * 31 / 16;
					colors.add(sprite.getRGB(sx, sy));
				}
			}
			return colors;
		} catch (IOException e) {
			throw new IllegalStateException("Could not load default miniature sprite", e);
		}
	}

	private static void drawPart(BufferedImage skin, int[] doll, int dx, int dy, int width, int height,
								 int sx, int sy, boolean opaque) {
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int color = skin.getRGB(sx + x, sy + y);
				if (opaque) color |= 0xFF000000;
				int alpha = color >>> 24;
				if (alpha == 0) continue;
				int index = (dy + y) * 16 + dx + x;
				int previous = doll[index];
				float a = alpha / 255F;
				float under = (previous >>> 24) / 255F * (1 - a);
				int outAlpha = Math.min(255, Math.round((a + under) * 255));
				int red = Math.round(((color >> 16 & 255) * a + (previous >> 16 & 255) * under) / (a + under));
				int green = Math.round(((color >> 8 & 255) * a + (previous >> 8 & 255) * under) / (a + under));
				int blue = Math.round(((color & 255) * a + (previous & 255) * under) / (a + under));
				doll[index] = outAlpha << 24 | red << 16 | green << 8 | blue;
			}
		}
	}

	private static int downsample(int[] doll, int x, int y) {
		int red = 0, green = 0, blue = 0, count = 0;
		for (int oy = 0; oy < 2; oy++) {
			for (int ox = 0; ox < 2; ox++) {
				int color = doll[(y + oy) * 16 + x + ox];
				if ((color >>> 24) == 0) continue;
				red += color >> 16 & 255;
				green += color >> 8 & 255;
				blue += color & 255;
				count++;
			}
		}
		return count == 0 ? 0x00FFFFFF : 0xFF000000 | red / count << 16 | green / count << 8 | blue / count;
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Level level = context.getLevel();
		var support = context.getClickedPos();
		var pos = support.above();
		if (!level.getBlockState(support).isFaceSturdy(level, support, Direction.UP)
				|| !level.getBlockState(pos).canBeReplaced()) {
			return InteractionResult.PASS;
		}
		if (level.isClientSide()) return InteractionResult.SUCCESS;

		var facing = context.getPlayer() == null
				? Direction.NORTH
				: context.getPlayer().getDirection().getOpposite();
		var state = ModBlocks.MINIATURE_STAND.defaultBlockState().setValue(MiniatureStandBlock.FACING, facing);
		if (!level.setBlock(pos, state, 3)) return InteractionResult.FAIL;

		if (level.getBlockEntity(pos) instanceof com.example.dnd.block.MiniatureStandBlockEntity stand) {
			stand.setMiniature(read(context.getItemInHand()));
		}
		Player player = context.getPlayer();
		if (player == null || !player.getAbilities().instabuild) context.getItemInHand().shrink(1);
		return InteractionResult.SUCCESS;
	}

	@Override
	public void appendHoverText(ItemStack stack, Item.TooltipContext context, TooltipDisplay display,
								Consumer<Component> lines, TooltipFlag flag) {
		lines.accept(Component.literal(read(stack).name()).withStyle(ChatFormatting.GRAY));
	}
}
