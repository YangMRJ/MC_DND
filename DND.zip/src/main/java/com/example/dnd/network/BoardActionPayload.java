package com.example.dnd.network;

import com.example.dnd.DND;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Client -> server: one edit on a board. Generic ints a/b/c are used per action:
 * ADD (a=x, b=z, c=miniature index), MOVE (a=x, b=z, c=tokenId), REMOVE (c=tokenId), CLEAR (remove all tokens),
 * ROTATE (c=tokenId), SET_CELL (a=x, b=z, c=packed cell), FILL (c=tile id), RESET_MAP.
 */
public record BoardActionPayload(BlockPos pos, int action, int a, int b, int c) implements CustomPacketPayload {
	public static final int ADD = 0, MOVE = 1, REMOVE = 2, CLEAR = 3, ROTATE = 4, SET_CELL = 5, FILL = 6, RESET_MAP = 7;

	public static final Identifier ID = DND.id("board_action");
	public static final CustomPacketPayload.Type<BoardActionPayload> TYPE = new CustomPacketPayload.Type<>(ID);
	public static final StreamCodec<RegistryFriendlyByteBuf, BoardActionPayload> CODEC = StreamCodec.composite(
			BlockPos.STREAM_CODEC, BoardActionPayload::pos,
			ByteBufCodecs.VAR_INT, BoardActionPayload::action,
			ByteBufCodecs.VAR_INT, BoardActionPayload::a,
			ByteBufCodecs.VAR_INT, BoardActionPayload::b,
			ByteBufCodecs.VAR_INT, BoardActionPayload::c,
			BoardActionPayload::new
	);

	public static BoardActionPayload of(BlockPos pos, int action, int a, int b, int c) {
		return new BoardActionPayload(pos, action, a, b, c);
	}

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
