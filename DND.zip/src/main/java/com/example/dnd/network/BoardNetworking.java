package com.example.dnd.network;

import com.example.dnd.block.BoardBlockEntity;
import com.example.dnd.block.MiniData;
import com.example.dnd.item.MiniBoxItem;
import com.example.dnd.item.MiniFigureItem;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

public class BoardNetworking {
	public static void register() {
		PayloadTypeRegistry.serverboundPlay().register(BoardActionPayload.TYPE, BoardActionPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(BoardActionPayload.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			BlockPos pos = payload.pos();

			// Never trust the client: must be near the board and it must really be a board.
			if (!player.blockPosition().closerThan(pos, 8.0)) return;
			if (!(player.level().getBlockEntity(pos) instanceof BoardBlockEntity board)) return;

			switch (payload.action()) {
				case BoardActionPayload.ADD -> board.addToken(payload.a(), payload.b(), payload.c());
				case BoardActionPayload.MOVE -> board.moveToken(payload.c(), payload.a(), payload.b());
				case BoardActionPayload.REMOVE -> board.removeToken(payload.c());
				case BoardActionPayload.CLEAR -> board.clearTokens();
				case BoardActionPayload.ROTATE -> board.rotateToken(payload.c());
				case BoardActionPayload.SET_CELL -> board.setCell(payload.a(), payload.b(), payload.c());
				case BoardActionPayload.FILL -> board.fill(payload.c());
				case BoardActionPayload.RESET_MAP -> board.resetMap();
				default -> {
				}
			}
		});
	}
}
