package com.example.dnd.network;

import com.example.dnd.sheet.CharacterSheetData;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;

/** Validates and performs dice rolls on the server, then announces them to everyone. */
public final class DiceNetworking {
	private static final int[] SIDES = {4, 6, 8, 10, 12, 20, 100};
	private static final String[] DICE_NAMES = {"d4", "d6", "d8", "d10", "d12", "d20", "d100"};
	private static final String[] ABILITIES = {"str", "dex", "con", "int", "wis", "cha"};
	private static final String[] ABILITY_NAMES = {"FOR", "DES", "CON", "INT", "SAB", "CAR"};

	private DiceNetworking() {}

	public static void register() {
		PayloadTypeRegistry.serverboundPlay().register(DiceRollPayload.TYPE, DiceRollPayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(DiceRollPayload.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			int[] counts = parseCounts(payload.diceCounts());
			if (counts == null) return;

			int totalDice = 0;
			for (int count : counts) totalDice += count;
			if (totalDice < 1 || totalDice > 50) return;

			int modifier = 0;
			String characterName = "";
			boolean hasValidSheet = false;
			if (payload.sheetSlot() >= 0 && payload.sheetSlot() < player.getInventory().getContainerSize()) {
				ItemStack sheetStack = player.getInventory().getItem(payload.sheetSlot());
				if (sheetStack.is(com.example.dnd.sheet.SheetItems.CHARACTER_SHEET)) {
					hasValidSheet = true;
					CompoundTag sheet = CharacterSheetData.read(sheetStack);
					characterName = sheet.getStringOr(CharacterSheetData.NAME, "").trim();
					int abilityIndex = abilityIndex(payload.ability());
					if (abilityIndex >= 0) {
						String scoreText = sheet.getStringOr(ABILITIES[abilityIndex], "");
						try {
							modifier = Math.floorDiv(Integer.parseInt(scoreText.trim()) - 10, 2);
						} catch (NumberFormatException ignored) {
							modifier = 0;
						}
					}
				}
			}

			StringBuilder details = new StringBuilder();
			int sum = 0;
			for (int i = 0; i < counts.length; i++) {
				if (counts[i] == 0) continue;
				if (!details.isEmpty()) details.append("  ");
				details.append(counts[i]).append(DICE_NAMES[i]).append(": ");
				for (int n = 0; n < counts[i]; n++) {
					int result = ThreadLocalRandom.current().nextInt(1, SIDES[i] + 1);
					sum += result;
					if (n > 0) details.append(", ");
					details.append(result);
				}
			}
			int result = sum + modifier;
			String who = characterName.isEmpty() ? player.getName().getString() : characterName;
			String bonus = hasValidSheet && abilityIndex(payload.ability()) >= 0
					? " + " + ABILITY_NAMES[abilityIndex(payload.ability())] + " (" + signed(modifier) + ")"
					: "";
			String message = "🎲 " + who + " rolou " + details + bonus + " = " + result;
			player.level().getServer().getPlayerList().broadcastSystemMessage(Component.literal(message), false);
		});
	}

	private static int[] parseCounts(String encoded) {
		if (encoded == null || encoded.length() > 32) return null;
		String[] parts = encoded.split(",", -1);
		if (parts.length != SIDES.length) return null;
		int[] counts = new int[SIDES.length];
		try {
			for (int i = 0; i < parts.length; i++) {
				counts[i] = Integer.parseInt(parts[i]);
				if (counts[i] < 0 || counts[i] > 20) return null;
			}
		} catch (NumberFormatException e) {
			return null;
		}
		return counts;
	}

	private static int abilityIndex(String ability) {
		for (int i = 0; i < ABILITIES.length; i++) {
			if (ABILITIES[i].equals(ability)) return i;
		}
		return -1;
	}

	private static String signed(int value) {
		return value >= 0 ? "+" + value : Integer.toString(value);
	}
}