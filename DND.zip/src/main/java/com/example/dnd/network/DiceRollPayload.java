package com.example.dnd.network;

import com.example.dnd.DND;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client -> server request to roll dice using an optional character sheet. */
public record DiceRollPayload(int sheetSlot, String ability, String diceCounts) implements CustomPacketPayload {
	public static final Identifier ID = DND.id("dice_roll");
	public static final CustomPacketPayload.Type<DiceRollPayload> TYPE = new CustomPacketPayload.Type<>(ID);
	public static final StreamCodec<RegistryFriendlyByteBuf, DiceRollPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, DiceRollPayload::sheetSlot,
			ByteBufCodecs.STRING_UTF8, DiceRollPayload::ability,
			ByteBufCodecs.STRING_UTF8, DiceRollPayload::diceCounts,
			DiceRollPayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
