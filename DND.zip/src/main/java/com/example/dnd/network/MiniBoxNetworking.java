package com.example.dnd.network;

import com.example.dnd.block.MiniData;
import com.example.dnd.box.MiniBoxStore;
import com.example.dnd.entity.PlacedItemEntity;
import com.example.dnd.item.MiniBoxItem;
import com.example.dnd.item.MiniFigureItem;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;

/** Servidor da caixa de miniaturas: valida cada pedido do cliente, edita a caixa e devolve a vista atual. */
public final class MiniBoxNetworking {
	private MiniBoxNetworking() {
	}

	public static void register() {
		PayloadTypeRegistry.serverboundPlay().register(MiniBoxPayload.TYPE, MiniBoxPayload.CODEC);
		PayloadTypeRegistry.clientboundPlay().register(MiniBoxViewPayload.TYPE, MiniBoxViewPayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(MiniBoxPayload.TYPE, (payload, context) -> handle(context.player(), payload));
	}

	private static void handle(ServerPlayer player, MiniBoxPayload p) {
		MinecraftServer server = player.level().getServer();
		if (server == null) return;

		// Nunca confie no cliente: a caixa tem que estar de fato na mao ou pousada logo ali.
		ItemStack stack;
		PlacedItemEntity placed = null;
		if (p.target() == MiniBoxPayload.TARGET_MAIN) {
			stack = player.getMainHandItem();
		} else if (p.target() == MiniBoxPayload.TARGET_OFF) {
			stack = player.getOffhandItem();
		} else {
			Entity e = player.level().getEntity(p.target() - MiniBoxPayload.TARGET_ENTITY);
			if (!(e instanceof PlacedItemEntity pe) || pe.distanceToSqr(player) > 64.0D) return;
			placed = pe;
			stack = pe.getStack().copy();
		}
		if (!(stack.getItem() instanceof MiniBoxItem)) return;

		MiniBoxStore.Box box = MiniBoxItem.box(server, stack);
		int oldActive = box.active;
		int tab = p.tab() >= 0 && p.tab() < box.tabs.size() ? p.tab() : box.active;
		MiniBoxStore.Tab t = box.tabs.get(tab);
		int page = p.page();
		boolean changed = false;
		int i = p.index();
		boolean validIndex = i >= 0 && i < t.minis.size();

		switch (p.action()) {
			case MiniBoxPayload.VIEW -> {
			}
			case MiniBoxPayload.ADD -> {
				boolean ok = p.png().length == 0 || MiniData.validPng(p.png());
				if (ok && box.total() < MiniData.MAX_TOTAL) {
					t.minis.add(new MiniData(p.name(), p.png(), p.slim()));
					page = MiniBoxViewPayload.pages(t.minis.size()) - 1; // mostra a recem-chegada
					changed = true;
				}
			}
			case MiniBoxPayload.REMOVE -> {
				if (validIndex) {
					t.minis.remove(i);
					changed = true;
				}
			}
			case MiniBoxPayload.RENAME -> {
				if (validIndex) {
					t.minis.set(i, t.minis.get(i).withName(p.name()));
					changed = true;
				}
			}
			case MiniBoxPayload.SLIM -> {
				if (validIndex) {
					t.minis.set(i, t.minis.get(i).withSlim(p.slim()));
					changed = true;
				}
			}
			case MiniBoxPayload.TAKE -> {
				// tira a mini da caixa e entrega como item (ou solta no chao se o inventario estiver cheio)
				if (validIndex) {
					ItemStack out = MiniFigureItem.create(t.minis.remove(i));
					if (!player.getInventory().add(out)) {
						player.drop(out, false);
					}
					changed = true;
				}
			}
			case MiniBoxPayload.TAB_ADD -> {
				if (box.tabs.size() < MiniBoxStore.MAX_TABS) {
					box.tabs.add(new MiniBoxStore.Tab(p.name()));
					tab = box.tabs.size() - 1;
					page = 0;
					changed = true;
				}
			}
			case MiniBoxPayload.TAB_RENAME -> {
				t.name = MiniBoxStore.cleanTabName(p.name());
				changed = true;
			}
			case MiniBoxPayload.TAB_DELETE -> {
				// as minis da aba apagada nao se perdem: vao para a primeira aba que sobrar
				if (box.tabs.size() > 1) {
					box.tabs.remove(tab);
					box.tabs.get(0).minis.addAll(t.minis);
					tab = Math.max(0, tab - 1);
					page = 0;
					changed = true;
				}
			}
			case MiniBoxPayload.MOVE -> {
				int to = p.extra();
				if (validIndex && to >= 0 && to < box.tabs.size() && to != tab) {
					box.tabs.get(to).minis.add(t.minis.remove(i));
					changed = true;
				}
			}
			default -> {
				return;
			}
		}

		box.active = tab; // a aba que o jogador esta vendo e a que vale para o tabuleiro e para a bandeja 3D
		if (changed || box.active != oldActive) {
			MiniBoxItem.commit(server, stack, box);
			if (placed != null) placed.setStack(stack);
		} else if (placed != null) {
			placed.setStack(stack); // id novo (caixa recem-criada)
		}
		sendView(player, box, tab, page);
	}

	private static void sendView(ServerPlayer player, MiniBoxStore.Box box, int tab, int page) {
		MiniBoxStore.Tab t = box.tabs.get(tab);
		int pages = MiniBoxViewPayload.pages(t.minis.size());
		page = Math.max(0, Math.min(page, pages - 1));
		int from = page * MiniBoxViewPayload.PAGE;
		int to = Math.min(t.minis.size(), from + MiniBoxViewPayload.PAGE);
		List<String> names = new ArrayList<>();
		List<Integer> counts = new ArrayList<>();
		for (MiniBoxStore.Tab x : box.tabs) {
			names.add(x.name);
			counts.add(x.minis.size());
		}
		ServerPlayNetworking.send(player, new MiniBoxViewPayload(tab, page, t.minis.size(), names, counts,
				new ArrayList<>(t.minis.subList(from, to))));
	}
}
