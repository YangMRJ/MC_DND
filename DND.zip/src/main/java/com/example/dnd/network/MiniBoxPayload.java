package com.example.dnd.network;

import com.example.dnd.DND;
import com.example.dnd.block.MiniData;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Cliente -> servidor: uma edicao na caixa de miniaturas (na mao ou pousada na mesa).
 * <p>target: 0 = mao principal, 1 = mao secundaria, 2+N = item pousado de id N.
 * tab/index/page sao da aba e da pagina que o jogador esta vendo; index e absoluto dentro da aba.
 * Depois de toda acao o servidor manda de volta a vista atual ({@link MiniBoxViewPayload}).
 * <br>extra: ADD/MOVE usam como aba de destino (MOVE).
 */
public record MiniBoxPayload(int target, int action, int tab, int index, int page, String name, byte[] png,
							 boolean slim, int extra) implements CustomPacketPayload {
	public static final int VIEW = 0, ADD = 1, REMOVE = 2, RENAME = 3, SLIM = 4, TAKE = 5,
			TAB_ADD = 6, TAB_RENAME = 7, TAB_DELETE = 8, MOVE = 9;

	public static final int TARGET_MAIN = 0, TARGET_OFF = 1, TARGET_ENTITY = 2;

	public static final Identifier ID = DND.id("mini_box");
	public static final CustomPacketPayload.Type<MiniBoxPayload> TYPE = new CustomPacketPayload.Type<>(ID);
	public static final StreamCodec<RegistryFriendlyByteBuf, MiniBoxPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, MiniBoxPayload::target,
			ByteBufCodecs.VAR_INT, MiniBoxPayload::action,
			ByteBufCodecs.VAR_INT, MiniBoxPayload::tab,
			ByteBufCodecs.VAR_INT, MiniBoxPayload::index,
			ByteBufCodecs.VAR_INT, MiniBoxPayload::page,
			ByteBufCodecs.stringUtf8(64), MiniBoxPayload::name,
			ByteBufCodecs.byteArray(MiniData.MAX_PNG), MiniBoxPayload::png,
			ByteBufCodecs.BOOL, MiniBoxPayload::slim,
			ByteBufCodecs.VAR_INT, MiniBoxPayload::extra,
			MiniBoxPayload::new
	);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
