package com.example.dnd.network;

import com.example.dnd.DND;
import com.example.dnd.block.MiniData;
import com.example.dnd.box.MiniBoxStore;
import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Servidor -> cliente: o que a tela da caixa mostra agora. So uma pagina da aba atual vai junto (as skins
 * pesam), por isso a caixa pode crescer sem limite sem estourar o tamanho dos pacotes.
 */
public record MiniBoxViewPayload(int tab, int page, int count, List<String> tabNames, List<Integer> tabCounts,
								 List<MiniData> minis) implements CustomPacketPayload {
	/** Quantas minis cabem numa pagina da tela. */
	public static final int PAGE = 8;

	public static final Identifier ID = DND.id("mini_box_view");
	public static final CustomPacketPayload.Type<MiniBoxViewPayload> TYPE = new CustomPacketPayload.Type<>(ID);

	private static final StreamCodec<ByteBuf, MiniData> MINI = StreamCodec.composite(
			ByteBufCodecs.stringUtf8(64), MiniData::name,
			ByteBufCodecs.byteArray(MiniData.MAX_PNG), MiniData::png,
			ByteBufCodecs.BOOL, MiniData::slim,
			MiniData::new
	);

	public static final StreamCodec<RegistryFriendlyByteBuf, MiniBoxViewPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, MiniBoxViewPayload::tab,
			ByteBufCodecs.VAR_INT, MiniBoxViewPayload::page,
			ByteBufCodecs.VAR_INT, MiniBoxViewPayload::count,
			ByteBufCodecs.stringUtf8(64).apply(ByteBufCodecs.list(MiniBoxStore.MAX_TABS)), MiniBoxViewPayload::tabNames,
			ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(MiniBoxStore.MAX_TABS)), MiniBoxViewPayload::tabCounts,
			MINI.apply(ByteBufCodecs.list(PAGE)), MiniBoxViewPayload::minis,
			MiniBoxViewPayload::new
	);

	public static int pages(int count) {
		return Math.max(1, (count + PAGE - 1) / PAGE);
	}

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
