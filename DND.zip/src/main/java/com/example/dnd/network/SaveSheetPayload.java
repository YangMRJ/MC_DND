package com.example.dnd.network;

import com.example.dnd.DND;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client -> server: save a character sheet: the one in the given hand, or (entityId >= 0) the one placed on a table. */
public record SaveSheetPayload(boolean mainHand, int entityId, CompoundTag sheet) implements CustomPacketPayload {
	public static final Identifier ID = DND.id("save_sheet");
	public static final CustomPacketPayload.Type<SaveSheetPayload> TYPE = new CustomPacketPayload.Type<>(ID);
	public static final StreamCodec<RegistryFriendlyByteBuf, SaveSheetPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.BOOL, SaveSheetPayload::mainHand,
			ByteBufCodecs.VAR_INT, SaveSheetPayload::entityId,
			ByteBufCodecs.COMPOUND_TAG, SaveSheetPayload::sheet,
			SaveSheetPayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
