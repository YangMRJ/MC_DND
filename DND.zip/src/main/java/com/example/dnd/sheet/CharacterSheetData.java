package com.example.dnd.sheet;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

/**
 * Character sheet contents, stored on the item as a "sheet" compound inside CUSTOM_DATA.
 * Every value is a short string; the limits below are enforced on the server too.
 */
public final class CharacterSheetData {
	public static final String TAG = "sheet";

	// Field keys.
	public static final String NAME = "name";
	public static final String LEVEL = "level";
	public static final String CLASS = "class";
	public static final String RACE = "race";
	public static final String BACKGROUND = "background";
	public static final String ALIGNMENT = "alignment";
	public static final String HP = "hp";
	public static final String MAX_HP = "maxhp";
	public static final String AC = "ac";
	public static final String SPEED = "speed";
	public static final String NOTES = "notes";

	/** The six ability scores, in display order. */
	public static final String[] ABILITIES = {"str", "dex", "con", "int", "wis", "cha"};

	/** Max length of every known field. Anything not listed here is dropped. */
	private static final Map<String, Integer> LIMITS = new LinkedHashMap<>();

	static {
		LIMITS.put(NAME, 40);
		LIMITS.put(LEVEL, 3);
		LIMITS.put(CLASS, 24);
		LIMITS.put(RACE, 24);
		LIMITS.put(BACKGROUND, 24);
		LIMITS.put(ALIGNMENT, 24);
		LIMITS.put(HP, 4);
		LIMITS.put(MAX_HP, 4);
		LIMITS.put(AC, 3);
		LIMITS.put(SPEED, 5);
		for (String ability : ABILITIES) {
			LIMITS.put(ability, 3);
		}
		LIMITS.put(NOTES, 1200);
	}

	private CharacterSheetData() {
	}

	public static int maxLength(String key) {
		return LIMITS.getOrDefault(key, 0);
	}

	/** Reads the sheet stored on the stack (empty compound if there is none yet). */
	public static CompoundTag read(ItemStack stack) {
		CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
		if (customData == null) {
			return new CompoundTag();
		}
		return customData.copyTag().getCompoundOrEmpty(TAG);
	}

	/**
	 * Builds a safe copy of whatever the client sent: only known keys, values cut to their
	 * limit, control characters removed (a newline is kept only in the notes).
	 */
	public static CompoundTag sanitize(CompoundTag input) {
		CompoundTag clean = new CompoundTag();
		for (Map.Entry<String, Integer> entry : LIMITS.entrySet()) {
			String key = entry.getKey();
			String value = input.getStringOr(key, "");
			StringBuilder out = new StringBuilder();
			for (int i = 0; i < value.length() && out.length() < entry.getValue(); i++) {
				char c = value.charAt(i);
				boolean newline = c == '\n' && key.equals(NOTES);
				if (newline || !Character.isISOControl(c)) {
					out.append(c);
				}
			}
			if (!out.isEmpty()) {
				clean.putString(key, out.toString());
			}
		}
		return clean;
	}

	/** Saves the (sanitized) sheet on the stack. */
	public static void write(ItemStack stack, CompoundTag sheet) {
		CompoundTag clean = sanitize(sheet);
		CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.put(TAG, clean));
	}
}
