package com.example.dnd.sheet;

import com.example.dnd.DND;
import com.example.dnd.item.CharacterSheetItem;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

public final class SheetItems {
	public static final Item CHARACTER_SHEET = register(
			"character_sheet",
			CharacterSheetItem::new,
			new Item.Properties().useItemDescriptionPrefix().stacksTo(1)
	);

	public static void initialize() {
		// Intentionally empty: calling this forces static item registration during mod init.
	}

	private SheetItems() {
	}

	private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
		Identifier id = DND.id(name);
		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
		T item = factory.apply(props.setId(itemKey));
		return Registry.register(BuiltInRegistries.ITEM, itemKey, item);
	}
}
