package com.example.dnd.sheet;

import com.example.dnd.entity.PlacedItemEntity;
import com.example.dnd.network.SaveSheetPayload;
import net.minecraft.world.entity.Entity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;

/** Registers the character sheet item, its creative tab entry and the "save" packet. */
public class SheetMod implements ModInitializer {
	@Override
	public void onInitialize() {
		SheetItems.initialize();
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS)
				.register(tab -> tab.accept(SheetItems.CHARACTER_SHEET));

		PayloadTypeRegistry.serverboundPlay().register(SaveSheetPayload.TYPE, SaveSheetPayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(SaveSheetPayload.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			ItemStack stack;
			PlacedItemEntity placed = null;
			if (payload.entityId() >= 0) {
				// ficha pousada na mesa: tem que existir, estar por perto e ser mesmo uma ficha
				Entity e = player.level().getEntity(payload.entityId());
				if (!(e instanceof PlacedItemEntity pe) || pe.distanceToSqr(player) > 64.0D) return;
				placed = pe;
				stack = pe.getStack().copy();
			} else {
				InteractionHand hand = payload.mainHand() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
				stack = player.getItemInHand(hand);
			}
			// Never trust the client: it must really be a character sheet.
			if (!stack.is(SheetItems.CHARACTER_SHEET)) return;

			CharacterSheetData.write(stack, payload.sheet());

			// Show the character's name on the item so sheets are easy to tell apart.
			CompoundTag saved = CharacterSheetData.read(stack);
			String name = saved.getStringOr(CharacterSheetData.NAME, "").trim();
			if (name.isEmpty()) {
				stack.remove(DataComponents.CUSTOM_NAME);
			} else {
				stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(style -> style.withItalic(false)));
			}
			if (placed != null) placed.setStack(stack);
		});
	}
}
