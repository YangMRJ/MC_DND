#!/usr/bin/env python3
"""Gera a arte dos itens do mod: sprites isometricos (inventario/hotbar) e modelos 3D (mao).

Rode:  python3 tools/gen_item_art.py

Saida (em src/main/resources/assets/dnd):
  textures/item/<item>.png            sprite isometrico 32x32 (hotbar, inventario, chao, moldura)
  textures/item/model_atlas.png       textura dos modelos 3D
  textures/item/board_map.png         textura de cima do mapa-diorama do tabuleiro (mao)
  models/item/dice_box_3d.json        modelo 3D da caixa de dados (mao)
  models/item/miniature_box_3d.json   modelo 3D da caixa de miniaturas (mao)

Os sprites sao desenhados por um mini renderizador isometrico (projecao 2:1) que testa pixel a pixel
qual face de qual caixa aparece, entao o resultado sai com pixel art limpo, sem antialiasing.
"""
import json
import os

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "dnd")
TEX = os.path.join(ROOT, "textures", "item")
MODELS = os.path.join(ROOT, "models", "item")
os.makedirs(TEX, exist_ok=True)
os.makedirs(MODELS, exist_ok=True)

SIZE = 32  # lado do sprite. Troque por 16 se preferir a densidade de pixels do jogo base.


# ------------------------------------------------------------------ cores / ruido
def hx(h):
    return ((h >> 16) & 255, (h >> 8) & 255, h & 255)


def mul(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def noise(a, b=0, c=0):
    n = (a * 374761393 + b * 668265263 + c * 1274126177) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


OUTLINE = hx(0x1A1208)
WOOD = hx(0x7A5230)
WOOD_D = hx(0x5A3A20)
WOOD_L = hx(0x9A6C40)
GOLD = hx(0xE8B84A)
GOLD_D = hx(0xA8782A)
PAPER = hx(0xE9D9A8)
INK = hx(0x4A3820)
SKIN = hx(0xF2C9A0)


# ------------------------------------------------------------------ materiais: f(face, a, b) -> rgb
# face: 'top' (a=x, b=z) | 'left' (+z face: a=x, b=y) | 'right' (+x face: a=z, b=y)
def solid(c):
    return lambda face, a, b: c


def wood(base=WOOD, dark=WOOD_D, light=WOOD_L):
    def f(face, a, b):
        row = int(b) if face == "top" else int(b)
        col = int(a)
        n = noise(row, 7, 1)
        c = mix(dark, base, 0.35 + 0.65 * n)
        if noise(col, row, 3) > 0.86:
            c = mix(c, light, 0.5)
        if face == "top" and int(b * 2) % 4 == 0:
            c = mul(c, 0.9)
        return c
    return f


def die(color, pip, top, left, right):
    """Dado d6. top/left/right = numero de pintas em cada face visivel. Faces de 5x5 unidades."""
    layouts = {
        1: {(2, 2)},
        2: {(1, 1), (3, 3)},
        3: {(1, 1), (2, 2), (3, 3)},
        4: {(1, 1), (3, 1), (1, 3), (3, 3)},
        5: {(1, 1), (3, 1), (2, 2), (1, 3), (3, 3)},
        6: {(1, 1), (3, 1), (1, 2), (3, 2), (1, 3), (3, 3)},
    }

    def f(face, a, b):
        n = {"top": top, "left": left, "right": right}[face]
        # a, b chegam relativos ao inicio da caixa; ver Box.color
        if (int(a), int(b)) in layouts[n]:
            return pip
        return color
    return f


def parchment_sheet():
    def f(face, a, b):
        if face != "top":
            return mix(PAPER, WOOD_D, 0.25)
        x, z = int(a), int(b)
        c = mix(PAPER, hx(0xD2BE86), noise(x, z, 5) * 0.35)
        if x in (0, 14) or z in (0, 11):
            return mix(c, hx(0xB89A5C), 0.7)  # borda
        if 2 <= x <= 5 and 2 <= z <= 5:
            return hx(0x8A6A3A) if x in (2, 5) or z in (2, 5) else hx(0xC9AE74)  # retrato
        if z == 2 and 7 <= x <= 12:
            return INK  # nome
        if z in (4, 5) and 7 <= x <= 12 and z == 4:
            return mix(INK, PAPER, 0.35)
        if z == 7 and (x % 4) in (1, 2) and 2 <= x <= 12:
            return hx(0xB23A3A) if x < 6 else (hx(0x3A6AB2) if x < 10 else hx(0x3A8A4A))  # atributos
        if z in (9, 10) and 2 <= x <= 12 and x % 6 != 0:
            return mix(INK, PAPER, 0.5)
        return c
    return f


def board_top():
    GRASS = [hx(0x5FA24A), hx(0x6BB154), hx(0x559A42)]
    WATER = hx(0x3F7FD0)
    PATH = hx(0xC9A66B)
    STONE = hx(0x8C8C94)

    def f(face, a, b):
        if face != "top":
            return mix(hx(0x5A8A3A), hx(0x3A2916), 0.55)
        cx, cz = int(a // 2), int(b // 2)  # celulas de 2x2 unidades
        if cx == cz or cx == cz + 1:
            return mul(WATER, 0.92 + 0.12 * noise(int(a), int(b), 9))
        if cz == 5 and cx < 5:
            return PATH
        if (cx, cz) in ((1, 4), (0, 1)):
            return STONE
        g = GRASS[(cx + cz * 2) % 3]
        return mul(g, 0.94 + 0.12 * noise(int(a), int(b), 4))
    return f


def leaves():
    def f(face, a, b):
        n = noise(int(a), int(b), 11)
        return mix(hx(0x2F7A34), hx(0x4DB04A), n)
    return f


class Box:
    def __init__(self, x0, y0, z0, x1, y1, z1, mat):
        self.b = (x0, y0, z0, x1, y1, z1)
        self.mat = mat

    def color(self, face, a, b):
        x0, y0, z0, x1, y1, z1 = self.b
        # coordenadas locais (relativas ao canto minimo) para que as texturas fiquem coladas na caixa
        if face == "top":
            return self.mat(face, a - x0, b - z0)
        if face == "left":
            return self.mat(face, a - x0, y1 - b)
        return self.mat(face, a - z0, y1 - b)


def B(*args):
    return Box(*args)


SHADE = {"top": 1.0, "left": 0.80, "right": 0.60}


def render(boxes, canvas=64, ox=32, oy=40):
    """Projecao 2:1: u = x - z ; v = (x + z) / 2 - y.  Camera olhando de (+x, +y, +z)."""
    img = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
    px = img.load()
    for py in range(canvas):
        for pxx in range(canvas):
            u = pxx + 0.5 - ox
            v = py + 0.5 - oy
            best = None
            for bx in boxes:
                x0, y0, z0, x1, y1, z1 = bx.b
                eps = 1e-6
                # topo (y = y1)
                s = 2 * (v + y1)
                x, z = (s + u) / 2, (s - u) / 2
                if x0 - eps <= x <= x1 + eps and z0 - eps <= z <= z1 + eps:
                    d = x + y1 + z
                    if best is None or d >= best[0] - 1e-9:
                        best = (d, "top", bx, x, z)
                # face +x (x = x1)
                z = x1 - u
                y = (x1 + z) / 2 - v
                if z0 - eps <= z <= z1 + eps and y0 - eps <= y <= y1 + eps:
                    d = x1 + y + z
                    if best is None or d >= best[0] - 1e-9:
                        best = (d, "right", bx, z, y)
                # face +z (z = z1)
                x = u + z1
                y = (x + z1) / 2 - v
                if x0 - eps <= x <= x1 + eps and y0 - eps <= y <= y1 + eps:
                    d = x + y + z1
                    if best is None or d >= best[0] - 1e-9:
                        best = (d, "left", bx, x, y)
            if best:
                _, face, bx, a, b = best
                a = min(max(a, bx.b[0] if face != "right" else bx.b[2]), bx.b[3] if face != "right" else bx.b[5]) - 1e-4
                col = bx.color(face, a if face != "right" else a, b if face == "top" else min(b, bx.b[4] - 1e-4))
                px[pxx, py] = mul(col, SHADE[face]) + (255,)
    return img


def finish(img, size=SIZE):
    """Recorta, centraliza, aplica contorno escuro de 1px e devolve um sprite size x size."""
    bbox = img.getbbox()
    crop = img.crop(bbox)
    w, h = crop.size
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    out.paste(crop, ((size - w) // 2, max(1, (size - h) // 2)))
    src = out.load()
    res = out.copy()
    dst = res.load()
    for y in range(size):
        for x in range(size):
            if src[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < size and 0 <= ny < size and src[nx, ny][3] > 0:
                        dst[x, y] = OUTLINE + (255,)
                        break
    return res


# ------------------------------------------------------------------ sprites
STEVE_SKIN = hx(0xC4966F)
STEVE_HAIR = hx(0x3E2A1B)
STEVE_SHIRT = hx(0x1FA3A3)
STEVE_PANTS = hx(0x3B3A9C)
STEVE_SHOE = hx(0x6A6A6A)
STEVE_EYE = hx(0x3B2F8F)


def steve_boxes(x, z, y=1.0, k=1.0):
    """Um Steve em pe (4 de largura incluindo os bracos, 3 de profundidade, ~9 de altura)."""
    def legs(face, a, b):
        a, b = a / k, b / k
        if b >= 2.3:
            return STEVE_SHOE
        return mul(STEVE_PANTS, 0.85) if (face != "right" and int(a) >= 2) else STEVE_PANTS

    def torso(face, a, b):
        a, b = a / k, b / k
        if face == "left":
            if b < 1 or 1 <= a < 3:
                return STEVE_SHIRT
            return STEVE_SKIN
        if face == "right":
            return STEVE_SHIRT if (b < 1 or a < 0.7 or a >= 2.3) else STEVE_SKIN
        return STEVE_SHIRT

    def head(face, a, b):
        a, b = a / k, b / k
        if face == "top":
            return STEVE_HAIR
        if face == "left":  # rosto
            if b < 1:
                return STEVE_HAIR
            if 1 <= b < 2 and int(a) in (0, 2):
                return STEVE_EYE
            if 2 <= b < 3 and int(a) == 1:
                return hx(0x8A5A44)
            return STEVE_SKIN
        return STEVE_HAIR if (b < 1 or a < 1) else STEVE_SKIN  # lado

    return [
        B(x + 0.5 * k, y, z, x + 3.5 * k, y + 3 * k, z + 3 * k, legs),
        B(x, y + 3 * k, z, x + 4 * k, y + 6.2 * k, z + 3 * k, torso),
        B(x + 0.5 * k, y + 6.2 * k, z, x + 3.5 * k, y + 9.2 * k, z + 3 * k, head),
    ]


def sprite_dice_box():
    boxes = [
        # tampa aberta, de pe, atras
        B(0, 6, -1.5, 16, 13.5, 0, wood(WOOD_L, WOOD, hx(0xB88050))),
        B(1, 7, 0, 15, 12.5, 0.3, solid(hx(0x8A2A2A))),
        B(0, 13, -1.5, 16, 13.5, 0, solid(GOLD)),
        # caixa aberta
        B(0, 0, 0, 16, 1, 11, wood(WOOD_D, hx(0x3A2916), WOOD)),
        B(0, 1, 0, 16, 6, 1, wood()),
        B(0, 1, 1, 1, 6, 10, wood()),
        B(15, 1, 1, 16, 4, 10, wood()),
        B(1, 1, 10, 15, 4, 11, wood()),
        B(0, 6, 0, 16, 6.8, 1, solid(GOLD)),
        B(0, 4, 10, 16, 4.8, 11, solid(GOLD)),
        B(7, 1.5, 11, 9, 3.5, 11.4, solid(GOLD_D)),                      # fecho
        B(1, 1, 1, 15, 1.3, 10, solid(hx(0x2E5A3A))),                    # feltro
        # dados la dentro
        B(2, 1.3, 2, 7, 6.3, 7, die(hx(0xCF3F3F), hx(0xFFF4E0), 5, 2, 3)),
        B(8.5, 1.3, 3, 13.5, 6.3, 8, die(hx(0xF4EBD8), hx(0x2A1A10), 6, 4, 1)),
        B(4, 6.3, 3, 9, 11.3, 8, die(hx(0x3F6FC4), hx(0xF4EBD8), 4, 5, 2)),
    ]
    return finish(render(boxes))


def sprite_miniature_box():
    boxes = [
        B(0, 0, 0, 16, 1, 11, wood(WOOD_D, hx(0x3A2916), WOOD)),
        B(0, 1, 0, 16, 5, 1, wood(WOOD_L, WOOD, hx(0xB88050))),
        B(0, 1, 1, 1, 5, 10, wood(WOOD_L, WOOD, hx(0xB88050))),
        B(15, 1, 1, 16, 2.5, 10, wood(WOOD_L, WOOD, hx(0xB88050))),
        B(1, 1, 10, 15, 2.5, 11, wood(WOOD_L, WOOD, hx(0xB88050))),
        B(0, 5, 0, 16, 5.8, 1, solid(GOLD)),
        B(0, 2.5, 10, 16, 3.2, 11, solid(GOLD)),
        B(1, 1, 1, 15, 1.4, 10, solid(hx(0x3F8A55))),
    ]
    boxes += steve_boxes(8.8, 2.0, 1.4, 1.4)   # fundo direita
    boxes += steve_boxes(1.6, 5.0, 1.4, 1.4)   # frente esquerda
    return finish(render(boxes))


def sprite_board():
    boxes = [
        B(0, 0, 0, 14, 2, 14, wood()),
        B(1, 2, 1, 13, 2.8, 13, board_top()),
        B(9, 2.8, 3, 10, 5, 4, solid(hx(0x6B4A2A))),               # arvore
        B(8, 5, 2, 11, 8, 5, leaves()),
        B(3, 2.8, 8.5, 5.5, 4.2, 11, solid(hx(0x8A8A92))),          # pedra
        B(6.5, 2.8, 6.5, 8.5, 5.8, 8.5, solid(hx(0xC24040))),       # miniatura
        B(6.5, 5.8, 6.5, 8.5, 7.8, 8.5, solid(SKIN)),
        B(6.5, 7.2, 6.5, 8.5, 7.8, 8.5, solid(hx(0x4A2A14))),
    ]
    return finish(render(boxes))


def sprite_character_sheet():
    boxes = [
        B(0, 0, 0, 15, 1, 12, parchment_sheet()),
        B(3, 1, 3.5, 11, 2, 4.5, solid(hx(0xE8C23A))),              # lapis
        B(11, 1, 3.5, 12, 2, 4.5, solid(hx(0xE9A7A7))),
        B(2.4, 1, 3.5, 3, 2, 4.5, solid(hx(0x333333))),
        B(11.5, 1, 8, 13.5, 1.8, 10, solid(hx(0xB23A3A))),          # lacre
    ]
    return finish(render(boxes))


def sprite_miniature_placeholder():
    """Sprite de reserva (a mini real e desenhada em tempo de execucao com a skin dela)."""
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()

    def rect(x0, y0, x1, y1, c):
        for y in range(y0, y1):
            for x in range(x0, x1):
                px[x, y] = c + (255,)

    rect(5, 1, 11, 7, SKIN)
    rect(5, 1, 11, 3, hx(0x4A2A14))
    rect(6, 4, 7, 5, hx(0x2A2A2A))
    rect(9, 4, 10, 5, hx(0x2A2A2A))
    rect(5, 7, 11, 12, hx(0x3FA0C4))
    rect(3, 7, 5, 12, SKIN)
    rect(11, 7, 13, 12, SKIN)
    rect(5, 12, 8, 15, hx(0x3F4AA0))
    rect(8, 12, 11, 15, hx(0x3F4AA0))
    return img


# ------------------------------------------------------------------ modelos 3D (mao)
ATLAS = 64
REG = {}  # nome -> (x, y, w, h) em pixels do atlas


def build_atlas():
    img = Image.new("RGBA", (ATLAS, ATLAS), (255, 0, 255, 255))
    px = img.load()
    cursor = [0, 0]

    def alloc(name, w, h):
        if cursor[0] + w > ATLAS:
            cursor[0] = 0
            cursor[1] += 8
        REG[name] = (cursor[0], cursor[1], w, h)
        cursor[0] += w

    def fill(name, fn):
        x0, y0, w, h = REG[name]
        for y in range(h):
            for x in range(w):
                px[x0 + x, y0 + y] = fn(x, y) + (255,)

    alloc("wood", 16, 8)
    fill("wood", lambda x, y: mix(WOOD_D, WOOD, 0.3 + 0.7 * noise(y, 2, 1)) if noise(x, y, 3) < 0.88 else WOOD_L)
    alloc("wood_l", 16, 8)
    fill("wood_l", lambda x, y: mix(WOOD, WOOD_L, 0.3 + 0.7 * noise(y, 5, 1)) if noise(x, y, 6) < 0.88 else hx(0xB88050))
    alloc("gold", 8, 8)
    fill("gold", lambda x, y: GOLD if (x + y) % 5 else GOLD_D)
    alloc("felt", 8, 8)
    fill("felt", lambda x, y: mix(hx(0x2E5A3A), hx(0x3F7A4F), noise(x, y, 8)))
    alloc("leaf", 8, 8)
    fill("leaf", lambda x, y: mix(hx(0x2F7A34), hx(0x4DB04A), noise(x, y, 11)))
    alloc("trunk", 8, 8)
    fill("trunk", lambda x, y: mix(hx(0x5A3A20), hx(0x7A5230), noise(x, y // 2, 13)))
    alloc("stone", 8, 8)
    fill("stone", lambda x, y: mix(hx(0x77777F), hx(0x9A9AA2), noise(x, y, 14)))
    alloc("dirt", 8, 8)
    fill("dirt", lambda x, y: mix(hx(0x6B4A2A), hx(0x8A6A3A), noise(x, y, 15)))
    layouts = {1: {(3, 3)}, 2: {(1, 1), (5, 5)}, 3: {(1, 1), (3, 3), (5, 5)}, 4: {(1, 1), (5, 1), (1, 5), (5, 5)},
               5: {(1, 1), (5, 1), (3, 3), (1, 5), (5, 5)}, 6: {(1, 1), (5, 1), (1, 3), (5, 3), (1, 5), (5, 5)}}
    for tag, col, pip in (("dr", hx(0xCF3F3F), hx(0xFFF4E0)), ("dw", hx(0xF4EBD8), hx(0x2A1A10)),
                          ("db", hx(0x3F6FC4), hx(0xF4EBD8)), ("dg", hx(0x3F9A4F), hx(0xF4EBD8))):
        for n in range(1, 7):
            name = f"{tag}{n}"
            alloc(name, 8, 8)
            fill(name, lambda x, y, n=n, col=col, pip=pip: pip if any(abs(x - px_) <= 1 and abs(y - py_) <= 1
                                                                      for px_, py_ in layouts[n]) else col)
    img.save(os.path.join(TEX, "model_atlas.png"))


def build_map_texture():
    """Textura de cima do mapa-diorama do tabuleiro: 32x32 = 16x16 unidades do modelo."""
    N = 32
    img = Image.new("RGBA", (N, N))
    px = img.load()
    for y in range(N):
        for x in range(N):
            bx, bz = x / 2.0, y / 2.0
            dx, dz = (bx - 10) / 3.5, (bz - 11) / 2.5
            d = dx * dx + dz * dz
            sx, sz = (bx - 10) / 5.2, (bz - 11) / 4.2
            ds = sx * sx + sz * sz
            n = noise(x, y, 21)
            if d < 1:
                c = mix(hx(0x2F6FD0), hx(0x4A8FE8), n * 0.7)
            elif ds < 1:
                c = mix(hx(0xD9C58A), hx(0xEBD9A0), n)
            elif bz > 14 and bx > 8:
                c = mix(hx(0xD9C58A), hx(0xEBD9A0), n)
            elif abs(bx - 2 - bz * 0.15) < 0.7 and bz < 9:
                c = mix(hx(0xA88A58), hx(0xC4A66E), n)
            else:
                c = mix(hx(0x4E9A3E), hx(0x6BB154), n)
            px[x, y] = c + (255,)
    img.save(os.path.join(TEX, "board_map.png"))


def uvr(name):
    x, y, w, h = REG[name]
    k = 16.0 / ATLAS
    return [round(x * k, 4), round(y * k, 4), round((x + w) * k, 4), round((y + h) * k, 4)]


def cube(frm, to, faces, rot=None):
    """faces: nome do material (todas as faces) ou dict face->nome ('map:' no comeco usa a textura do mapa)."""
    els = {}
    for f in ("north", "south", "east", "west", "up", "down"):
        name = faces if isinstance(faces, str) else faces.get(f, faces.get("all"))
        if name == "MAP":
            els[f] = {"texture": "#map", "uv": [0, 0, 16, 16]}
        else:
            els[f] = {"texture": "#atlas", "uv": uvr(name)}
    el = {"from": frm, "to": to, "faces": els}
    if rot:
        el["rotation"] = rot
    return el


DISPLAY = {
    "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 3, 1], "scale": [0.42, 0.42, 0.42]},
    "thirdperson_lefthand": {"rotation": [75, 45, 0], "translation": [0, 3, 1], "scale": [0.42, 0.42, 0.42]},
    "firstperson_righthand": {"rotation": [30, -40, 0], "translation": [1.5, 3.5, 0], "scale": [0.55, 0.55, 0.55]},
    "firstperson_lefthand": {"rotation": [30, 140, 0], "translation": [1.5, 3.5, 0], "scale": [0.55, 0.55, 0.55]},
    "head": {"rotation": [0, 0, 0], "translation": [0, 13, 0], "scale": [0.8, 0.8, 0.8]},
    "gui": {"rotation": [30, 225, 0], "translation": [0, 0, 0], "scale": [0.7, 0.7, 0.7]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.4, 0.4, 0.4]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.7, 0.7, 0.7]},
}

BOARD_DISPLAY = dict(DISPLAY)
BOARD_DISPLAY.update({
    # segurado inclinado para o jogador, como um mapa (o jogo so faz a pose de duas maos para o mapa de verdade)
    "firstperson_righthand": {"rotation": [55, -35, 0], "translation": [2, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "firstperson_lefthand": {"rotation": [55, 145, 0], "translation": [2, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "thirdperson_righthand": {"rotation": [60, 45, 0], "translation": [0, 3, 1], "scale": [0.32, 0.32, 0.32]},
    "thirdperson_lefthand": {"rotation": [60, 45, 0], "translation": [0, 3, 1], "scale": [0.32, 0.32, 0.32]},
})


def write_model(name, elements, display=DISPLAY, extra_textures=None):
    tex = {"atlas": "dnd:item/model_atlas", "particle": "dnd:item/model_atlas"}
    if extra_textures:
        tex.update(extra_textures)
    model = {"textures": tex, "elements": elements, "display": display}
    with open(os.path.join(MODELS, name + ".json"), "w") as fh:
        json.dump(model, fh, indent=2)


def tray(x0, z0, x1, z1, rim, front_clasp=True):
    """Caixa de madeira aberta (paredes de 1, feltro dentro, borda dourada, cantoneiras)."""
    els = [
        cube([x0, 0, z0], [x1, 1, z1], "wood"),
        cube([x0, 1, z0], [x1, rim, z0 + 1], "wood"),
        cube([x0, 1, z0 + 1], [x0 + 1, rim, z1 - 1], "wood"),
        cube([x1 - 1, 1, z0 + 1], [x1, rim, z1 - 1], "wood"),
        cube([x0, 1, z1 - 1], [x1, rim, z1], "wood"),
        cube([x0 + 1, 1, z0 + 1], [x1 - 1, 1.2, z1 - 1], "felt"),
        # borda dourada
        cube([x0 - 0.1, rim, z0 - 0.1], [x1 + 0.1, rim + 0.5, z0 + 1.1], "gold"),
        cube([x0 - 0.1, rim, z1 - 1.1], [x1 + 0.1, rim + 0.5, z1 + 0.1], "gold"),
        cube([x0 - 0.1, rim, z0 + 1], [x0 + 1.1, rim + 0.5, z1 - 1], "gold"),
        cube([x1 - 1.1, rim, z0 + 1], [x1 + 0.1, rim + 0.5, z1 - 1], "gold"),
    ]
    # cantoneiras douradas
    for cx in (x0, x1 - 1.2):
        for cz in (z0, z1 - 1.2):
            els.append(cube([cx - 0.05, 0, cz - 0.05], [cx + 1.25, rim, cz + 1.25], "gold"))
    if front_clasp:
        els.append(cube([(x0 + x1) / 2 - 1, 2, z1], [(x0 + x1) / 2 + 1, rim - 1.2, z1 + 0.4], "gold"))
    return els


def die_cube(x, y, z, tag, size=3.0, angle=0):
    faces = {"up": f"{tag}5", "down": f"{tag}6", "north": f"{tag}1", "south": f"{tag}2", "east": f"{tag}3", "west": f"{tag}4"}
    rot = {"origin": [x + size / 2, y, z + size / 2], "axis": "y", "angle": angle} if angle else None
    return cube([x, y, z], [x + size, y + size, z + size], faces, rot)


def model_dice_box():
    els = tray(0, 3, 16, 13, 6)
    # dados dentro da caixa, uns tortos e um empilhado
    els += [
        die_cube(2.2, 1.2, 4.2, "dr", 3, 22.5),
        die_cube(6.0, 1.2, 4.0, "dw", 3, -22.5),
        die_cube(10.0, 1.2, 4.6, "db", 3, 22.5),
        die_cube(3.0, 1.2, 8.2, "dg", 3, -22.5),
        die_cube(7.2, 1.2, 8.0, "dr", 3, 0),
        die_cube(11.2, 1.2, 8.4, "dw", 3, 22.5),
        die_cube(2.6, 4.2, 4.4, "dw", 3, 22.5),
        die_cube(7.4, 4.2, 8.2, "dg", 3, -22.5),
    ]
    write_model("dice_box_3d", els)


def model_miniature_box():
    """So a bandeja: as miniaturas (com a skin de cada uma) sao desenhadas em tempo de execucao."""
    write_model("miniature_box_3d", tray(0, 3, 16, 13, 5.5))


def model_board():
    els = [
        cube([0, 0, 0], [16, 2, 16], {"all": "dirt", "up": "MAP"}),
        # moldura de madeira em volta do mapa
        cube([0, 2, 0], [16, 2.8, 0.8], "wood_l"),
        cube([0, 2, 15.2], [16, 2.8, 16], "wood_l"),
        cube([0, 2, 0.8], [0.8, 2.8, 15.2], "wood_l"),
        cube([15.2, 2, 0.8], [16, 2.8, 15.2], "wood_l"),
    ]
    for (x, z) in ((3, 3), (7, 3.6), (13, 4), (3.5, 10.5), (2.5, 13)):
        els.append(cube([x, 2, z], [x + 1, 5, z + 1], "trunk"))
        els.append(cube([x - 1, 5, z - 1], [x + 2, 8, z + 2], "leaf"))
        els.append(cube([x - 0.1, 8, z - 0.1], [x + 1.1, 9.2, z + 1.1], "leaf"))
    for (x, z) in ((6, 7), (13, 13)):
        els.append(cube([x, 2, z], [x + 2, 3, z + 1.6], "stone"))
        els.append(cube([x + 0.4, 3, z + 0.3], [x + 1.6, 3.8, z + 1.3], "stone"))
    write_model("board_3d", els, BOARD_DISPLAY, {"map": "dnd:item/board_map"})


def main():
    sprites = {
        "dice_box": sprite_dice_box(),
        "miniature_box": sprite_miniature_box(),
        "board": sprite_board(),
        "character_sheet": sprite_character_sheet(),
    }
    for name, img in sprites.items():
        img.save(os.path.join(TEX, name + ".png"))
    sprite_miniature_placeholder().save(os.path.join(TEX, "miniature.png"))
    build_atlas()
    build_map_texture()
    model_dice_box()
    model_miniature_box()
    model_board()
    print("ok:", ", ".join(sprites), "+ miniature, model_atlas, 2 modelos 3D")


if __name__ == "__main__":
    main()
