#!/usr/bin/env python3
"""Gera as texturas de GUI do mod (pixel art). Rode: python3 tools/gen_textures.py"""
import os, random
import json
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "dnd", "textures", "gui")
ITEM_OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "dnd", "textures", "item")
os.makedirs(OUT, exist_ok=True)
os.makedirs(ITEM_OUT, exist_ok=True)
rnd = random.Random(1337)

def rgb(h): return ((h >> 16) & 255, (h >> 8) & 255, h & 255, 255)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(4))
def shade(c, f): return (max(0, min(255, int(c[0]*f))), max(0, min(255, int(c[1]*f))), max(0, min(255, int(c[2]*f))), c[3])
def save(img, name): img.save(os.path.join(OUT, name))
def save_item(img, name): img.save(os.path.join(ITEM_OUT, name))

# ------------------------------------------------------------------ dados (24x24)
EDGE = rgb(0x1A1208)
PAL = {  # claro, medio, escuro
    4:   (rgb(0x8FE07A), rgb(0x45B04F), rgb(0x216D36)),
    6:   (rgb(0xF58A80), rgb(0xCF3F3F), rgb(0x8A2222)),
    8:   (rgb(0x8EC2FA), rgb(0x4283DB), rgb(0x244E9A)),
    10:  (rgb(0xCB9BF5), rgb(0x9158D0), rgb(0x5A3392)),
    12:  (rgb(0xFABF6A), rgb(0xE48C2C), rgb(0xA65614)),
    20:  (rgb(0x8FEDEA), rgb(0x40B8C4), rgb(0x218590)),
    100: (rgb(0xF6A6D0), rgb(0xD25C9E), rgb(0x91326B)),
}

def face(d, pts, fill):
    d.polygon(pts, fill=fill, outline=shade(fill, 0.55))

def finish(img, d, outer, light):
    d.polygon(outer, outline=EDGE)
    # brilho
    x, y = outer[0]
    img.putpixel((min(23, max(0, light[0])), min(23, max(0, light[1]))), (255, 255, 255, 255))

def die(sides):
    L, M, D = PAL[sides]
    MD = mix(M, D, 0.5)
    img = Image.new("RGBA", (24, 24), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if sides == 4:
        A, B, C, P = (12, 2), (22, 21), (2, 21), (12, 15)
        face(d, [A, C, P], L); face(d, [A, B, P], M); face(d, [C, B, P], D)
        finish(img, d, [A, B, C], (10, 8))
    elif sides == 6:
        T, UR, LR, B, LL, UL, C = (12, 2), (21, 7), (21, 17), (12, 22), (3, 17), (3, 7), (12, 12)
        face(d, [T, UR, C, UL], L); face(d, [UL, C, B, LL], M); face(d, [C, UR, LR, B], D)
        finish(img, d, [T, UR, LR, B, LL, UL], (9, 6))
    elif sides == 8:
        T, R, B, Lf, C = (12, 2), (21, 13), (12, 22), (3, 13), (12, 13)
        face(d, [T, Lf, C], L); face(d, [T, R, C], M); face(d, [Lf, B, C], MD); face(d, [R, B, C], D)
        finish(img, d, [T, R, B, Lf], (8, 9))
    elif sides == 10:
        draw_d10(img, d, L, M, D, MD, 1.0, 0, 0)
    elif sides == 12:
        P = [(12, 2), (22, 9), (18, 21), (6, 21), (2, 9)]
        Q = [(12, 8), (16, 11), (15, 16), (9, 16), (8, 11)]
        shades = [mix(L, M, 0.4), M, D, MD, L]
        for i in range(5):
            j = (i + 1) % 5
            face(d, [P[i], P[j], Q[j], Q[i]], shades[i])
        face(d, Q, L)
        finish(img, d, P, (9, 9))
    elif sides == 20:
        V = [(12, 1), (22, 7), (22, 17), (12, 23), (2, 17), (2, 7)]
        I0, I1, I2 = (12, 7), (17, 16), (7, 16)
        tris = [([V[5], V[0], I0], L), ([V[0], V[1], I0], mix(L, M, 0.5)), ([V[1], V[2], I1], M),
                ([V[2], V[3], I1], D), ([V[3], V[4], I2], MD), ([V[4], V[5], I2], mix(M, L, 0.3)),
                ([I0, I1, V[1]], M), ([I1, I2, V[3]], D), ([I2, I0, V[5]], mix(L, M, 0.5))]
        for pts, c in tris: face(d, pts, c)
        face(d, [I0, I1, I2], L)
        finish(img, d, V, (11, 11))
    elif sides == 100:
        L2, M2, D2 = PAL[10]
        draw_d10(img, d, L2, M2, D2, mix(M2, D2, 0.5), 0.72, 0, 6)
        draw_d10(img, d, L, M, D, MD, 0.72, 9, 0)
    return img

def draw_d10(img, d, L, M, D, MD, s, ox, oy):
    def p(x, y): return (round(x * s) + ox, round(y * s) + oy)
    T, R, B, Lf, Rb, Lb, Mi = p(12, 1), p(21, 9), p(12, 23), p(3, 9), p(19, 17), p(5, 17), p(12, 13)
    face(d, [T, Lf, Mi], L); face(d, [T, R, Mi], M)
    face(d, [Lf, Lb, B, Mi], MD); face(d, [R, Rb, B, Mi], D)
    d.polygon([T, R, Rb, B, Lb, Lf], outline=EDGE)
    img.putpixel(p(9, 6), (255, 255, 255, 255))

for s in (4, 6, 8, 10, 12, 20, 100):
    save(die(s), f"dice_d{s}.png")

# ------------------------------------------------------------------ slots (40x44)
def slot(kind):
    w, h = 40, 44
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    top, bot = {"n": (0x2C1F14, 0x1E140C), "h": (0x4A3622, 0x32231A), "a": (0x3C2A18, 0x2A1C10)}[kind]
    for y in range(h):
        c = mix(rgb(top), rgb(bot), y / (h - 1))
        for x in range(w):
            n = rnd.randint(-3, 3)
            img.putpixel((x, y), (max(0, c[0] + n), max(0, c[1] + n), max(0, c[2] + n), 255))
    border = {"n": 0x0F0905, "h": 0xFFD98A, "a": 0x9C7A45}[kind]
    d.rectangle([0, 0, w - 1, h - 1], outline=rgb(border))
    if kind != "h":
        d.line([(1, 1), (w - 2, 1)], fill=rgb(0x120B06)); d.line([(1, 1), (1, h - 2)], fill=rgb(0x120B06))
        d.line([(2, h - 2), (w - 2, h - 2)], fill=rgb(0x5A4129)); d.line([(w - 2, 2), (w - 2, h - 2)], fill=rgb(0x5A4129))
    else:
        d.rectangle([1, 1, w - 2, h - 2], outline=rgb(0xB8893F))
    return img
save(slot("n"), "slot.png"); save(slot("h"), "slot_hover.png"); save(slot("a"), "slot_active.png")

# ------------------------------------------------------------------ painel da caixa de dados (320x220)
def wood(img, box, horizontal, base=0x5B3A1E):
    x0, y0, x1, y1 = box
    for y in range(y0, y1):
        for x in range(x0, x1):
            k = (y if horizontal else x)
            band = (k // 5) % 2
            c = shade(rgb(base), 1.0 + 0.10 * band + rnd.uniform(-0.05, 0.05))
            if (k % 5) == 0: c = shade(c, 0.78)
            img.putpixel((x, y), c)

def rivet(d, x, y):
    d.ellipse([x - 2, y - 2, x + 2, y + 2], fill=rgb(0x8E8E96), outline=rgb(0x2A2A30))
    d.point((x - 1, y - 1), fill=rgb(0xE8E8F0))

def dice_panel(W=320, H=220):
    img = Image.new("RGBA", (W, H), rgb(0x1A1008)); d = ImageDraw.Draw(img)
    F = 9
    wood(img, (0, 0, W, F), True); wood(img, (0, H - F, W, H), True)
    wood(img, (0, 0, F, H), False); wood(img, (W - F, 0, W, H), False)
    d.rectangle([0, 0, W - 1, H - 1], outline=rgb(0x120A04))
    d.rectangle([F - 1, F - 1, W - F, H - F], outline=rgb(0x2B1A0B))
    # couro interno
    for y in range(F, H - F):
        for x in range(F, W - F):
            base = mix(rgb(0x4A2B1D), rgb(0x34201A), y / H)
            n = rnd.randint(-5, 5)
            if rnd.random() < 0.02: n -= 10
            img.putpixel((x, y), (max(0, base[0] + n), max(0, base[1] + n), max(0, base[2] + n), 255))
    # sombra interna
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); od = ImageDraw.Draw(ov)
    for i in range(4):
        od.rectangle([F + i, F + i, W - F - 1 - i, H - F - 1 - i], outline=(0, 0, 0, 70 - i * 16))
    img.alpha_composite(ov); d = ImageDraw.Draw(img)
    # costura
    s = F + 5
    for x in range(s, W - s, 4):
        d.point((x, s), fill=rgb(0xC9A25E)); d.point((x + 1, s), fill=rgb(0xC9A25E))
        d.point((x, H - s - 1), fill=rgb(0xC9A25E)); d.point((x + 1, H - s - 1), fill=rgb(0xC9A25E))
    for y in range(s, H - s, 4):
        d.point((s, y), fill=rgb(0xC9A25E)); d.point((s, y + 1), fill=rgb(0xC9A25E))
        d.point((W - s - 1, y), fill=rgb(0xC9A25E)); d.point((W - s - 1, y + 1), fill=rgb(0xC9A25E))
    # cantoneiras de ferro
    for cx, cy in [(0, 0), (W - 22, 0), (0, H - 22), (W - 22, H - 22)]:
        d.rectangle([cx, cy, cx + 21, cy + 21], fill=rgb(0x45454E), outline=rgb(0x1C1C22))
        d.line([(cx + 1, cy + 1), (cx + 20, cy + 1)], fill=rgb(0x7A7A86)); d.line([(cx + 1, cy + 1), (cx + 1, cy + 20)], fill=rgb(0x7A7A86))
        rivet(d, cx + 6, cy + 6); rivet(d, cx + 15, cy + 15)
    # fita do titulo
    rx0, rx1, ry0, ry1 = 80, W - 80, 5, 25
    d.polygon([(rx0 - 10, ry0 + 3), (rx0, ry0 + 3), (rx0, ry1 + 3), (rx0 - 10, ry1 + 3), (rx0 - 5, (ry0 + ry1) // 2 + 3)], fill=rgb(0x5A1616), outline=rgb(0x240808))
    d.polygon([(rx1 + 10, ry0 + 3), (rx1, ry0 + 3), (rx1, ry1 + 3), (rx1 + 10, ry1 + 3), (rx1 + 5, (ry0 + ry1) // 2 + 3)], fill=rgb(0x5A1616), outline=rgb(0x240808))
    for y in range(ry0, ry1 + 1):
        c = mix(rgb(0x9A2A2A), rgb(0x6A1818), (y - ry0) / (ry1 - ry0))
        d.line([(rx0, y), (rx1, y)], fill=c)
    d.rectangle([rx0, ry0, rx1, ry1], outline=rgb(0x2A0A0A))
    d.line([(rx0 + 2, ry0 + 2), (rx1 - 2, ry0 + 2)], fill=rgb(0xD9A648)); d.line([(rx0 + 2, ry1 - 2), (rx1 - 2, ry1 - 2)], fill=rgb(0xD9A648))
    return img
save(dice_panel(), "dice_panel.png")

# ------------------------------------------------------------------ pergaminho da ficha (356x236)
def sheet_bg(W=356, H=236):
    img = Image.new("RGBA", (W, H), rgb(0x2A1A0C)); d = ImageDraw.Draw(img)
    cx, cy = W / 2, H / 2
    for y in range(H):
        for x in range(W):
            dx, dy = abs(x - cx) / cx, abs(y - cy) / cy
            edge = max(dx, dy) ** 3.2                  # envelhecimento nas bordas
            base = mix(rgb(0xEFDFB0), rgb(0xC79A5A), min(1, edge))
            n = rnd.randint(-6, 6)
            c = (max(0, min(255, base[0] + n)), max(0, min(255, base[1] + n)), max(0, min(255, base[2] + n - 2)), 255)
            img.putpixel((x, y), c)
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); od = ImageDraw.Draw(ov)
    for _ in range(260):                               # fibras e manchinhas
        x, y = rnd.randrange(W), rnd.randrange(H)
        l = rnd.randint(2, 6)
        od.line([(x, y), (x + l, y + rnd.randint(-1, 1))], fill=(140, 100, 50, rnd.randint(22, 50)))
    img.alpha_composite(ov); d = ImageDraw.Draw(img)
    # moldura dupla
    d.rectangle([0, 0, W - 1, H - 1], outline=rgb(0x2A1A0C))
    d.rectangle([1, 1, W - 2, H - 2], outline=rgb(0x5A3D1E))
    d.rectangle([5, 5, W - 6, H - 6], outline=rgb(0x8A6232))
    d.rectangle([8, 8, W - 9, H - 9], outline=rgb(0xB8935A))
    # ornamentos de canto
    def corner(x, y, sx, sy):
        for i in range(0, 14, 2):
            d.point((x + sx * i, y), fill=rgb(0x8A6232)); d.point((x, y + sy * i), fill=rgb(0x8A6232))
        for (ox, oy) in [(3, 3), (5, 5), (4, 4), (3, 5), (5, 3)]:
            d.point((x + sx * ox, y + sy * oy), fill=rgb(0x6B4423))
        d.rectangle([x + sx * 1 - (1 if sx < 0 else 0), y + sy * 1 - (1 if sy < 0 else 0), x + sx * 2, y + sy * 2], fill=rgb(0xB8362E))
    corner(12, 12, 1, 1); corner(W - 13, 12, -1, 1); corner(12, H - 13, 1, -1); corner(W - 13, H - 13, -1, -1)
    # faixa do titulo
    bx0, bx1, by0, by1 = 52, W - 52, 11, 29
    d.polygon([(bx0 - 14, by0 + 2), (bx0, by0 + 2), (bx0, by1 + 2), (bx0 - 14, by1 + 2), (bx0 - 8, (by0 + by1) // 2 + 2)], fill=rgb(0x4E1414), outline=rgb(0x1E0808))
    d.polygon([(bx1 + 14, by0 + 2), (bx1, by0 + 2), (bx1, by1 + 2), (bx1 + 14, by1 + 2), (bx1 + 8, (by0 + by1) // 2 + 2)], fill=rgb(0x4E1414), outline=rgb(0x1E0808))
    for y in range(by0, by1 + 1):
        c = mix(rgb(0x8E2626), rgb(0x5C1818), (y - by0) / (by1 - by0))
        d.line([(bx0, y), (bx1, y)], fill=c)
    d.rectangle([bx0, by0, bx1, by1], outline=rgb(0x2A0A0A))
    d.line([(bx0 + 2, by0 + 2), (bx1 - 2, by0 + 2)], fill=rgb(0xE0B050)); d.line([(bx0 + 2, by1 - 2), (bx1 - 2, by1 - 2)], fill=rgb(0xE0B050))
    for ex in (bx0 + 7, bx1 - 7):                       # losangos
        d.polygon([(ex, (by0 + by1) // 2 - 3), (ex + 3, (by0 + by1) // 2), (ex, (by0 + by1) // 2 + 3), (ex - 3, (by0 + by1) // 2)], fill=rgb(0xE0B050))
    return img
save(sheet_bg(), "sheet_bg.png")

# ------------------------------------------------------------------ item sprites (isometric pixel art)
INK = rgb(0x26170D)
GOLD = rgb(0xE2B65C)

def outlined_poly(d, points, fill, outline=INK):
    d.polygon(points, fill=fill)
    d.line(points + [points[0]], fill=outline, width=1, joint="curve")

def box_sprite(kind):
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    top = [(16, 2), (29, 9), (16, 16), (3, 9)]
    outlined_poly(d, [(3, 9), (16, 16), (16, 29), (3, 22)], rgb(0x75431F))
    outlined_poly(d, [(16, 16), (29, 9), (29, 22), (16, 29)], rgb(0x4A2A19))
    outlined_poly(d, top, rgb(0xA96931))
    d.line([(5, 10), (16, 16), (27, 10)], fill=rgb(0xD18A44))
    # Brass edging and tiny rivets give the two boxes distinct silhouettes.
    d.line([(4, 20), (16, 27), (16, 28)], fill=GOLD)
    d.line([(17, 27), (28, 21)], fill=rgb(0xB67A36))
    d.point((6, 12), fill=GOLD)
    d.point((26, 11), fill=GOLD)
    if kind == "dice":
        d.polygon([(16, 5), (21, 8), (16, 11), (11, 8)], fill=rgb(0xE9D7A6), outline=INK)
        d.polygon([(11, 8), (16, 11), (16, 15), (11, 12)], fill=rgb(0x8EC2FA), outline=INK)
        d.polygon([(16, 11), (21, 8), (21, 12), (16, 15)], fill=rgb(0x4283DB), outline=INK)
        d.point((14, 9), fill=INK)
        d.point((18, 12), fill=rgb(0xFFFFFF))
    else:
        # A little front-facing hero crest, rather than an isometric miniature.
        d.polygon([(16, 5), (21, 8), (16, 11), (11, 8)], fill=rgb(0xD8B66A), outline=INK)
        d.rectangle((14, 6, 17, 9), fill=rgb(0xE8B68C), outline=INK)
        d.rectangle((14, 6, 17, 6), fill=rgb(0x4E3021))
        d.rectangle((13, 10, 18, 13), fill=rgb(0x3B719A), outline=INK)
        d.point((15, 7), fill=INK)
        d.point((17, 7), fill=INK)
    d.line([(16, 16), (16, 28)], fill=rgb(0x2D1A10))
    return img

save_item(box_sprite("dice"), "dice_box.png")
save_item(box_sprite("mini"), "miniature_box.png")

def sheet_sprite():
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    outlined_poly(d, [(16, 3), (28, 10), (16, 17), (4, 10)], rgb(0x9B6F3C))
    outlined_poly(d, [(4, 10), (16, 17), (16, 29), (4, 22)], rgb(0xD6B879))
    outlined_poly(d, [(16, 17), (28, 10), (28, 22), (16, 29)], rgb(0xB38D53))
    d.line([(7, 11), (16, 16), (25, 11)], fill=rgb(0xF5E5B8))
    for y in (19, 22, 25):
        d.line([(7, y - 7), (14, y - 3)], fill=rgb(0x76512E))
        d.line([(18, y - 3), (25, y - 7)], fill=rgb(0x76512E))
    d.point((16, 20), fill=rgb(0x9E3830))
    d.point((16, 23), fill=rgb(0x9E3830))
    return img

save_item(sheet_sprite(), "character_sheet.png")

def board_sprite():
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    outlined_poly(d, [(16, 3), (29, 10), (16, 17), (3, 10)], rgb(0x44633A))
    outlined_poly(d, [(3, 10), (16, 17), (16, 24), (3, 17)], rgb(0x57391E))
    outlined_poly(d, [(16, 17), (29, 10), (29, 17), (16, 24)], rgb(0x382315))
    for i in range(1, 4):
        x = 3 + i * 3.25
        d.line([(round(x), 10 + round(i * 1.75)), (round(x), 17 + round(i * 1.75))], fill=rgb(0xA9BF72))
    for i in range(1, 4):
        d.line([(4 + i * 3, 10 + i), (28 - i * 3, 10 + i)], fill=rgb(0xA9BF72))
    d.point((11, 10), fill=rgb(0x8C5130))
    d.point((20, 12), fill=rgb(0x567D9E))
    return img

save_item(board_sprite(), "board.png")

def miniature_sprite():
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # Front-facing Steve-shaped miniature; skin colors are supplied by the stored skin in-world.
    d.rectangle((12, 1, 19, 8), fill=rgb(0x805436), outline=INK)
    d.rectangle((13, 4, 14, 5), fill=rgb(0x252229))
    d.rectangle((17, 4, 18, 5), fill=rgb(0x252229))
    d.line([(14, 7), (17, 7)], fill=rgb(0xFFFFFF))
    d.rectangle((9, 9, 13, 21), fill=rgb(0x4A8EC4), outline=INK)
    d.rectangle((18, 9, 22, 21), fill=rgb(0x4A8EC4), outline=INK)
    d.rectangle((13, 9, 18, 20), fill=rgb(0x36739E), outline=INK)
    d.rectangle((13, 20, 15, 30), fill=rgb(0x34465B), outline=INK)
    d.rectangle((16, 20, 18, 30), fill=rgb(0x34465B), outline=INK)
    d.rectangle((12, 29, 15, 31), fill=rgb(0x4A2D20))
    d.rectangle((16, 29, 19, 31), fill=rgb(0x4A2D20))
    d.line([(10, 10), (10, 18)], fill=rgb(0x78B5DC))
    d.point((14, 11), fill=rgb(0x89B7D1))
    return img

save_item(miniature_sprite(), "miniature.png")
save_item(Image.new("RGBA", (16, 16), (255, 255, 255, 255)), "miniature_white.png")

def miniature_pixel_model():
    elements = []
    for y in range(16):
        for x in range(8):
            if (y < 4 or y >= 10) and not 2 <= x <= 5:
                continue
            tint = y * 8 + x
            elements.append({
                "from": [4 + x, 15 - y, 7.5],
                "to": [5 + x, 16 - y, 8.5],
                "faces": {
                    "north": {"texture": "#pixel", "tintindex": tint}
                }
            })
    model = {
        "textures": {"pixel": "dnd:item/miniature_white", "particle": "dnd:item/miniature_white"},
        "elements": elements,
        "display": {
            "gui": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]}
        }
    }
    path = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "dnd", "models", "item", "miniature_pixels.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(model, f, indent=2)
        f.write("\n")

    tints = [{"type": "minecraft:custom_model_data", "index": i, "default": 0xFFFFFF} for i in range(128)]
    item = {
        "model": {
            "type": "minecraft:select",
            "cases": [{
                "when": "gui",
                "model": {
                    "type": "minecraft:model",
                    "model": "dnd:item/miniature_pixels",
                    "tints": tints
                }
            }],
            "fallback": {"type": "minecraft:model", "model": "dnd:item/miniature"},
            "property": "minecraft:display_context"
        }
    }
    item_path = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "dnd", "items", "miniature.json")
    with open(item_path, "w", encoding="utf-8") as f:
        json.dump(item, f, indent=2)
        f.write("\n")

miniature_pixel_model()

def box_model_texture(kind, face):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    base = 0x81502B if face == "side" else 0xA66C38
    d.rectangle((0, 0, 15, 15), fill=rgb(base))
    for y in (3, 8, 13):
        d.line((0, y, 15, y), fill=rgb(0x4B2B18))
        d.line((1, y - 1, 14, y - 1), fill=rgb(0xBD8245))
    d.line((3, 0, 3, 15), fill=rgb(0xD0A251))
    d.line((12, 0, 12, 15), fill=rgb(0x4A2A19))
    if face == "top":
        d.rectangle((1, 1, 14, 14), outline=rgb(0xE2B65C))
        if kind == "dice":
            d.polygon([(8, 3), (12, 5), (8, 7), (4, 5)], fill=rgb(0xE7D7AD), outline=INK)
            d.polygon([(4, 5), (8, 7), (8, 11), (4, 9)], fill=rgb(0x78AEDF), outline=INK)
            d.polygon([(8, 7), (12, 5), (12, 9), (8, 11)], fill=rgb(0x3F77B6), outline=INK)
        else:
            d.rectangle((6, 3, 9, 6), fill=rgb(0xE8B68C), outline=INK)
            d.rectangle((5, 7, 10, 12), fill=rgb(0x36739E), outline=INK)
            d.rectangle((6, 3, 9, 3), fill=rgb(0x4E3021))
    return img

for kind in ("dice", "miniature"):
    for face_name in ("side", "top", "bottom"):
        save_item(box_model_texture(kind, face_name), f"{kind}_box_3d_{face_name}.png")

# ------------------------------------------------------------------ icones 16x16
def icon(rows, cmap, name):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    assert len(rows) == 16, (name, len(rows))
    for y, r in enumerate(rows):
        assert len(r) == 16, (name, y, len(r), r)
        for x, ch in enumerate(r):
            if ch != '.': img.putpixel((x, y), rgb(cmap[ch]))
    save(img, name)

icon(["................",
      "..kkkk....kkkk..",
      ".kRRRRk..kRRRRk.",
      "kRRwwRRkkRRRRRRk",
      "kRRwRRRRRRRRRRrk",
      "kRRRRRRRRRRRRRrk",
      "kRRRRRRRRRRRRrrk",
      ".kRRRRRRRRRRrrk.",
      ".kRRRRRRRRRrrk..",
      "..kRRRRRRRrrrk..",
      "...kRRRRRrrrk...",
      "....kRRRrrrk....",
      ".....kRRrrk.....",
      "......kkkk......",
      "................",
      "................"],
     {'k': 0x3A0A0A, 'R': 0xE53A3A, 'r': 0xA81C24, 'w': 0xFFC0C0}, "icon_heart.png")
icon(["................",
      ".kkkkkkkkkkkkkk.",
      ".kBBBBBkbbbbbbk.",
      ".kBwBBBkbbbbbbk.",
      ".kBBBBBkbbbbbbk.",
      ".kBBBBBkbbbbbbk.",
      ".kBBBBBkbbbbbbk.",
      ".kBBBBBkbbbbbbk.",
      "..kBBBBkbbbbbk..",
      "..kBBBBkbbbbbk..",
      "...kBBBkbbbbk...",
      "...kBBBkbbbbk...",
      "....kBBkbbbk....",
      ".....kBkbbk.....",
      "......kkkk......",
      "................"],
     {'k': 0x14181F, 'B': 0x8FB4D8, 'b': 0x4F73A0, 'w': 0xFFFFFF}, "icon_shield.png")
icon(["................",
      "....kkkkk.......",
      "...kBBBBbk......",
      "...kBBBBbk......",
      "...kBBBBbk......",
      "...kBBBBbk......",
      "...kBBBBbkkk....",
      "...kBBBBbbbbkk..",
      "...kBBBBbbbbbbk.",
      "..kkBBBBbbbbbbk.",
      ".kBBBBBBbbbbbbk.",
      ".kBBBBBBbbbbbbk.",
      ".kkkkkkkkkkkkkk.",
      ".kwwwwwwwwwwwwk.",
      ".kkkkkkkkkkkkkk.",
      "................"],
     {'k': 0x24160A, 'B': 0xB98250, 'b': 0x80532C, 'w': 0x5A4A3A}, "icon_boot.png")
print("ok ->", os.path.abspath(OUT))
